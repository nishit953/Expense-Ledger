from django.contrib import admin

from .models import SavingsEntry


@admin.register(SavingsEntry)
class SavingsEntryAdmin(admin.ModelAdmin):
    list_display = ['user', 'source', 'amount', 'date', 'is_emergency_fund']
    list_filter = ['source', 'is_emergency_fund', 'date']
    search_fields = ['description', 'user__email']
    date_hierarchy = 'date'
