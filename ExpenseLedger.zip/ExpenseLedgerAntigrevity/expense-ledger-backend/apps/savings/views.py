import django_filters
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from . import services
from .models import SavingsEntry
from .permissions import IsOwner
from .serializers import SavingsEntrySerializer, SavingsStatsSerializer


class SavingsFilter(django_filters.FilterSet):
    date_from = django_filters.DateFilter(field_name='date', lookup_expr='gte')
    date_to = django_filters.DateFilter(field_name='date', lookup_expr='lte')
    amount_min = django_filters.NumberFilter(field_name='amount', lookup_expr='gte')
    amount_max = django_filters.NumberFilter(field_name='amount', lookup_expr='lte')

    class Meta:
        model = SavingsEntry
        fields = ['source', 'is_emergency_fund', 'date_from', 'date_to', 'amount_min', 'amount_max']


class SavingsViewSet(viewsets.ModelViewSet):
    """Full CRUD for savings entries, scoped to the logged-in user."""

    serializer_class = SavingsEntrySerializer
    permission_classes = [IsAuthenticated, IsOwner]
    filterset_class = SavingsFilter
    search_fields = ['description']
    ordering_fields = ['amount', 'date', 'created_at']
    ordering = ['-date']

    def get_queryset(self):
        return SavingsEntry.objects.filter(user=self.request.user)


class SavingsStatsView(APIView):
    """GET /api/savings/stats/ — total, this month, emergency fund, and the growth trend, for the summary widgets."""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        data = {
            'total_savings': services.get_total_savings(user),
            'monthly_savings': services.get_monthly_savings(user),
            'emergency_fund': services.get_emergency_fund_total(user),
            'growth_trend': services.get_savings_growth_trend(user, months=6),
        }
        return Response({'success': True, 'data': SavingsStatsSerializer(data).data})
