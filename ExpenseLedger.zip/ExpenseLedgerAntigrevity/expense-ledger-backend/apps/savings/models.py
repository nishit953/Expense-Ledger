from django.conf import settings
from decimal import Decimal

from django.core.validators import MinValueValidator
from django.db import models


class SavingsEntry(models.Model):
    SOURCE_CHOICES = [
        ('salary_savings', 'Salary Savings'),
        ('investment_return', 'Investment Return'),
        ('bonus', 'Bonus'),
        ('gift', 'Gift'),
        ('interest', 'Interest'),
        ('other', 'Other'),
    ]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='savings_entries')

    amount = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal('0.01'))])
    date = models.DateField(db_index=True)
    source = models.CharField(max_length=20, choices=SOURCE_CHOICES, default='other')
    description = models.CharField(max_length=500, blank=True)

    # Flags a portion of savings as the user's emergency fund, for the
    # dashboard's dedicated "Emergency Fund" widget.
    is_emergency_fund = models.BooleanField(default=False)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'savings_entries'
        ordering = ['-date', '-created_at']
        verbose_name_plural = 'Savings entries'
        indexes = [
            models.Index(fields=['user', 'date']),
        ]

    def __str__(self):
        return f'{self.get_source_display()} — ₹{self.amount} on {self.date}'
