import calendar
from datetime import date
from decimal import Decimal

from django.db.models import Sum
from django.db.models.functions import TruncMonth


def get_total_savings(user):
    from .models import SavingsEntry
    total = SavingsEntry.objects.filter(user=user).aggregate(t=Sum('amount'))['t']
    return total or Decimal('0')


def get_emergency_fund_total(user):
    from .models import SavingsEntry
    total = SavingsEntry.objects.filter(user=user, is_emergency_fund=True).aggregate(t=Sum('amount'))['t']
    return total or Decimal('0')


def get_monthly_savings(user, month_date=None):
    from .models import SavingsEntry

    month_date = month_date or date.today()
    first_day = month_date.replace(day=1)
    last_day = month_date.replace(day=calendar.monthrange(month_date.year, month_date.month)[1])

    total = SavingsEntry.objects.filter(
        user=user, date__gte=first_day, date__lte=last_day
    ).aggregate(t=Sum('amount'))['t']
    return total or Decimal('0')


def get_savings_growth_trend(user, months=6):
    """Cumulative savings balance at the end of each of the last N months — for the growth chart."""
    from .models import SavingsEntry

    monthly_totals = (
        SavingsEntry.objects.filter(user=user)
        .annotate(month=TruncMonth('date'))
        .values('month')
        .annotate(total=Sum('amount'))
    )
    monthly_map = {row['month']: row['total'] for row in monthly_totals}

    today = date.today()
    cursor = today.replace(day=1)
    buffer_months = []
    for _ in range(months):
        buffer_months.append(cursor)
        prev_month = cursor.month - 1 or 12
        prev_year = cursor.year - 1 if cursor.month == 1 else cursor.year
        cursor = date(prev_year, prev_month, 1)
    buffer_months.reverse()

    # Cumulative balance up to and including each month, so the chart reads
    # as a running total rather than isolated monthly deposits.
    earliest = buffer_months[0]
    starting_balance = (
        SavingsEntry.objects.filter(user=user, date__lt=earliest)
        .aggregate(t=Sum('amount'))['t']
    ) or Decimal('0')

    results = []
    running_total = starting_balance
    for m in buffer_months:
        running_total += monthly_map.get(m, 0) or 0
        results.append({
            'month': calendar.month_abbr[m.month],
            'deposited': float(monthly_map.get(m, 0) or 0),
            'total_balance': float(running_total),
        })
    return results
