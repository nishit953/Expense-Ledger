from rest_framework import serializers

from .models import SavingsEntry


class SavingsEntrySerializer(serializers.ModelSerializer):
    source_display = serializers.CharField(source='get_source_display', read_only=True)

    class Meta:
        model = SavingsEntry
        fields = [
            'id', 'amount', 'date', 'source', 'source_display', 'description',
            'is_emergency_fund', 'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']

    def create(self, validated_data):
        validated_data['user'] = self.context['request'].user
        return super().create(validated_data)


class SavingsGrowthPointSerializer(serializers.Serializer):
    month = serializers.CharField()
    deposited = serializers.FloatField()
    total_balance = serializers.FloatField()


class SavingsStatsSerializer(serializers.Serializer):
    total_savings = serializers.DecimalField(max_digits=14, decimal_places=2)
    monthly_savings = serializers.DecimalField(max_digits=14, decimal_places=2)
    emergency_fund = serializers.DecimalField(max_digits=14, decimal_places=2)
    growth_trend = SavingsGrowthPointSerializer(many=True)
