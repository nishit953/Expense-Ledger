from django.urls import path
from rest_framework.routers import DefaultRouter

from .views import SavingsStatsView, SavingsViewSet

router = DefaultRouter()
router.register('', SavingsViewSet, basename='savings')

urlpatterns = [
    path('stats/', SavingsStatsView.as_view(), name='savings-stats'),
] + router.urls
