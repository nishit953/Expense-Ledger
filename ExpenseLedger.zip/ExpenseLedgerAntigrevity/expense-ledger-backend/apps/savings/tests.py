from datetime import date

from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase

from apps.authentication.models import User
from .models import SavingsEntry
from .services import get_emergency_fund_total, get_total_savings


class SavingsTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='a@x.com', email='a@x.com', password='StrongPass123!')
        self.other_user = User.objects.create_user(username='b@x.com', email='b@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)
        self.list_url = reverse('savings-list')

        SavingsEntry.objects.create(user=self.user, amount=5000, date=date(2026, 6, 1), source='salary_savings')
        SavingsEntry.objects.create(
            user=self.user, amount=2000, date=date(2026, 6, 15), source='other', is_emergency_fund=True
        )

    def test_list_only_returns_own_entries(self):
        SavingsEntry.objects.create(user=self.other_user, amount=1000, date=date(2026, 6, 1), source='bonus')
        response = self.client.get(self.list_url)
        self.assertEqual(response.data['count'], 2)

    def test_create_savings_entry(self):
        payload = {'amount': '3000.00', 'date': '2026-06-20', 'source': 'bonus'}
        response = self.client.post(self.list_url, payload)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_total_savings_service(self):
        self.assertEqual(get_total_savings(self.user), 7000)

    def test_emergency_fund_total_service(self):
        self.assertEqual(get_emergency_fund_total(self.user), 2000)

    def test_cannot_access_other_users_entry(self):
        other_entry = SavingsEntry.objects.create(user=self.other_user, amount=1000, date=date(2026, 6, 1), source='bonus')
        response = self.client.get(reverse('savings-detail', args=[other_entry.id]))
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)


class SavingsStatsTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='d@x.com', email='d@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)
        SavingsEntry.objects.create(user=self.user, amount=5000, date=date(2026, 6, 1), source='salary_savings', is_emergency_fund=True)

    def test_stats_endpoint(self):
        response = self.client.get(reverse('savings-stats'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.data['data']
        self.assertEqual(float(data['total_savings']), 5000.0)
        self.assertEqual(float(data['emergency_fund']), 5000.0)
        self.assertEqual(len(data['growth_trend']), 6)

    def test_stats_route_does_not_collide_with_detail_route(self):
        # Regression check: DRF's default pk regex would otherwise treat
        # "stats" as a lookup value and 404 instead of hitting the stats view.
        response = self.client.get(reverse('savings-stats'))
        self.assertNotEqual(response.status_code, status.HTTP_404_NOT_FOUND)
