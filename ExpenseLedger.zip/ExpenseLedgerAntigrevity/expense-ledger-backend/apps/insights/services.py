"""
The AI Insights engine. This is NOT itself a trained model — there is no
plausible labeled dataset for "which recommendation should be shown"
(that would mean fabricating ground truth for taste/judgment, exactly
the trap the Phase 6 design doc explicitly avoided for the Financial
Health Score). Instead, this synthesizes outputs already produced
elsewhere — the 5 ML models' predictions, and the existing rule-based
financial health score / budget status / analytics — into readable,
prioritized, personalized text.

Every generator function below calls into an EXISTING service rather
than recomputing anything: apps.budgets.services, apps.savings.services,
apps.goals.services, apps.dashboard.services, apps.reports.services,
apps.ml.pipeline.predict_*, apps.ml.services. This file's only job is
synthesis and phrasing, not new computation — consistent with the "no
duplicate code" standard already followed across this project.

Insights are computed fresh on every request (see apps/insights/models.py
for why nothing here is persisted).
"""
import calendar
import logging
from datetime import date, timedelta

logger = logging.getLogger('insights')

PRIORITY_ORDER = {'high': 0, 'medium': 1, 'low': 2, 'info': 3}

# Personal-finance rules of thumb used below — named constants so the
# reasoning is visible in one place rather than buried as magic numbers.
HEALTHY_SAVINGS_RATE_PERCENT = 20
LOW_SAVINGS_RATE_PERCENT = 10
RECOMMENDED_EMERGENCY_FUND_MONTHS = 3
BUDGET_RISK_THRESHOLD = 0.6
UNDER_SPENT_BUDGET_THRESHOLD_PERCENT = 50
MIN_CATEGORY_SPEND_FOR_BUDGET_SUGGESTION = 500  # per month average — below this, a budget isn't worth suggesting


def _fmt(amount):
    return f'₹{amount:,.0f}'


def generate_overspending_alerts(user, today):
    """Already-exceeded budgets, ML-predicted at-risk budgets, and anomaly-flagged recent expenses."""
    from apps.budgets.models import Budget
    from apps.budgets.services import annotate_budget
    from apps.ml.pipeline.predict_anomaly import predict_anomaly
    from apps.ml.pipeline.predict_budget_risk import predict_budget_risk
    from apps.ml.services import get_budget_risk_context, get_recent_expenses_with_category_history

    insights = []
    month_start = today.replace(day=1)

    for budget in Budget.objects.filter(user=user, month=month_start):
        annotated = annotate_budget(budget)
        if annotated['status'] == 'exceeded':
            insights.append({
                'category': 'overspending', 'priority': 'high',
                'title': f'{budget.get_category_display()} budget exceeded',
                'message': (
                    f"You've spent {_fmt(annotated['current_spending'])} of your "
                    f"{_fmt(budget.monthly_limit)} {budget.get_category_display()} budget "
                    f"this month ({annotated['percentage_used']}%)."
                ),
                'metric': annotated['percentage_used'],
                'related_type': 'budget', 'related_id': budget.id,
            })
            continue  # already known to be over — no need for a risk prediction on top

        risk_score, _method = predict_budget_risk(**get_budget_risk_context(budget))
        if risk_score >= BUDGET_RISK_THRESHOLD:
            insights.append({
                'category': 'overspending', 'priority': 'medium',
                'title': f'{budget.get_category_display()} budget at risk',
                'message': (
                    f"At your current pace, there's roughly a {round(risk_score * 100)}% chance "
                    f"you'll exceed your {budget.get_category_display()} budget by month-end."
                ),
                'metric': risk_score,
                'related_type': 'budget', 'related_id': budget.id,
            })

    for expense, history in get_recent_expenses_with_category_history(user, days=14):
        outcome = predict_anomaly(float(expense.amount), history, day_of_week=expense.expense_date.weekday())
        if outcome['method'] == 'insufficient_history' or not outcome['is_anomaly'] or outcome['score'] <= 0:
            continue  # score <= 0 means "unusually low", not a spending concern
        insights.append({
            'category': 'overspending', 'priority': 'low',
            'title': 'Unusual transaction detected',
            'message': f'"{expense.title}" ({_fmt(float(expense.amount))}) is higher than your typical {expense.category} spending.',
            'metric': outcome['score'],
            'related_type': 'expense', 'related_id': expense.id,
        })

    return insights


def generate_budget_suggestions(user, today):
    """Two directions: categories with real spend but no budget, and budgets that are consistently under-used."""
    from django.db.models import Sum

    from apps.budgets.models import Budget
    from apps.budgets.services import annotate_budget
    from apps.expenses.models import Expense

    insights = []
    month_start = today.replace(day=1)
    window_start = today - timedelta(days=90)

    budgeted_categories = set(
        Budget.objects.filter(user=user, month=month_start).values_list('category', flat=True)
    )
    category_labels = dict(Expense.CATEGORY_CHOICES)

    spend_by_category = (
        Expense.objects.filter(user=user, expense_date__gte=window_start)
        .values('category').annotate(total=Sum('amount')).order_by('-total')
    )
    for row in spend_by_category:
        if row['category'] in budgeted_categories:
            continue
        avg_monthly = float(row['total']) / 3
        if avg_monthly < MIN_CATEGORY_SPEND_FOR_BUDGET_SUGGESTION:
            continue
        label = category_labels.get(row['category'], row['category'])
        insights.append({
            'category': 'budget', 'priority': 'medium',
            'title': f'Consider a budget for {label}',
            'message': (
                f"You've spent an average of {_fmt(avg_monthly)}/month on {label} over the last "
                f"3 months with no budget set for it."
            ),
            'metric': avg_monthly,
            'related_type': None, 'related_id': None,
        })

    days_in_month = calendar.monthrange(month_start.year, month_start.month)[1]
    if today.day >= days_in_month - 5:  # only worth suggesting near month-end, once the picture is mostly settled
        for budget in Budget.objects.filter(user=user, month=month_start):
            annotated = annotate_budget(budget)
            if annotated['percentage_used'] < UNDER_SPENT_BUDGET_THRESHOLD_PERCENT:
                insights.append({
                    'category': 'budget', 'priority': 'low',
                    'title': f'{budget.get_category_display()} budget has room',
                    'message': (
                        f"You've only used {annotated['percentage_used']}% of your "
                        f"{budget.get_category_display()} budget this month — consider "
                        f"reallocating the rest toward savings or a goal."
                    ),
                    'metric': annotated['percentage_used'],
                    'related_type': 'budget', 'related_id': budget.id,
                })

    return insights


def generate_savings_recommendations(user, today):
    """Savings-rate framing plus emergency-fund adequacy, against standard personal-finance rules of thumb."""
    from django.db.models import Sum

    from apps.dashboard.services import get_financial_health_score
    from apps.expenses.models import Expense
    from apps.savings.services import get_emergency_fund_total

    insights = []
    health = get_financial_health_score(user, today)

    if health['savings_rate'] < LOW_SAVINGS_RATE_PERCENT:
        insights.append({
            'category': 'savings', 'priority': 'high',
            'title': 'Savings rate is low this month',
            'message': (
                f"You've saved {health['savings_rate']}% of your income this month. A commonly "
                f"cited target is at least {HEALTHY_SAVINGS_RATE_PERCENT}%."
            ),
            'metric': health['savings_rate'], 'related_type': None, 'related_id': None,
        })
    elif health['savings_rate'] >= HEALTHY_SAVINGS_RATE_PERCENT:
        insights.append({
            'category': 'savings', 'priority': 'info',
            'title': 'Healthy savings rate',
            'message': (
                f"You're saving {health['savings_rate']}% of your income this month — at or above "
                f"the commonly cited {HEALTHY_SAVINGS_RATE_PERCENT}% target."
            ),
            'metric': health['savings_rate'], 'related_type': None, 'related_id': None,
        })

    emergency_fund = float(get_emergency_fund_total(user))
    recent_expense_total = Expense.objects.filter(
        user=user, expense_date__gte=today - timedelta(days=90),
    ).aggregate(t=Sum('amount'))['t']
    avg_monthly_expense = float(recent_expense_total or 0) / 3

    if avg_monthly_expense > 0:
        months_covered = emergency_fund / avg_monthly_expense
        if months_covered < RECOMMENDED_EMERGENCY_FUND_MONTHS:
            insights.append({
                'category': 'savings', 'priority': 'medium',
                'title': 'Emergency fund below recommended level',
                'message': (
                    f"Your emergency fund covers about {months_covered:.1f} month(s) of expenses. "
                    f"A common guideline is {RECOMMENDED_EMERGENCY_FUND_MONTHS}-6 months."
                ),
                'metric': round(months_covered, 1), 'related_type': None, 'related_id': None,
            })

    return insights


def generate_goal_progress_advice(user, today):
    """Uses the goal-completion forecaster's pace_status for each active goal."""
    from apps.goals.models import Goal
    from apps.ml.pipeline.predict_goal_forecast import predict_goal_forecast
    from apps.ml.services import compute_goal_velocity

    insights = []
    for goal in Goal.objects.filter(user=user, status='active'):
        result = predict_goal_forecast(**compute_goal_velocity(goal))

        if result['pace_status'] == 'stalled':
            insights.append({
                'category': 'goal', 'priority': 'medium',
                'title': f'"{goal.name}" has no recent contributions',
                'message': f"You haven't logged a contribution toward {goal.name} yet — even a small regular one keeps it on track.",
                'metric': None, 'related_type': 'goal', 'related_id': goal.id,
            })
        elif result['pace_status'] == 'behind':
            remaining_days = (goal.target_date - today).days
            remaining_amount = float(goal.target_amount) - float(goal.saved_amount)
            if remaining_days > 0:
                required_daily = remaining_amount / remaining_days
                insights.append({
                    'category': 'goal', 'priority': 'medium',
                    'title': f'"{goal.name}" is behind pace',
                    'message': (
                        f"To hit your {goal.target_date} deadline, you'd need to contribute about "
                        f"{_fmt(required_daily)}/day from here — more than your recent pace."
                    ),
                    'metric': round(required_daily, 2), 'related_type': 'goal', 'related_id': goal.id,
                })
        elif result['pace_status'] == 'ahead':
            insights.append({
                'category': 'goal', 'priority': 'info',
                'title': f'"{goal.name}" is ahead of schedule',
                'message': f"At your current pace, you're on track to finish {goal.name} before {goal.target_date}.",
                'metric': None, 'related_type': 'goal', 'related_id': goal.id,
            })

    return insights


def generate_monthly_summary(user, today):
    """Narrative synthesis of the current month — reuses reports.services.monthly_report rather than reimplementing aggregation."""
    from apps.reports.services import monthly_report

    report = monthly_report(user, today.year, today.month)
    overview = report['monthly_overview']
    top_category = report['top_expense_category']
    net = float(overview['net_savings'])

    message = (
        f"This month you've earned {_fmt(float(overview['total_income']))} and spent "
        f"{_fmt(float(overview['total_expense']))}, "
    )
    message += f'leaving a net of {_fmt(net)}.' if net >= 0 else f'spending {_fmt(abs(net))} more than you earned.'
    if top_category:
        message += f" Your biggest expense category was {top_category['category_display']} at {top_category['percentage']}% of total spend."

    return [{
        'category': 'monthly_summary', 'priority': 'info',
        'title': f'{today.strftime("%B %Y")} summary',
        'message': message,
        'metric': net, 'related_type': None, 'related_id': None,
    }]


def generate_financial_health_insights(user, today):
    """Translates the existing rule-based financial health score into specific, actionable narrative insights."""
    from apps.dashboard.services import get_financial_health_score

    health = get_financial_health_score(user, today)
    insights = [{
        'category': 'health', 'priority': 'info',
        'title': f'Financial health: {health["rating"]}',
        'message': (
            f"Your financial health score is {health['score']}/100 ({health['rating']}), based on "
            f"your savings rate, budget adherence, and expense-to-income ratio this month."
        ),
        'metric': health['score'], 'related_type': None, 'related_id': None,
    }]

    if health['budget_adherence'] < 50:
        insights.append({
            'category': 'health', 'priority': 'medium',
            'title': 'Budget adherence needs attention',
            'message': "You're exceeding your set budgets more often than not this month — tightening a category or two could meaningfully improve your score.",
            'metric': health['budget_adherence'], 'related_type': None, 'related_id': None,
        })
    if health['expense_ratio'] > 90:
        insights.append({
            'category': 'health', 'priority': 'high',
            'title': 'Expenses are close to your income',
            'message': f"You're spending {health['expense_ratio']}% of your income this month, leaving little room for savings or unexpected costs.",
            'metric': health['expense_ratio'], 'related_type': None, 'related_id': None,
        })

    return insights


GENERATORS = {
    'overspending': generate_overspending_alerts,
    'budget': generate_budget_suggestions,
    'savings': generate_savings_recommendations,
    'goal': generate_goal_progress_advice,
    'monthly_summary': generate_monthly_summary,
    'health': generate_financial_health_insights,
}


def generate_all_insights(user, category=None, today=None):
    """
    The single entry point the view calls. Runs one or all category
    generators, sorts by priority, and assigns each result a stable-ish
    id for frontend list keys — not a database pk, since nothing here is
    persisted.

    One category's generator failing (e.g. an ML artifact load error)
    does not take down the others — logged and skipped, matching the
    graceful-degradation approach used throughout apps/ml.
    """
    today = today or date.today()
    categories = [category] if category else list(GENERATORS.keys())

    results = []
    for cat in categories:
        generator = GENERATORS.get(cat)
        if not generator:
            continue
        try:
            results.extend(generator(user, today))
        except Exception:
            logger.exception(f'Insight generator "{cat}" failed for user {user.id}')

    results.sort(key=lambda item: PRIORITY_ORDER.get(item['priority'], 99))
    for index, item in enumerate(results):
        item['id'] = f'{item["category"]}-{item.get("related_id") or "na"}-{index}'

    return results
