from collections import Counter
from datetime import date

from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.throttling import ScopedRateThrottle
from rest_framework.views import APIView

from .serializers import VALID_CATEGORIES, InsightsResponseSerializer
from .services import generate_all_insights, logger


class InsightsView(APIView):
    """
    GET /api/insights/?category=overspending

    Returns every AI-generated insight for the current user, sorted by
    priority (high -> info), optionally filtered to one category. Computed
    fresh on every call — see models.py for why nothing here is cached.
    """

    permission_classes = [IsAuthenticated]
    throttle_classes = [ScopedRateThrottle]
    # Insights transitively calls the budget-risk and goal-forecast models
    # across every one of a user's active budgets/goals in a single
    # request — meaningfully more expensive than any single ML prediction
    # endpoint, hence its own, more conservative scope.
    throttle_scope = 'insights'

    def get(self, request):
        category = request.query_params.get('category')
        if category and category not in VALID_CATEGORIES:
            return Response(
                {'success': False, 'message': f'Invalid category. Choose from: {", ".join(VALID_CATEGORIES)}'},
                status=400,
            )

        try:
            insights = generate_all_insights(request.user, category=category, today=date.today())
        except Exception:
            logger.exception('InsightsView: generation failed for user %s', request.user.id)
            return Response(
                {'success': False, 'message': 'Insights are temporarily unavailable.'},
                status=503,
            )

        data = {
            'insights': insights,
            'counts_by_category': dict(Counter(item['category'] for item in insights)),
            'counts_by_priority': dict(Counter(item['priority'] for item in insights)),
        }
        return Response({'success': True, 'data': InsightsResponseSerializer(data).data})
