from rest_framework.permissions import IsAuthenticated

# Every insight is computed from request.user's own data — there's no
# separate object being fetched by id, so IsAuthenticated is sufficient.
__all__ = ['IsAuthenticated']
