# Insights are computed live on every request, not persisted — an insight
# like "you're overspending on Food" would go stale the moment it was
# cached, and staleness would actively mislead rather than just being
# inconvenient. This mirrors the `analytics` and `dashboard` apps, which
# make the same choice for the same reason. Discrete events that genuinely
# need read/dismissed state already have a home in the `notifications`
# app — insights intentionally doesn't duplicate that.
