# No models to register — insights are computed live from other apps'
# data on every request. See models.py for the reasoning.
