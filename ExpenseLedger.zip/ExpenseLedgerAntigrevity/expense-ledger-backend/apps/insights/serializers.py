from rest_framework import serializers

VALID_CATEGORIES = ['overspending', 'budget', 'savings', 'goal', 'monthly_summary', 'health']


class InsightSerializer(serializers.Serializer):
    id = serializers.CharField()
    category = serializers.ChoiceField(choices=VALID_CATEGORIES)
    priority = serializers.ChoiceField(choices=['high', 'medium', 'low', 'info'])
    title = serializers.CharField()
    message = serializers.CharField()
    metric = serializers.FloatField(allow_null=True)
    related_type = serializers.ChoiceField(choices=['budget', 'goal', 'expense'], allow_null=True, required=False)
    related_id = serializers.IntegerField(allow_null=True)


class InsightsResponseSerializer(serializers.Serializer):
    insights = InsightSerializer(many=True)
    counts_by_category = serializers.DictField(child=serializers.IntegerField())
    counts_by_priority = serializers.DictField(child=serializers.IntegerField())
