from datetime import date, timedelta

from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase

from apps.authentication.models import User
from apps.budgets.models import Budget
from apps.expenses.models import Expense
from apps.goals.models import Goal
from apps.goals.services import add_contribution
from apps.income.models import Income
from apps.savings.models import SavingsEntry
from .services import (
    generate_all_insights,
    generate_budget_suggestions,
    generate_financial_health_insights,
    generate_goal_progress_advice,
    generate_monthly_summary,
    generate_overspending_alerts,
    generate_savings_recommendations,
)


class InsightGeneratorTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='a@x.com', email='a@x.com', password='StrongPass123!')
        self.today = date.today()

    def test_overspending_alert_on_exceeded_budget(self):
        Budget.objects.create(user=self.user, category='food', monthly_limit=1000, month=self.today.replace(day=1))
        Expense.objects.create(user=self.user, title='Big spend', category='food', amount=1500, payment_method='upi', expense_date=self.today)

        insights = generate_overspending_alerts(self.user, self.today)
        self.assertEqual(len(insights), 1)
        self.assertEqual(insights[0]['priority'], 'high')
        self.assertEqual(insights[0]['related_type'], 'budget')

    def test_no_overspending_alert_when_within_budget(self):
        Budget.objects.create(user=self.user, category='food', monthly_limit=10000, month=self.today.replace(day=1))
        Expense.objects.create(user=self.user, title='Small spend', category='food', amount=100, payment_method='upi', expense_date=self.today)

        insights = generate_overspending_alerts(self.user, self.today)
        self.assertEqual(insights, [])

    def test_budget_suggestion_for_unbudgeted_category(self):
        for i in range(3):
            month_date = self.today - timedelta(days=30 * i)
            Expense.objects.create(
                user=self.user, title=f'Meal {i}', category='food', amount=1000,
                payment_method='upi', expense_date=month_date,
            )
        insights = generate_budget_suggestions(self.user, self.today)
        self.assertTrue(any(i['category'] == 'budget' and 'food' in i['title'].lower() for i in insights))

    def test_no_budget_suggestion_for_trivial_spend(self):
        Expense.objects.create(user=self.user, title='Snack', category='food', amount=50, payment_method='upi', expense_date=self.today)
        insights = generate_budget_suggestions(self.user, self.today)
        self.assertEqual(insights, [])

    def test_no_budget_suggestion_when_already_budgeted(self):
        Budget.objects.create(user=self.user, category='food', monthly_limit=5000, month=self.today.replace(day=1))
        Expense.objects.create(user=self.user, title='Meal', category='food', amount=2000, payment_method='upi', expense_date=self.today)
        insights = generate_budget_suggestions(self.user, self.today)
        # Specifically checking for the "create a new budget" suggestion type —
        # NOT a blanket "no insight mentions food" check, since a *different*,
        # entirely legitimate insight (under-spent budget reallocation, near
        # month-end) can also mention the category name. Conflating the two
        # made this test flaky depending on what day of the month it ran.
        self.assertFalse(any(i['title'].startswith('Consider a budget for') for i in insights))

    def test_low_savings_rate_flagged(self):
        Income.objects.create(user=self.user, source='salary', amount=50000, income_date=self.today)
        Expense.objects.create(user=self.user, title='Rent', category='rent', amount=48000, payment_method='net_banking', expense_date=self.today)
        insights = generate_savings_recommendations(self.user, self.today)
        self.assertTrue(any(i['priority'] == 'high' and i['category'] == 'savings' for i in insights))

    def test_healthy_savings_rate_praised(self):
        Income.objects.create(user=self.user, source='salary', amount=50000, income_date=self.today)
        Expense.objects.create(user=self.user, title='Rent', category='rent', amount=20000, payment_method='net_banking', expense_date=self.today)
        insights = generate_savings_recommendations(self.user, self.today)
        self.assertTrue(any(i['title'] == 'Healthy savings rate' for i in insights))

    def test_low_emergency_fund_flagged(self):
        Expense.objects.create(user=self.user, title='Rent', category='rent', amount=20000, payment_method='net_banking', expense_date=self.today - timedelta(days=10))
        SavingsEntry.objects.create(user=self.user, amount=5000, date=self.today, source='other', is_emergency_fund=True)
        insights = generate_savings_recommendations(self.user, self.today)
        self.assertTrue(any('emergency fund' in i['title'].lower() for i in insights))

    def test_goal_with_no_contributions_flagged(self):
        Goal.objects.create(user=self.user, name='Trip', category='vacation', target_amount=10000, target_date=self.today + timedelta(days=90))
        insights = generate_goal_progress_advice(self.user, self.today)
        self.assertEqual(len(insights), 1)
        self.assertIn('no recent contributions', insights[0]['title'])

    def test_goal_behind_pace_flagged(self):
        goal = Goal.objects.create(
            user=self.user, name='Trip', category='vacation', target_amount=100000,
            target_date=self.today + timedelta(days=10),
        )
        add_contribution(goal, amount=100, contribution_date=self.today)
        insights = generate_goal_progress_advice(self.user, self.today)
        self.assertTrue(any('behind pace' in i['title'] for i in insights))

    def test_monthly_summary_always_returns_one_insight(self):
        insights = generate_monthly_summary(self.user, self.today)
        self.assertEqual(len(insights), 1)
        self.assertEqual(insights[0]['category'], 'monthly_summary')

    def test_health_insight_always_present(self):
        insights = generate_financial_health_insights(self.user, self.today)
        self.assertTrue(any(i['title'].startswith('Financial health:') for i in insights))

    def test_combined_insights_sorted_by_priority(self):
        Budget.objects.create(user=self.user, category='food', monthly_limit=1000, month=self.today.replace(day=1))
        Expense.objects.create(user=self.user, title='Big spend', category='food', amount=2000, payment_method='upi', expense_date=self.today)

        results = generate_all_insights(self.user, today=self.today)
        priorities = [item['priority'] for item in results]
        priority_rank = {'high': 0, 'medium': 1, 'low': 2, 'info': 3}
        self.assertEqual(priorities, sorted(priorities, key=lambda p: priority_rank[p]))

    def test_each_insight_has_a_stable_id(self):
        results = generate_all_insights(self.user, today=self.today)
        ids = [item['id'] for item in results]
        self.assertEqual(len(ids), len(set(ids)))  # all unique

    def test_single_category_filter(self):
        results = generate_all_insights(self.user, category='health', today=self.today)
        self.assertTrue(all(item['category'] == 'health' for item in results))


class InsightsViewTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='b@x.com', email='b@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)
        self.url = reverse('insights')

    def test_requires_auth(self):
        self.client.force_authenticate(user=None)
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_returns_insights_with_counts(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.data['data']
        self.assertIn('insights', data)
        self.assertIn('counts_by_category', data)
        self.assertIn('counts_by_priority', data)
        # monthly_summary and health always produce at least one insight each, even with no data
        self.assertGreaterEqual(len(data['insights']), 2)

    def test_invalid_category_rejected(self):
        response = self.client.get(self.url, {'category': 'not-a-real-category'})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_valid_category_filter(self):
        response = self.client.get(self.url, {'category': 'monthly_summary'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(all(i['category'] == 'monthly_summary' for i in response.data['data']['insights']))
