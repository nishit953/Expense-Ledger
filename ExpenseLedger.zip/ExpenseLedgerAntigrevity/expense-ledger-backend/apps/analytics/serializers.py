from rest_framework import serializers


class MonthlyTrendPointSerializer(serializers.Serializer):
    month = serializers.CharField()
    income = serializers.FloatField()
    expense = serializers.FloatField()


class CategoryBreakdownSerializer(serializers.Serializer):
    category = serializers.CharField()
    category_display = serializers.CharField()
    total = serializers.DecimalField(max_digits=14, decimal_places=2)
    percentage = serializers.FloatField()


class SourceBreakdownSerializer(serializers.Serializer):
    source = serializers.CharField()
    source_display = serializers.CharField()
    total = serializers.DecimalField(max_digits=14, decimal_places=2)
    percentage = serializers.FloatField()


class WeeklySpendingSerializer(serializers.Serializer):
    day = serializers.CharField()
    total = serializers.FloatField()


class FinancialOverviewSerializer(serializers.Serializer):
    total_income = serializers.DecimalField(max_digits=14, decimal_places=2)
    total_expense = serializers.DecimalField(max_digits=14, decimal_places=2)
    net = serializers.DecimalField(max_digits=14, decimal_places=2)
    total_saved = serializers.DecimalField(max_digits=14, decimal_places=2)
    lifetime_savings = serializers.DecimalField(max_digits=14, decimal_places=2)


class StatisticsSerializer(serializers.Serializer):
    average_monthly_expense = serializers.DecimalField(max_digits=14, decimal_places=2)
    highest_expense_category = serializers.CharField()
    total_transactions = serializers.IntegerField()
    total_savings = serializers.DecimalField(max_digits=14, decimal_places=2)
    monthly_growth = serializers.FloatField()


class AnalyticsSerializer(serializers.Serializer):
    period = serializers.CharField()
    date_from = serializers.DateField()
    date_to = serializers.DateField()

    monthly_income_trend = MonthlyTrendPointSerializer(many=True)
    monthly_expense_trend = MonthlyTrendPointSerializer(many=True)
    expense_categories = CategoryBreakdownSerializer(many=True)
    income_sources = SourceBreakdownSerializer(many=True)
    weekly_spending = WeeklySpendingSerializer(many=True)
    savings_trend = serializers.ListField()
    budget_usage = serializers.DictField()
    financial_overview = FinancialOverviewSerializer()
    statistics = StatisticsSerializer()
