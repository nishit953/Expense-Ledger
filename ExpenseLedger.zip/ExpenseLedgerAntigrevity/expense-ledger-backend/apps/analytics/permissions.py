from rest_framework.permissions import IsAuthenticated

# Analytics has no per-object ownership to check — every query is already
# scoped to request.user inside services.py. IsAuthenticated is enough,
# re-exported here so the app still follows the standard per-app layout.
__all__ = ['IsAuthenticated']
