# No models to register — analytics is a read-only aggregation layer over
# expenses, income, budgets, and savings, which manage their own admin views.
