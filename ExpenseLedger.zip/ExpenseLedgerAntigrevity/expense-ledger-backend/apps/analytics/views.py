from datetime import datetime

from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.budgets.services import get_overall_budget_usage
from apps.savings.services import get_savings_growth_trend

from . import services
from .serializers import AnalyticsSerializer


class AnalyticsView(APIView):
    """
    GET /api/analytics/?period=this_month
    GET /api/analytics/?period=custom&date_from=2026-01-01&date_to=2026-06-30

    period: today | this_week | this_month | last_month | last_6_months | this_year | custom
    """

    permission_classes = [IsAuthenticated]

    def get(self, request):
        period = request.query_params.get('period', 'this_month')
        date_from_param = request.query_params.get('date_from')
        date_to_param = request.query_params.get('date_to')

        date_from = self._parse_date(date_from_param)
        date_to = self._parse_date(date_to_param)

        try:
            start, end = services.resolve_date_range(period, date_from, date_to)
        except ValueError as exc:
            return Response({'success': False, 'message': str(exc)}, status=400)

        user = request.user
        trend = services.monthly_trend(user, months=6)

        data = {
            'period': period,
            'date_from': start,
            'date_to': end,
            'monthly_income_trend': trend,
            'monthly_expense_trend': trend,
            'expense_categories': services.expense_categories_breakdown(user, start, end),
            'income_sources': services.income_sources_breakdown(user, start, end),
            'weekly_spending': services.weekly_spending_pattern(user, start, end),
            'savings_trend': get_savings_growth_trend(user, months=6),
            'budget_usage': get_overall_budget_usage(user, end),
            'financial_overview': services.financial_overview(user, start, end),
            'statistics': services.compute_statistics(user, start, end),
        }

        serializer = AnalyticsSerializer(data)
        return Response({'success': True, 'data': serializer.data})

    @staticmethod
    def _parse_date(value):
        if not value:
            return None
        return datetime.strptime(value, '%Y-%m-%d').date()
