# The analytics app is read-only and aggregates data from expenses, income,
# budgets, and savings — it intentionally defines no models of its own.
