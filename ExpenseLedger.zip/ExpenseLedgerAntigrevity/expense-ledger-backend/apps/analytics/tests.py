from datetime import date

from django.urls import reverse
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase

from apps.authentication.models import User
from apps.expenses.models import Expense
from apps.income.models import Income
from . import services


class AnalyticsServiceTests(APITestCase):
    def test_resolve_this_month(self):
        today = date(2026, 6, 15)
        start, end = services.resolve_date_range('this_month', today=today)
        self.assertEqual(start, date(2026, 6, 1))
        self.assertEqual(end, today)

    def test_resolve_last_month(self):
        today = date(2026, 6, 15)
        start, end = services.resolve_date_range('last_month', today=today)
        self.assertEqual(start, date(2026, 5, 1))
        self.assertEqual(end, date(2026, 5, 31))

    def test_resolve_custom_requires_dates(self):
        with self.assertRaises(ValueError):
            services.resolve_date_range('custom')

    def test_resolve_last_6_months_crosses_year_boundary(self):
        today = date(2026, 2, 10)
        start, end = services.resolve_date_range('last_6_months', today=today)
        self.assertEqual(start, date(2025, 9, 1))


class AnalyticsEndpointTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='a@x.com', email='a@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)
        today = timezone.localdate()

        Expense.objects.create(user=self.user, title='Groceries', category='food', amount=1200, payment_method='upi', expense_date=today)
        Income.objects.create(user=self.user, source='salary', amount=84000, income_date=today)

    def test_analytics_default_period(self):
        response = self.client.get(reverse('analytics'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.data['data']
        self.assertIn('financial_overview', data)
        self.assertIn('statistics', data)
        self.assertIn('expense_categories', data)

    def test_analytics_custom_period_requires_dates(self):
        response = self.client.get(reverse('analytics'), {'period': 'custom'})
        self.assertEqual(response.status_code, 400)

    def test_analytics_custom_period_with_dates(self):
        response = self.client.get(
            reverse('analytics'), {'period': 'custom', 'date_from': '2026-01-01', 'date_to': '2026-12-31'}
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_requires_auth(self):
        self.client.force_authenticate(user=None)
        response = self.client.get(reverse('analytics'))
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
