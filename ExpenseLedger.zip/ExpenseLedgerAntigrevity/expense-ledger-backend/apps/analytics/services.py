import calendar
from datetime import date, timedelta
from decimal import Decimal

from django.db.models import Sum
from django.db.models.functions import TruncMonth

PERIOD_CHOICES = ['today', 'this_week', 'this_month', 'last_month', 'last_6_months', 'this_year', 'custom']


def resolve_date_range(period, date_from=None, date_to=None, today=None):
    """Translates a named period (or explicit custom range) into (start, end) dates, inclusive."""
    today = today or date.today()

    if period == 'today':
        return today, today

    if period == 'this_week':
        start = today - timedelta(days=today.weekday())  # Monday
        return start, today

    if period == 'this_month':
        return today.replace(day=1), today

    if period == 'last_month':
        first_of_this_month = today.replace(day=1)
        last_day_prev_month = first_of_this_month - timedelta(days=1)
        return last_day_prev_month.replace(day=1), last_day_prev_month

    if period == 'last_6_months':
        month = today.month - 5
        year = today.year
        while month <= 0:
            month += 12
            year -= 1
        return date(year, month, 1), today

    if period == 'this_year':
        return date(today.year, 1, 1), today

    if period == 'custom':
        if not date_from or not date_to:
            raise ValueError('Custom period requires both date_from and date_to.')
        return date_from, date_to

    # Sensible default rather than raising, since this feeds a dashboard.
    return today.replace(day=1), today


def monthly_trend(user, months=6, today=None):
    """Shared income + expense monthly trend, reused by monthly income/expense trend endpoints."""
    from apps.expenses.models import Expense
    from apps.income.models import Income

    today = today or date.today()
    expense_totals = (
        Expense.objects.filter(user=user)
        .annotate(month=TruncMonth('expense_date'))
        .values('month')
        .annotate(total=Sum('amount'))
    )
    income_totals = (
        Income.objects.filter(user=user)
        .annotate(month=TruncMonth('income_date'))
        .values('month')
        .annotate(total=Sum('amount'))
    )
    expense_map = {row['month']: row['total'] for row in expense_totals}
    income_map = {row['month']: row['total'] for row in income_totals}

    cursor = today.replace(day=1)
    buffer_months = []
    for _ in range(months):
        buffer_months.append(cursor)
        prev_month = cursor.month - 1 or 12
        prev_year = cursor.year - 1 if cursor.month == 1 else cursor.year
        cursor = date(prev_year, prev_month, 1)
    buffer_months.reverse()

    return [
        {
            'month': calendar.month_abbr[m.month],
            'income': float(income_map.get(m, 0) or 0),
            'expense': float(expense_map.get(m, 0) or 0),
        }
        for m in buffer_months
    ]


def expense_categories_breakdown(user, start, end):
    from apps.expenses.models import Expense

    totals = (
        Expense.objects.filter(user=user, expense_date__gte=start, expense_date__lte=end)
        .values('category')
        .annotate(total=Sum('amount'))
        .order_by('-total')
    )
    grand_total = sum(row['total'] for row in totals) or 1
    labels = dict(Expense.CATEGORY_CHOICES)
    return [
        {
            'category': row['category'],
            'category_display': labels.get(row['category'], row['category']),
            'total': row['total'],
            'percentage': round(float(row['total']) / float(grand_total) * 100, 1),
        }
        for row in totals
    ]


def income_sources_breakdown(user, start, end):
    from apps.income.models import Income

    totals = (
        Income.objects.filter(user=user, income_date__gte=start, income_date__lte=end)
        .values('source')
        .annotate(total=Sum('amount'))
        .order_by('-total')
    )
    grand_total = sum(row['total'] for row in totals) or 1
    labels = dict(Income.SOURCE_CHOICES)
    return [
        {
            'source': row['source'],
            'source_display': labels.get(row['source'], row['source']),
            'total': row['total'],
            'percentage': round(float(row['total']) / float(grand_total) * 100, 1),
        }
        for row in totals
    ]


def weekly_spending_pattern(user, start, end):
    """Total expenses grouped by day-of-week within the range — reveals spending habits (e.g. weekend spikes)."""
    from apps.expenses.models import Expense

    day_totals = {i: Decimal('0') for i in range(7)}  # 0=Monday ... 6=Sunday
    expenses = Expense.objects.filter(user=user, expense_date__gte=start, expense_date__lte=end).values(
        'expense_date', 'amount'
    )
    for row in expenses:
        weekday = row['expense_date'].weekday()
        day_totals[weekday] += row['amount']

    day_names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    return [{'day': day_names[i], 'total': float(day_totals[i])} for i in range(7)]


def financial_overview(user, start, end):
    from apps.expenses.models import Expense
    from apps.income.models import Income
    from apps.savings.services import get_total_savings

    total_income = Income.objects.filter(
        user=user, income_date__gte=start, income_date__lte=end
    ).aggregate(t=Sum('amount'))['t'] or Decimal('0')
    total_expense = Expense.objects.filter(
        user=user, expense_date__gte=start, expense_date__lte=end
    ).aggregate(t=Sum('amount'))['t'] or Decimal('0')
    total_saved_in_range = 0  # populated below via savings app for consistency with period filters
    from apps.savings.models import SavingsEntry
    total_saved_in_range = SavingsEntry.objects.filter(
        user=user, date__gte=start, date__lte=end
    ).aggregate(t=Sum('amount'))['t'] or Decimal('0')

    return {
        'total_income': total_income,
        'total_expense': total_expense,
        'net': total_income - total_expense,
        'total_saved': total_saved_in_range,
        'lifetime_savings': get_total_savings(user),
    }


def compute_statistics(user, start, end):
    from apps.expenses.models import Expense
    from apps.income.models import Income
    from apps.savings.services import get_total_savings

    expenses_qs = Expense.objects.filter(user=user, expense_date__gte=start, expense_date__lte=end)
    incomes_qs = Income.objects.filter(user=user, income_date__gte=start, income_date__lte=end)

    months_in_range = max(1, (end.year - start.year) * 12 + (end.month - start.month) + 1)
    total_expense = expenses_qs.aggregate(t=Sum('amount'))['t'] or Decimal('0')
    average_monthly_expense = total_expense / months_in_range

    category_totals = (
        expenses_qs.values('category').annotate(total=Sum('amount')).order_by('-total').first()
    )
    highest_expense_category = None
    if category_totals:
        highest_expense_category = dict(Expense.CATEGORY_CHOICES).get(category_totals['category'])

    total_transactions = expenses_qs.count() + incomes_qs.count()

    # Growth: net (income - expense) this period vs. the immediately preceding period of equal length.
    period_length = (end - start).days + 1
    prev_end = start - timedelta(days=1)
    prev_start = prev_end - timedelta(days=period_length - 1)

    current_net = float(incomes_qs.aggregate(t=Sum('amount'))['t'] or 0) - float(total_expense)
    prev_income = Income.objects.filter(
        user=user, income_date__gte=prev_start, income_date__lte=prev_end
    ).aggregate(t=Sum('amount'))['t'] or 0
    prev_expense = Expense.objects.filter(
        user=user, expense_date__gte=prev_start, expense_date__lte=prev_end
    ).aggregate(t=Sum('amount'))['t'] or 0
    prev_net = float(prev_income) - float(prev_expense)

    if prev_net != 0:
        monthly_growth = round(((float(current_net) - prev_net) / abs(prev_net)) * 100, 1)
    else:
        monthly_growth = 100.0 if current_net > 0 else 0.0

    return {
        'average_monthly_expense': round(average_monthly_expense, 2),
        'highest_expense_category': highest_expense_category or 'N/A',
        'total_transactions': total_transactions,
        'total_savings': get_total_savings(user),
        'monthly_growth': monthly_growth,
    }
