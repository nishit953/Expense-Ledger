from rest_framework.generics import RetrieveUpdateAPIView
from rest_framework.permissions import IsAuthenticated

from .serializers import UserSettingsSerializer
from .services import get_or_create_settings


class UserSettingsView(RetrieveUpdateAPIView):
    """GET/PUT/PATCH /api/settings/ — always operates on the current user's single settings record."""

    serializer_class = UserSettingsSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return get_or_create_settings(self.request.user)
