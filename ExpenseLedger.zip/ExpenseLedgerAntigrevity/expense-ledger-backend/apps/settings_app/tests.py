from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase

from apps.authentication.models import User
from .models import UserSettings


class UserSettingsTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='a@x.com', email='a@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)
        self.url = reverse('user-settings')

    def test_get_creates_default_settings(self):
        self.assertFalse(UserSettings.objects.filter(user=self.user).exists())
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['theme'], 'system')
        self.assertTrue(UserSettings.objects.filter(user=self.user).exists())

    def test_update_settings(self):
        response = self.client.patch(self.url, {'theme': 'dark'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['theme'], 'dark')

    def test_requires_auth(self):
        self.client.force_authenticate(user=None)
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
