def get_or_create_settings(user):
    from .models import UserSettings

    settings_obj, _ = UserSettings.objects.get_or_create(user=user)
    return settings_obj

