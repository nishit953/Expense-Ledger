from django.contrib import admin

from .models import UserSettings


@admin.register(UserSettings)
class UserSettingsAdmin(admin.ModelAdmin):
    list_display = ['user', 'theme', 'two_factor_enabled']
    list_filter = ['theme']
    search_fields = ['user__email']
