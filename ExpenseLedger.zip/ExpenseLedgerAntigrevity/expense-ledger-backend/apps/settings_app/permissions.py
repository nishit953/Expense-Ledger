from rest_framework.permissions import IsAuthenticated

# UserSettings is fetched via get_or_create scoped to request.user in the
# view itself, so there's no separate object to check ownership against.
__all__ = ['IsAuthenticated']
