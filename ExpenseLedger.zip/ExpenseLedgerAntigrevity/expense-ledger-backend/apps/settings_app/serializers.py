from rest_framework import serializers

from .models import UserSettings


class UserSettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserSettings
        fields = [
            'theme',
            'notify_budget_alerts', 'notify_goal_reminders', 'notify_bill_reminders',
            'notify_monthly_summary', 'notify_low_savings_alerts', 'email_notifications_enabled',
            'two_factor_enabled', 'updated_at',
        ]
        read_only_fields = ['updated_at']
