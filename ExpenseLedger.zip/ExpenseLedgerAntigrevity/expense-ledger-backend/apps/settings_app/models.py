from django.conf import settings
from django.db import models


class UserSettings(models.Model):
    THEME_CHOICES = [
        ('light', 'Light'),
        ('dark', 'Dark'),
        ('system', 'System'),
    ]

    CURRENCY_CHOICES = [
        ('INR', 'Indian Rupee (₹)'),
        ('USD', 'US Dollar ($)'),
        ('EUR', 'Euro (€)'),
        ('GBP', 'British Pound (£)'),
    ]

    LANGUAGE_CHOICES = [
        ('en', 'English'),
        ('hi', 'Hindi'),
    ]

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='settings')

    theme = models.CharField(max_length=10, choices=THEME_CHOICES, default='system')
    currency = models.CharField(max_length=3, choices=CURRENCY_CHOICES, default='INR')
    language = models.CharField(max_length=5, choices=LANGUAGE_CHOICES, default='en')

    # Notification preferences — checked by apps.notifications.services
    # before creating each category of alert, so a user can opt out per type.
    notify_budget_alerts = models.BooleanField(default=True)
    notify_goal_reminders = models.BooleanField(default=True)
    notify_bill_reminders = models.BooleanField(default=True)
    notify_monthly_summary = models.BooleanField(default=True)
    notify_low_savings_alerts = models.BooleanField(default=True)
    email_notifications_enabled = models.BooleanField(default=True)

    two_factor_enabled = models.BooleanField(default=False)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'user_settings'
        verbose_name_plural = 'User settings'

    def __str__(self):
        return f'Settings for {self.user.email}'
