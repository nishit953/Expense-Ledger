from rest_framework.permissions import BasePermission


class IsEmailVerified(BasePermission):
    """Restricts access to users who have completed email verification."""

    message = 'Please verify your email address to access this resource.'

    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_email_verified)
