import logging
import random
from datetime import timedelta

from django.utils import timezone
from rest_framework.views import exception_handler

logger = logging.getLogger('authentication')

OTP_VALIDITY_MINUTES = 10


def generate_otp():
    """Generate a random 6-digit numeric OTP as a string."""
    return f'{random.randint(0, 999999):06d}'


def create_verification_token(user, purpose):
    """Create (and return) a fresh OTP token for the given user/purpose,
    invalidating any previous unused tokens for the same purpose."""
    from .models import EmailVerificationToken

    EmailVerificationToken.objects.filter(user=user, purpose=purpose, is_used=False).update(is_used=True)

    return EmailVerificationToken.objects.create(
        user=user,
        code=generate_otp(),
        purpose=purpose,
        expires_at=timezone.now() + timedelta(minutes=OTP_VALIDITY_MINUTES),
    )


def send_otp_email(user, token):
    """
    Sends the OTP via email using whatever EMAIL_BACKEND is configured
    (console in dev by default, SMTP if configured in .env).

    A send failure never blocks the calling view (registration/password
    reset should not hard-fail just because an email provider is
    temporarily down) — but it IS logged as an error rather than swallowed
    silently, so a misconfigured SMTP setup (wrong App Password, no
    network route, etc.) shows up in the server log instead of leaving
    the user staring at a "check your email" message that never arrives
    with zero trace anywhere of what went wrong.
    """
    from django.core.mail import send_mail

    purpose_subject = {
        'verify_email': 'Verify your ExpenseLedger email',
        'reset_password': 'Reset your ExpenseLedger password',
    }
    subject = purpose_subject.get(token.purpose, 'Your ExpenseLedger code')
    message = (
        f'Hi {user.first_name or user.username},\n\n'
        f'Your verification code is: {token.code}\n'
        f'This code expires in {OTP_VALIDITY_MINUTES} minutes.\n\n'
        f'If you did not request this, you can safely ignore this email.'
    )
    try:
        send_mail(subject, message, None, [user.email], fail_silently=False)
    except Exception:
        logger.error(
            'Failed to send %s email to %s — check EMAIL_BACKEND/EMAIL_HOST_* configuration.',
            token.purpose, user.email, exc_info=True,
        )


def custom_exception_handler(exc, context):
    """Wraps DRF's default exception handler to return a consistent
    { success, message, errors } envelope for every error response."""
    response = exception_handler(exc, context)

    if response is not None:
        errors = response.data
        message = 'Something went wrong'
        if isinstance(errors, dict):
            first_key = next(iter(errors), None)
            if first_key:
                value = errors[first_key]
                message = value[0] if isinstance(value, list) else str(value)
        elif isinstance(errors, list) and errors:
            message = str(errors[0])

        response.data = {
            'success': False,
            'message': message,
            'errors': errors,
        }

    return response
