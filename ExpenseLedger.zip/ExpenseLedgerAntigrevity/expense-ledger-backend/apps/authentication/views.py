from rest_framework import generics, status
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.exceptions import TokenError
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenObtainPairView

from .models import User
from .serializers import (
    ChangePasswordSerializer,
    CustomTokenObtainPairSerializer,
    ForgotPasswordSerializer,
    RegisterSerializer,
    ResendOTPSerializer,
    ResetPasswordSerializer,
    UserSerializer,
    VerifyEmailSerializer,
)
from .utils import create_verification_token, send_otp_email


class RegisterView(generics.CreateAPIView):
    """POST /api/auth/register/ — creates the user and sends an email-verification OTP."""

    queryset = User.objects.all()
    serializer_class = RegisterSerializer
    permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()

        token = create_verification_token(user, purpose='verify_email')
        send_otp_email(user, token)

        return Response(
            {
                'success': True,
                'message': 'Account created. Check your email for a verification code.',
                'data': {'email': user.email},
            },
            status=status.HTTP_201_CREATED,
        )


class CustomTokenObtainPairView(TokenObtainPairView):
    """POST /api/auth/login/ — email + password login, honors remember_me."""

    serializer_class = CustomTokenObtainPairSerializer
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        return Response(
            {'success': True, 'message': 'Logged in successfully.', 'data': serializer.validated_data},
            status=status.HTTP_200_OK,
        )


class LogoutView(APIView):
    """POST /api/auth/logout/ — blacklists the refresh token so it can't be reused."""

    permission_classes = [IsAuthenticated]

    def post(self, request):
        refresh_token = request.data.get('refresh')
        if not refresh_token:
            return Response(
                {'success': False, 'message': 'Refresh token is required.'},
                status=status.HTTP_400_BAD_REQUEST,
            )
        try:
            token = RefreshToken(refresh_token)
            token.blacklist()
        except TokenError:
            return Response(
                {'success': False, 'message': 'Invalid or already expired token.'},
                status=status.HTTP_400_BAD_REQUEST,
            )
        return Response({'success': True, 'message': 'Logged out successfully.'}, status=status.HTTP_200_OK)


class ProfileView(generics.RetrieveUpdateAPIView):
    """GET/PATCH /api/auth/profile/ — view and edit the logged-in user's profile."""

    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def get_object(self):
        return self.request.user

    def update(self, request, *args, **kwargs):
        partial = True  # profile updates are always partial (PATCH-style)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({'success': True, 'message': 'Profile updated successfully.', 'data': serializer.data})


class ChangePasswordView(APIView):
    """POST /api/auth/change-password/"""

    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = ChangePasswordSerializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({'success': True, 'message': 'Password changed successfully.'})


class ForgotPasswordView(APIView):
    """POST /api/auth/forgot-password/ — issues a reset OTP if the email exists."""

    permission_classes = [AllowAny]

    def post(self, request):
        serializer = ForgotPasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.validated_data['email']

        user = User.objects.filter(email=email).first()
        if user:
            token = create_verification_token(user, purpose='reset_password')
            send_otp_email(user, token)

        # Same response whether or not the account exists — prevents email enumeration.
        return Response(
            {'success': True, 'message': 'If that email exists, a reset code has been sent.'}
        )


class ResetPasswordView(APIView):
    """POST /api/auth/reset-password/ — consumes the OTP and sets a new password."""

    permission_classes = [AllowAny]

    def post(self, request):
        serializer = ResetPasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({'success': True, 'message': 'Password reset successfully. You can now log in.'})


class VerifyEmailView(APIView):
    """POST /api/auth/verify-email/"""

    permission_classes = [AllowAny]

    def post(self, request):
        serializer = VerifyEmailSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({'success': True, 'message': 'Email verified successfully.'})


class ResendOTPView(APIView):
    """POST /api/auth/resend-otp/ — reissues a verification or password-reset code."""

    permission_classes = [AllowAny]

    def post(self, request):
        serializer = ResendOTPSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.validated_data['email']
        purpose = serializer.validated_data['purpose']

        user = User.objects.filter(email=email).first()
        if user:
            token = create_verification_token(user, purpose=purpose)
            send_otp_email(user, token)

        return Response({'success': True, 'message': 'If that email exists, a new code has been sent.'})


class ProfileSummaryView(APIView):
    """
    GET /api/auth/profile/summary/ — Phase 4 profile additions: financial
    goal summary, account statistics, and recent activity, combined into
    one call so the Profile page doesn't need to fan out to five endpoints.
    """

    permission_classes = [IsAuthenticated]

    def get(self, request):
        # Deferred imports — authentication is a foundational app that
        # other apps depend on, so it can't import them at module load time.
        from apps.expenses.models import Expense
        from apps.goals.services import get_goals_summary
        from apps.income.models import Income
        from apps.savings.services import get_total_savings

        user = request.user

        goal_summary = get_goals_summary(user)

        account_statistics = {
            'member_since': user.created_at.date(),
            'total_expenses_logged': Expense.objects.filter(user=user).count(),
            'total_income_logged': Income.objects.filter(user=user).count(),
            'lifetime_savings': get_total_savings(user),
            'is_email_verified': user.is_email_verified,
        }

        recent_expenses = [
            {'type': 'expense', 'title': e.title, 'amount': e.amount, 'date': e.expense_date}
            for e in Expense.objects.filter(user=user).order_by('-expense_date', '-created_at')[:5]
        ]
        recent_incomes = [
            {'type': 'income', 'title': i.get_source_display(), 'amount': i.amount, 'date': i.income_date}
            for i in Income.objects.filter(user=user).order_by('-income_date', '-created_at')[:5]
        ]
        recent_activity = sorted(recent_expenses + recent_incomes, key=lambda x: x['date'], reverse=True)[:8]

        return Response({
            'success': True,
            'data': {
                'goal_summary': goal_summary,
                'account_statistics': account_statistics,
                'recent_activity': recent_activity,
            },
        })
