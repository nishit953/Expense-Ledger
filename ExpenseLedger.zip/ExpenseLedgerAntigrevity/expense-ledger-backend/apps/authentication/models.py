import uuid

from django.contrib.auth.models import AbstractUser
from django.db import models


def avatar_upload_path(instance, filename):
    ext = filename.split('.')[-1]
    return f'avatars/{instance.id}/{uuid.uuid4().hex}.{ext}'


class User(AbstractUser):
    """
    Custom user model, keyed on email rather than username.

    AbstractUser is extended (rather than AbstractBaseUser) so we keep
    Django's built-in permission/group machinery for free, while adding
    the profile fields the frontend's Profile page needs.
    """

    email = models.EmailField(unique=True)
    phone_number = models.CharField(max_length=20, blank=True)
    bio = models.TextField(max_length=500, blank=True)
    avatar = models.ImageField(upload_to=avatar_upload_path, blank=True, null=True)

    # Phase 4 profile additions
    occupation = models.CharField(max_length=150, blank=True)
    monthly_income = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)

    is_email_verified = models.BooleanField(default=False)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']  # username kept internally, not user-facing

    class Meta:
        db_table = 'users'
        ordering = ['-created_at']

    def __str__(self):
        return self.email

    @property
    def full_name(self):
        return f'{self.first_name} {self.last_name}'.strip() or self.username


class EmailVerificationToken(models.Model):
    """One-time 6-digit OTP used for email verification and password reset."""

    PURPOSE_CHOICES = [
        ('verify_email', 'Verify Email'),
        ('reset_password', 'Reset Password'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='verification_tokens')
    code = models.CharField(max_length=6)
    purpose = models.CharField(max_length=20, choices=PURPOSE_CHOICES)
    is_used = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()

    class Meta:
        db_table = 'email_verification_tokens'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.user.email} — {self.purpose} — {self.code}'

    @property
    def is_expired(self):
        from django.utils import timezone
        return timezone.now() > self.expires_at
