from django.contrib.auth import authenticate
from django.contrib.auth.password_validation import validate_password
from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

from .models import EmailVerificationToken, User


class UserSerializer(serializers.ModelSerializer):
    """Read-only representation of a user, used for /profile/ and nested in auth responses."""

    full_name = serializers.CharField(read_only=True)

    class Meta:
        model = User
        fields = [
            'id', 'email', 'first_name', 'last_name', 'full_name',
            'phone_number', 'bio', 'avatar', 'occupation', 'monthly_income',
            'is_email_verified', 'created_at',
        ]
        read_only_fields = ['id', 'email', 'is_email_verified', 'created_at']

    def validate_phone_number(self, value):
        if value:
            import re
            cleaned = re.sub(r'\D', '', value)
            if len(cleaned) == 12 and cleaned.startswith('91'):
                cleaned = cleaned[2:]
            if len(cleaned) != 10:
                raise serializers.ValidationError('Phone number must be exactly 10 digits.')
            return cleaned
        return ''

    def validate_monthly_income(self, value):
        if value is not None and value < 0:
            raise serializers.ValidationError('Monthly income cannot be negative.')
        return value


class RegisterSerializer(serializers.ModelSerializer):
    full_name = serializers.CharField(write_only=True, max_length=150)
    phone_number = serializers.CharField(required=False, allow_blank=True, max_length=20)
    password = serializers.CharField(write_only=True, validators=[validate_password])
    confirm_password = serializers.CharField(write_only=True)
    accept_terms = serializers.BooleanField(write_only=True)

    class Meta:
        model = User
        fields = ['full_name', 'email', 'phone_number', 'password', 'confirm_password', 'accept_terms']

    def validate_phone_number(self, value):
        if value:
            import re
            cleaned = re.sub(r'\D', '', value)
            if len(cleaned) == 12 and cleaned.startswith('91'):
                cleaned = cleaned[2:]
            if len(cleaned) != 10:
                raise serializers.ValidationError('Phone number must be exactly 10 digits.')
            return cleaned
        return ''

    def validate_email(self, value):
        value = value.lower().strip()
        if User.objects.filter(email=value).exists():
            raise serializers.ValidationError('An account with this email already exists.')
        return value

    def validate_accept_terms(self, value):
        if not value:
            raise serializers.ValidationError('You must accept the Terms of Service to register.')
        return value

    def validate(self, attrs):
        if attrs['password'] != attrs['confirm_password']:
            raise serializers.ValidationError({'confirm_password': 'Passwords do not match.'})
        return attrs

    def create(self, validated_data):
        full_name = validated_data.pop('full_name').strip()
        validated_data.pop('confirm_password')
        validated_data.pop('accept_terms')

        name_parts = full_name.split(' ', 1)
        first_name = name_parts[0]
        last_name = name_parts[1] if len(name_parts) > 1 else ''

        user = User.objects.create_user(
            username=validated_data['email'],
            email=validated_data['email'],
            phone_number=validated_data.get('phone_number', ''),
            first_name=first_name,
            last_name=last_name,
            password=validated_data['password'],
        )
        return user


class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    """
    Extends SimpleJWT's login serializer to authenticate by email and to
    stretch the refresh token's lifetime when the client sends remember_me.
    """

    username_field = User.USERNAME_FIELD
    remember_me = serializers.BooleanField(required=False, default=False, write_only=True)

    def validate(self, attrs):
        email = attrs.get('email', '').lower().strip()
        password = attrs.get('password')
        remember_me = attrs.get('remember_me', False)

        user = authenticate(self.context['request'], username=email, password=password)
        if user is None:
            raise serializers.ValidationError('Incorrect email or password.')
        if not user.is_active:
            raise serializers.ValidationError('This account has been deactivated.')

        self.user = user
        data = {}
        refresh = self.get_token(self.user)

        if remember_me:
            from datetime import timedelta
            from django.conf import settings
            refresh.set_exp(lifetime=timedelta(days=settings.REMEMBER_ME_REFRESH_LIFETIME_DAYS))

        data['refresh'] = str(refresh)
        data['access'] = str(refresh.access_token)
        data['user'] = UserSerializer(self.user).data
        return data


class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(write_only=True)
    new_password = serializers.CharField(write_only=True, validators=[validate_password])
    confirm_new_password = serializers.CharField(write_only=True)

    def validate_old_password(self, value):
        user = self.context['request'].user
        if not user.check_password(value):
            raise serializers.ValidationError('Current password is incorrect.')
        return value

    def validate(self, attrs):
        if attrs['new_password'] != attrs['confirm_new_password']:
            raise serializers.ValidationError({'confirm_new_password': 'Passwords do not match.'})
        return attrs

    def save(self, **kwargs):
        user = self.context['request'].user
        user.set_password(self.validated_data['new_password'])
        user.save(update_fields=['password'])
        return user


class ForgotPasswordSerializer(serializers.Serializer):
    email = serializers.EmailField()

    def validate_email(self, value):
        value = value.lower().strip()
        # Deliberately does not raise if the user doesn't exist — avoids
        # leaking which emails are registered.
        return value


class ResetPasswordSerializer(serializers.Serializer):
    email = serializers.EmailField()
    code = serializers.CharField(max_length=6, min_length=6)
    new_password = serializers.CharField(write_only=True, validators=[validate_password])
    confirm_new_password = serializers.CharField(write_only=True)

    def validate(self, attrs):
        if attrs['new_password'] != attrs['confirm_new_password']:
            raise serializers.ValidationError({'confirm_new_password': 'Passwords do not match.'})

        try:
            user = User.objects.get(email=attrs['email'].lower().strip())
        except User.DoesNotExist:
            raise serializers.ValidationError({'email': 'Invalid email or code.'})

        try:
            token = EmailVerificationToken.objects.filter(
                user=user, purpose='reset_password', code=attrs['code'], is_used=False,
            ).latest('created_at')
        except EmailVerificationToken.DoesNotExist:
            raise serializers.ValidationError({'code': 'Invalid or expired code.'})

        if token.is_expired:
            raise serializers.ValidationError({'code': 'This code has expired. Request a new one.'})

        attrs['user'] = user
        attrs['token'] = token
        return attrs

    def save(self, **kwargs):
        user = self.validated_data['user']
        token = self.validated_data['token']
        user.set_password(self.validated_data['new_password'])
        user.save(update_fields=['password'])
        token.is_used = True
        token.save(update_fields=['is_used'])
        return user


class VerifyEmailSerializer(serializers.Serializer):
    email = serializers.EmailField()
    code = serializers.CharField(max_length=6, min_length=6)

    def validate(self, attrs):
        try:
            user = User.objects.get(email=attrs['email'].lower().strip())
        except User.DoesNotExist:
            raise serializers.ValidationError({'email': 'Invalid email or code.'})

        try:
            token = EmailVerificationToken.objects.filter(
                user=user, purpose='verify_email', code=attrs['code'], is_used=False,
            ).latest('created_at')
        except EmailVerificationToken.DoesNotExist:
            raise serializers.ValidationError({'code': 'Invalid or expired code.'})

        if token.is_expired:
            raise serializers.ValidationError({'code': 'This code has expired. Request a new one.'})

        attrs['user'] = user
        attrs['token'] = token
        return attrs

    def save(self, **kwargs):
        user = self.validated_data['user']
        token = self.validated_data['token']
        user.is_email_verified = True
        user.save(update_fields=['is_email_verified'])
        token.is_used = True
        token.save(update_fields=['is_used'])
        return user


class ResendOTPSerializer(serializers.Serializer):
    email = serializers.EmailField()
    purpose = serializers.ChoiceField(choices=['verify_email', 'reset_password'])
