from django.core.files.uploadedfile import SimpleUploadedFile
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase

from .models import EmailVerificationToken, User


class RegisterTests(APITestCase):
    def setUp(self):
        self.url = reverse('auth-register')
        self.payload = {
            'full_name': 'Aarav Sharma',
            'email': 'aarav@example.com',
            'phone_number': '+919876543210',
            'password': 'StrongPass123!',
            'confirm_password': 'StrongPass123!',
            'accept_terms': True,
        }

    def test_register_success(self):
        response = self.client.post(self.url, self.payload)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertTrue(User.objects.filter(email='aarav@example.com').exists())
        self.assertTrue(
            EmailVerificationToken.objects.filter(user__email='aarav@example.com', purpose='verify_email').exists()
        )

    def test_register_password_mismatch(self):
        self.payload['confirm_password'] = 'Different123!'
        response = self.client.post(self.url, self.payload)
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_register_duplicate_email(self):
        self.client.post(self.url, self.payload)
        response = self.client.post(self.url, self.payload)
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_register_requires_terms_acceptance(self):
        self.payload['accept_terms'] = False
        response = self.client.post(self.url, self.payload)
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)


class LoginTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username='aarav@example.com', email='aarav@example.com', password='StrongPass123!',
        )
        self.url = reverse('auth-login')

    def test_login_success(self):
        response = self.client.post(self.url, {'email': 'aarav@example.com', 'password': 'StrongPass123!'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('access', response.data['data'])
        self.assertIn('refresh', response.data['data'])

    def test_login_wrong_password(self):
        response = self.client.post(self.url, {'email': 'aarav@example.com', 'password': 'wrong'})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)


class ProfileTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username='aarav@example.com', email='aarav@example.com', password='StrongPass123!',
        )
        self.client.force_authenticate(user=self.user)
        self.url = reverse('auth-profile')

    def test_get_profile(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['email'], 'aarav@example.com')

    def test_update_profile(self):
        response = self.client.patch(self.url, {'bio': 'Building better spending habits.'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.user.refresh_from_db()
        self.assertEqual(self.user.bio, 'Building better spending habits.')

    def test_profile_requires_auth(self):
        self.client.force_authenticate(user=None)
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)


class EmailVerificationTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username='aarav@example.com', email='aarav@example.com', password='StrongPass123!',
        )

    def test_verify_email_success(self):
        from .utils import create_verification_token
        token = create_verification_token(self.user, purpose='verify_email')

        response = self.client.post(
            reverse('auth-verify-email'), {'email': self.user.email, 'code': token.code}
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.user.refresh_from_db()
        self.assertTrue(self.user.is_email_verified)

    def test_verify_email_wrong_code(self):
        response = self.client.post(
            reverse('auth-verify-email'), {'email': self.user.email, 'code': '000000'}
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)


class AvatarUploadTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='av@x.com', email='av@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)
        self.url = reverse('auth-profile')

    # A real, minimal 1x1 transparent PNG — the avatar field is a DRF
    # ImageField, which validates actual image content via Pillow (not
    # just the file extension, unlike the receipt field), so arbitrary
    # fake bytes are correctly rejected and won't do for this test.
    VALID_PNG_BYTES = (
        b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01'
        b'\x08\x06\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\nIDATx\x9cc\x00\x01'
        b'\x00\x00\x05\x00\x01\r\n-\xb4\x00\x00\x00\x00IEND\xaeB`\x82'
    )

    def test_avatar_upload_accepted(self):
        avatar = SimpleUploadedFile('avatar.png', self.VALID_PNG_BYTES, content_type='image/png')
        response = self.client.patch(self.url, {'avatar': avatar, 'bio': 'Testing avatar'}, format='multipart')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIsNotNone(response.data['data']['avatar'])

    def test_non_image_file_rejected_as_avatar(self):
        # Confirms the ImageField's content validation is genuinely active,
        # not just checking the file extension.
        fake = SimpleUploadedFile('avatar.png', b'not-actually-a-png', content_type='image/png')
        response = self.client.patch(self.url, {'avatar': fake}, format='multipart')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_profile_update_without_avatar_still_works(self):
        response = self.client.patch(self.url, {'bio': 'No avatar change'}, format='multipart')
        self.assertEqual(response.status_code, status.HTTP_200_OK)


class ProfileJSONContentTypeTests(APITestCase):
    """Regression test: same parser_classes bug as expenses — plain JSON PATCH to /profile/ was silently rejected."""

    def setUp(self):
        self.user = User.objects.create_user(username='pjson@x.com', email='pjson@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)

    def test_update_profile_via_json(self):
        response = self.client.patch(reverse('auth-profile'), {'bio': 'Updated via JSON'}, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['data']['bio'], 'Updated via JSON')
