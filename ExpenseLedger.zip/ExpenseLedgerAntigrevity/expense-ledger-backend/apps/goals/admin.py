from django.contrib import admin

from .models import Goal, GoalContribution


class GoalContributionInline(admin.TabularInline):
    model = GoalContribution
    extra = 0


@admin.register(Goal)
class GoalAdmin(admin.ModelAdmin):
    list_display = ['name', 'user', 'category', 'target_amount', 'saved_amount', 'status', 'target_date']
    list_filter = ['category', 'priority', 'status']
    search_fields = ['name', 'user__email']
    inlines = [GoalContributionInline]


@admin.register(GoalContribution)
class GoalContributionAdmin(admin.ModelAdmin):
    list_display = ['goal', 'amount', 'date']
    list_filter = ['date']
    search_fields = ['goal__name']
