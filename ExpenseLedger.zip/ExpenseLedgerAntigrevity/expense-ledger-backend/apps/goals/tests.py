from datetime import date, timedelta

from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase

from apps.authentication.models import User
from .models import Goal


class GoalTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='a@x.com', email='a@x.com', password='StrongPass123!')
        self.other_user = User.objects.create_user(username='b@x.com', email='b@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)
        self.list_url = reverse('goal-list')

        self.goal = Goal.objects.create(
            user=self.user, name='Emergency Fund', category='emergency_fund',
            target_amount=100000, target_date=date.today() + timedelta(days=180),
        )

    def test_create_goal(self):
        payload = {
            'name': 'Japan Trip', 'category': 'vacation', 'target_amount': '250000.00',
            'target_date': (date.today() + timedelta(days=300)).isoformat(),
        }
        response = self.client.post(self.list_url, payload)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_list_only_returns_own_goals(self):
        Goal.objects.create(user=self.other_user, name='Car', category='buy_car', target_amount=500000, target_date=date.today())
        response = self.client.get(self.list_url)
        self.assertEqual(response.data['count'], 1)

    def test_contribute_updates_saved_amount(self):
        url = reverse('goal-contribute', args=[self.goal.id])
        response = self.client.post(url, {'amount': '5000.00', 'date': date.today().isoformat()})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.goal.refresh_from_db()
        self.assertEqual(self.goal.saved_amount, 5000)

    def test_contribution_completes_goal_when_target_reached(self):
        url = reverse('goal-contribute', args=[self.goal.id])
        self.client.post(url, {'amount': '100000.00', 'date': date.today().isoformat()})
        self.goal.refresh_from_db()
        self.assertEqual(self.goal.status, 'completed')

    def test_progress_percentage_capped_at_100(self):
        url = reverse('goal-contribute', args=[self.goal.id])
        self.client.post(url, {'amount': '150000.00', 'date': date.today().isoformat()})
        response = self.client.get(reverse('goal-detail', args=[self.goal.id]))
        self.assertEqual(response.data['progress_percentage'], 100)

    def test_abandon_and_reactivate(self):
        abandon_url = reverse('goal-abandon', args=[self.goal.id])
        response = self.client.post(abandon_url)
        self.assertEqual(response.data['data']['status'], 'abandoned')

        reactivate_url = reverse('goal-reactivate', args=[self.goal.id])
        response = self.client.post(reactivate_url)
        self.assertEqual(response.data['data']['status'], 'active')

    def test_cannot_access_other_users_goal(self):
        other_goal = Goal.objects.create(user=self.other_user, name='Car', category='buy_car', target_amount=500000, target_date=date.today())
        response = self.client.get(reverse('goal-detail', args=[other_goal.id]))
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
