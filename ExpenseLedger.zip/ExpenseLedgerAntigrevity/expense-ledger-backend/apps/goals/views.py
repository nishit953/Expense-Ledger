import django_filters
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from .models import Goal
from .permissions import IsOwner
from .serializers import AddContributionSerializer, GoalDetailSerializer, GoalSerializer
from .services import add_contribution, get_goals_summary


class GoalFilter(django_filters.FilterSet):
    target_date_from = django_filters.DateFilter(field_name='target_date', lookup_expr='gte')
    target_date_to = django_filters.DateFilter(field_name='target_date', lookup_expr='lte')

    class Meta:
        model = Goal
        fields = ['category', 'priority', 'status', 'target_date_from', 'target_date_to']


class GoalViewSet(viewsets.ModelViewSet):
    """
    Full CRUD for financial goals, scoped to the logged-in user.

    Extra actions:
    - POST /goals/{id}/contribute/  — log a savings contribution toward the goal
    - POST /goals/{id}/abandon/     — mark an active goal as abandoned
    - POST /goals/{id}/reactivate/  — bring an abandoned goal back to active
    """

    permission_classes = [IsAuthenticated, IsOwner]
    filterset_class = GoalFilter
    search_fields = ['name', 'description']
    ordering_fields = ['target_date', 'target_amount', 'saved_amount', 'priority', 'created_at']
    ordering = ['-priority', 'target_date']

    def get_queryset(self):
        return Goal.objects.filter(user=self.request.user).prefetch_related('contributions')

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return GoalDetailSerializer
        return GoalSerializer

    @action(detail=True, methods=['post'])
    def contribute(self, request, pk=None):
        goal = self.get_object()
        serializer = AddContributionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        add_contribution(
            goal,
            amount=serializer.validated_data['amount'],
            contribution_date=serializer.validated_data['date'],
            note=serializer.validated_data.get('note', ''),
        )
        goal.refresh_from_db()
        return Response(
            {'success': True, 'message': 'Contribution added.', 'data': GoalDetailSerializer(goal).data}
        )

    @action(detail=True, methods=['post'])
    def abandon(self, request, pk=None):
        goal = self.get_object()
        goal.status = 'abandoned'
        goal.save(update_fields=['status', 'updated_at'])
        return Response({'success': True, 'message': 'Goal marked as abandoned.', 'data': GoalSerializer(goal).data})

    @action(detail=True, methods=['post'])
    def reactivate(self, request, pk=None):
        goal = self.get_object()
        goal.status = 'active'
        goal.save(update_fields=['status', 'updated_at'])
        return Response({'success': True, 'message': 'Goal reactivated.', 'data': GoalSerializer(goal).data})

    @action(detail=False, methods=['get'])
    def summary(self, request):
        return Response({'success': True, 'data': get_goals_summary(request.user)})
