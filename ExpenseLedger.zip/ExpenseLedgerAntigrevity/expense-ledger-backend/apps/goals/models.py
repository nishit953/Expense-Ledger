from django.conf import settings
from decimal import Decimal

from django.core.validators import MinValueValidator
from django.db import models


class Goal(models.Model):
    CATEGORY_CHOICES = [
        ('emergency_fund', 'Emergency Fund'),
        ('buy_car', 'Buy a Car'),
        ('buy_house', 'Buy a House'),
        ('vacation', 'Vacation'),
        ('education', 'Education'),
        ('wedding', 'Wedding'),
        ('business', 'Business'),
        ('custom', 'Custom Goal'),
    ]

    PRIORITY_CHOICES = [
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
    ]

    STATUS_CHOICES = [
        ('active', 'Active'),
        ('completed', 'Completed'),
        ('abandoned', 'Abandoned'),
    ]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='goals')

    name = models.CharField(max_length=200)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default='custom')
    target_amount = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal('0.01'))])

    # Updated by services.add_contribution() whenever a contribution is
    # logged — stored (not purely derived) so the field can be read cheaply
    # in list views without summing contributions on every request.
    saved_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    target_date = models.DateField()
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='medium')
    description = models.CharField(max_length=1000, blank=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='active', db_index=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'goals'
        ordering = ['-priority', 'target_date']
        indexes = [
            models.Index(fields=['user', 'status']),
        ]

    def __str__(self):
        return f'{self.name} — ₹{self.saved_amount}/{self.target_amount}'


class GoalContribution(models.Model):
    """A single deposit toward a goal — the goal's savings history."""

    goal = models.ForeignKey(Goal, on_delete=models.CASCADE, related_name='contributions')
    amount = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal('0.01'))])
    date = models.DateField()
    note = models.CharField(max_length=300, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'goal_contributions'
        ordering = ['-date', '-created_at']

    def __str__(self):
        return f'{self.goal.name} +₹{self.amount} on {self.date}'
