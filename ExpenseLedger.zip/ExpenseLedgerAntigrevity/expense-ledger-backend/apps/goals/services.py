from datetime import date
from decimal import Decimal

from django.db import transaction


def get_progress_percentage(goal):
    if goal.target_amount <= 0:
        return 0.0
    return round(min(float(goal.saved_amount) / float(goal.target_amount) * 100, 100), 1)


def get_days_remaining(goal, today=None):
    today = today or date.today()
    return (goal.target_date - today).days


def get_goal_status_label(goal, today=None):
    """Human-facing status, distinct from the stored `status` field — flags
    an active goal as overdue without changing its persisted state."""
    if goal.status != 'active':
        return goal.status
    days_remaining = get_days_remaining(goal, today)
    if days_remaining < 0:
        return 'overdue'
    return 'active'


@transaction.atomic
def add_contribution(goal, amount, contribution_date, note=''):
    """Logs a contribution and updates the goal's saved_amount + status atomically."""
    from .models import GoalContribution

    contribution = GoalContribution.objects.create(
        goal=goal, amount=amount, date=contribution_date, note=note
    )

    was_active = goal.status == 'active'
    goal.saved_amount = goal.saved_amount + Decimal(amount)
    if goal.saved_amount >= goal.target_amount and was_active:
        goal.status = 'completed'
    goal.save(update_fields=['saved_amount', 'status', 'updated_at'])

    if was_active and goal.status == 'completed':
        # Deferred import — notifications depends on goals for reminders,
        # so goals can't import notifications at module load time.
        from apps.notifications.services import notify_success
        notify_success(
            goal.user,
            title=f'Goal reached: {goal.name}',
            message=f'You hit your {goal.name} target of ₹{goal.target_amount}. 🎉',
            category='goal_reminder',
        )

    return contribution


def get_goals_summary(user):
    """Aggregate goal stats — used by the Profile page and Reports module."""
    from .models import Goal

    goals = Goal.objects.filter(user=user)
    active = goals.filter(status='active')
    completed = goals.filter(status='completed')

    total_target = sum((g.target_amount for g in goals), Decimal('0'))
    total_saved = sum((g.saved_amount for g in goals), Decimal('0'))

    return {
        'total_goals': goals.count(),
        'active_goals': active.count(),
        'completed_goals': completed.count(),
        'total_target_amount': total_target,
        'total_saved_amount': total_saved,
        'overall_progress': round(float(total_saved) / float(total_target) * 100, 1) if total_target else 0.0,
    }
