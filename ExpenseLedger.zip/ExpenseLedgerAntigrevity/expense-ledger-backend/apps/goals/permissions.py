from rest_framework.permissions import BasePermission


class IsOwner(BasePermission):
    """Object-level permission: only the record's owner may read/write it."""

    def has_object_permission(self, request, view, obj):
        owner_id = obj.user_id if hasattr(obj, 'user_id') else obj.goal.user_id
        return owner_id == request.user.id
