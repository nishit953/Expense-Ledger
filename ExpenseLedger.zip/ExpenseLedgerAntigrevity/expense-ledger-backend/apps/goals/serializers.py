from decimal import Decimal

from rest_framework import serializers

from .models import Goal, GoalContribution
from .services import get_days_remaining, get_goal_status_label, get_progress_percentage


class GoalContributionSerializer(serializers.ModelSerializer):
    class Meta:
        model = GoalContribution
        fields = ['id', 'amount', 'date', 'note', 'created_at']
        read_only_fields = ['id', 'created_at']


class GoalSerializer(serializers.ModelSerializer):
    category_display = serializers.CharField(source='get_category_display', read_only=True)
    priority_display = serializers.CharField(source='get_priority_display', read_only=True)
    progress_percentage = serializers.SerializerMethodField()
    days_remaining = serializers.SerializerMethodField()
    status_label = serializers.SerializerMethodField()

    class Meta:
        model = Goal
        fields = [
            'id', 'name', 'category', 'category_display', 'target_amount', 'saved_amount',
            'target_date', 'priority', 'priority_display', 'description', 'status', 'status_label',
            'progress_percentage', 'days_remaining', 'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'saved_amount', 'status', 'created_at', 'updated_at']

    def get_progress_percentage(self, obj):
        return get_progress_percentage(obj)

    def get_days_remaining(self, obj):
        return get_days_remaining(obj)

    def get_status_label(self, obj):
        return get_goal_status_label(obj)

    def create(self, validated_data):
        validated_data['user'] = self.context['request'].user
        return super().create(validated_data)


class GoalDetailSerializer(GoalSerializer):
    """Adds the full contribution history — used on the goal detail view."""

    contributions = GoalContributionSerializer(many=True, read_only=True)

    class Meta(GoalSerializer.Meta):
        fields = GoalSerializer.Meta.fields + ['contributions']


class AddContributionSerializer(serializers.Serializer):
    amount = serializers.DecimalField(max_digits=12, decimal_places=2, min_value=Decimal('0.01'))
    date = serializers.DateField()
    note = serializers.CharField(max_length=300, required=False, allow_blank=True)
