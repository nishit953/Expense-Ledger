from datetime import date

from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase

from apps.authentication.models import User
from .models import Income


class IncomeTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='a@x.com', email='a@x.com', password='StrongPass123!')
        self.other_user = User.objects.create_user(username='b@x.com', email='b@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)
        self.list_url = reverse('income-list')

        self.income = Income.objects.create(
            user=self.user, source='salary', amount=84000, income_date=date(2026, 6, 1),
        )

    def test_list_only_returns_own_income(self):
        Income.objects.create(user=self.other_user, source='bonus', amount=5000, income_date=date(2026, 6, 1))
        response = self.client.get(self.list_url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)

    def test_create_income(self):
        payload = {'source': 'freelancing', 'amount': '12000.00', 'income_date': '2026-06-10'}
        response = self.client.post(self.list_url, payload)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Income.objects.filter(user=self.user).count(), 2)

    def test_recurring_requires_frequency(self):
        payload = {'source': 'rental', 'amount': '20000.00', 'income_date': '2026-06-01', 'is_recurring': True}
        response = self.client.post(self.list_url, payload)
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_cannot_access_other_users_income(self):
        other_income = Income.objects.create(user=self.other_user, source='bonus', amount=5000, income_date=date(2026, 6, 1))
        url = reverse('income-detail', args=[other_income.id])
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_update_income(self):
        url = reverse('income-detail', args=[self.income.id])
        response = self.client.patch(url, {'amount': '90000.00'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.income.refresh_from_db()
        self.assertEqual(str(self.income.amount), '90000.00')
