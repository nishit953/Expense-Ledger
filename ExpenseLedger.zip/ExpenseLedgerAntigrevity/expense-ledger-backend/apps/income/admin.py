from django.contrib import admin

from .models import Income


@admin.register(Income)
class IncomeAdmin(admin.ModelAdmin):
    list_display = ['source', 'user', 'amount', 'income_date', 'is_recurring']
    list_filter = ['source', 'is_recurring', 'income_date']
    search_fields = ['description', 'user__email']
    date_hierarchy = 'income_date'
