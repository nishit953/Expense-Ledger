import django_filters
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated

from .models import Income
from .permissions import IsOwner
from .serializers import IncomeSerializer


class IncomeFilter(django_filters.FilterSet):
    date_from = django_filters.DateFilter(field_name='income_date', lookup_expr='gte')
    date_to = django_filters.DateFilter(field_name='income_date', lookup_expr='lte')
    amount_min = django_filters.NumberFilter(field_name='amount', lookup_expr='gte')
    amount_max = django_filters.NumberFilter(field_name='amount', lookup_expr='lte')

    class Meta:
        model = Income
        fields = ['source', 'is_recurring', 'date_from', 'date_to', 'amount_min', 'amount_max']


class IncomeViewSet(viewsets.ModelViewSet):
    """Full CRUD for income entries, scoped to the logged-in user."""

    serializer_class = IncomeSerializer
    permission_classes = [IsAuthenticated, IsOwner]
    filterset_class = IncomeFilter
    search_fields = ['description']
    ordering_fields = ['amount', 'income_date', 'created_at']
    ordering = ['-income_date']

    def get_queryset(self):
        return Income.objects.filter(user=self.request.user)
