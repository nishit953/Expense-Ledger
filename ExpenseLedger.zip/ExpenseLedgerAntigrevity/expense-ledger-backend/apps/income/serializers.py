from rest_framework import serializers

from .models import Income


class IncomeSerializer(serializers.ModelSerializer):
    source_display = serializers.CharField(source='get_source_display', read_only=True)

    class Meta:
        model = Income
        fields = [
            'id', 'source', 'source_display', 'amount', 'income_date', 'description',
            'is_recurring', 'recurring_frequency', 'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']

    def validate(self, attrs):
        is_recurring = attrs.get('is_recurring', getattr(self.instance, 'is_recurring', False))
        frequency = attrs.get('recurring_frequency', getattr(self.instance, 'recurring_frequency', None))
        if is_recurring and not frequency:
            raise serializers.ValidationError(
                {'recurring_frequency': 'Select a frequency for recurring income.'}
            )
        if not is_recurring:
            attrs['recurring_frequency'] = None
        return attrs

    def create(self, validated_data):
        validated_data['user'] = self.context['request'].user
        return super().create(validated_data)
