from django.conf import settings
from decimal import Decimal

from django.core.validators import MinValueValidator
from django.db import models


class Income(models.Model):
    SOURCE_CHOICES = [
        ('salary', 'Salary'),
        ('freelancing', 'Freelancing'),
        ('business', 'Business'),
        ('rental', 'Rental'),
        ('interest', 'Interest'),
        ('bonus', 'Bonus'),
        ('other', 'Other'),
    ]

    RECURRING_FREQUENCY_CHOICES = [
        ('daily', 'Daily'),
        ('weekly', 'Weekly'),
        ('monthly', 'Monthly'),
        ('yearly', 'Yearly'),
    ]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='incomes')

    source = models.CharField(max_length=20, choices=SOURCE_CHOICES, db_index=True)
    amount = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal('0.01'))])
    income_date = models.DateField(db_index=True)
    description = models.CharField(max_length=500, blank=True)

    is_recurring = models.BooleanField(default=False)
    recurring_frequency = models.CharField(
        max_length=10, choices=RECURRING_FREQUENCY_CHOICES, blank=True, null=True
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'incomes'
        ordering = ['-income_date', '-created_at']
        indexes = [
            models.Index(fields=['user', 'income_date']),
            models.Index(fields=['user', 'source']),
        ]

    def __str__(self):
        return f'{self.get_source_display()} — ₹{self.amount}'
