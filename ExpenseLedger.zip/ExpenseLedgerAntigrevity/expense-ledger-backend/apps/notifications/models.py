from django.conf import settings
from django.db import models


class Notification(models.Model):
    TYPE_CHOICES = [
        ('success', 'Success'),
        ('warning', 'Warning'),
        ('info', 'Info'),
        ('reminder', 'Reminder'),
    ]

    CATEGORY_CHOICES = [
        ('budget_alert', 'Budget Alert'),
        ('goal_reminder', 'Goal Reminder'),
        ('monthly_reminder', 'Monthly Reminder'),
        ('bill_reminder', 'Bill Reminder'),
        ('low_savings_alert', 'Low Savings Alert'),
        ('general', 'General'),
    ]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notifications')

    type = models.CharField(max_length=10, choices=TYPE_CHOICES, default='info')
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default='general')
    title = models.CharField(max_length=200)
    message = models.CharField(max_length=500)

    # A stable key so services.py can avoid creating duplicate alerts for
    # the same underlying condition (e.g. one "budget exceeded" notice per
    # budget per month, not one per request).
    dedupe_key = models.CharField(max_length=255, blank=True, db_index=True)

    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'notifications'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['user', 'is_read']),
        ]

    def __str__(self):
        return f'[{self.type}] {self.title}'
