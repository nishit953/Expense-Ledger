from rest_framework.routers import DefaultRouter

from .views import GenerateNotificationsView, NotificationViewSet
from django.urls import path

router = DefaultRouter()
router.register('', NotificationViewSet, basename='notification')

urlpatterns = [
    path('generate/', GenerateNotificationsView.as_view(), name='notification-generate'),
] + router.urls
