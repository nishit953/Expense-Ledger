import django_filters
from rest_framework import mixins, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Notification
from .permissions import IsOwner
from .serializers import NotificationSerializer
from .services import run_notification_checks


class NotificationFilter(django_filters.FilterSet):
    class Meta:
        model = Notification
        fields = ['type', 'category', 'is_read']


class NotificationViewSet(
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.DestroyModelMixin,
    viewsets.GenericViewSet,
):
    """
    Notifications are system-generated, not user-created — so this viewset
    intentionally omits create/update, only list/retrieve/delete plus the
    mark-as-read action below.
    """

    serializer_class = NotificationSerializer
    permission_classes = [IsAuthenticated, IsOwner]
    filterset_class = NotificationFilter
    ordering_fields = ['created_at']
    ordering = ['-created_at']

    def get_queryset(self):
        return Notification.objects.filter(user=self.request.user)

    @action(detail=True, methods=['put', 'patch'], url_path='read')
    def mark_read(self, request, pk=None):
        notification = self.get_object()
        notification.is_read = True
        notification.save(update_fields=['is_read'])
        return Response({'success': True, 'data': NotificationSerializer(notification).data})

    @action(detail=False, methods=['post'], url_path='mark-all-read')
    def mark_all_read(self, request):
        updated = self.get_queryset().filter(is_read=False).update(is_read=True)
        return Response({'success': True, 'message': f'{updated} notification(s) marked as read.'})

    @action(detail=False, methods=['get'], url_path='unread-count')
    def unread_count(self, request):
        count = self.get_queryset().filter(is_read=False).count()
        return Response({'success': True, 'data': {'unread_count': count}})


class GenerateNotificationsView(APIView):
    """POST /api/notifications/generate/ — runs the rule-based checks on demand (no task queue in this phase)."""

    permission_classes = [IsAuthenticated]

    def post(self, request):
        created = run_notification_checks(request.user)
        return Response({
            'success': True,
            'message': f'{len(created)} new notification(s) generated.',
            'data': NotificationSerializer(created, many=True).data,
        })
