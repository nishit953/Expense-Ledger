from datetime import date

from django.utils import timezone


def _create_if_new(user, dedupe_key, **kwargs):
    """Creates a notification only if one with the same dedupe_key doesn't already exist — keeps repeated checks idempotent."""
    from .models import Notification

    if Notification.objects.filter(user=user, dedupe_key=dedupe_key).exists():
        return None
    return Notification.objects.create(user=user, dedupe_key=dedupe_key, **kwargs)


def notify_success(user, title, message, category='general'):
    """Immediate, one-off success notification — called directly at the moment of an achievement (e.g. goal completed)."""
    from .models import Notification

    return Notification.objects.create(
        user=user, type='success', category=category, title=title, message=message,
    )


def check_budget_alerts(user, today=None):
    """One notification per over-threshold budget per month."""
    from apps.budgets.models import Budget
    from apps.budgets.services import annotate_budget
    from apps.settings_app.services import get_or_create_settings

    if not get_or_create_settings(user).notify_budget_alerts:
        return []

    today = today or date.today()
    month = today.replace(day=1)
    created = []

    for budget in Budget.objects.filter(user=user, month=month):
        annotated = annotate_budget(budget)
        if annotated['status'] == 'exceeded':
            key = f'budget-exceeded-{budget.id}-{month.isoformat()}'
            n = _create_if_new(
                user, key, type='warning', category='budget_alert',
                title=f'{budget.get_category_display()} budget exceeded',
                message=f'You\'ve spent {annotated["percentage_used"]}% of your {budget.get_category_display()} budget for {month.strftime("%B")}.',
            )
        elif annotated['status'] == 'warning':
            key = f'budget-warning-{budget.id}-{month.isoformat()}'
            n = _create_if_new(
                user, key, type='warning', category='budget_alert',
                title=f'Nearing your {budget.get_category_display()} budget limit',
                message=f'You\'ve used {annotated["percentage_used"]}% of your {budget.get_category_display()} budget for {month.strftime("%B")}.',
            )
        else:
            n = None
        if n:
            created.append(n)
    return created


def check_goal_reminders(user, days_threshold=14, today=None):
    """One reminder per active goal whose deadline is within `days_threshold` days."""
    from apps.goals.models import Goal
    from apps.goals.services import get_days_remaining
    from apps.settings_app.services import get_or_create_settings

    if not get_or_create_settings(user).notify_goal_reminders:
        return []

    today = today or date.today()
    created = []

    for goal in Goal.objects.filter(user=user, status='active'):
        days_remaining = get_days_remaining(goal, today)
        if 0 <= days_remaining <= days_threshold:
            key = f'goal-reminder-{goal.id}-{today.isoformat()}'
            n = _create_if_new(
                user, key, type='reminder', category='goal_reminder',
                title=f'"{goal.name}" deadline approaching',
                message=f'{days_remaining} day(s) left to reach your {goal.name} goal.',
            )
            if n:
                created.append(n)
    return created


def check_bill_reminders(user, days_threshold=3, today=None):
    """Reminder for recurring expenses (bills) due within `days_threshold` days."""
    from apps.dashboard.services import get_upcoming_bills
    from apps.settings_app.services import get_or_create_settings

    if not get_or_create_settings(user).notify_bill_reminders:
        return []

    today = today or date.today()
    created = []

    for bill in get_upcoming_bills(user, days_ahead=days_threshold, today=today):
        key = f'bill-{bill["title"]}-{bill["category"]}-{bill["due_date"].isoformat()}'
        n = _create_if_new(
            user, key, type='reminder', category='bill_reminder',
            title=f'{bill["title"]} due soon',
            message=f'₹{bill["amount"]} due on {bill["due_date"].strftime("%d %b")}.',
        )
        if n:
            created.append(n)
    return created


def check_low_savings_alert(user, threshold_percent=10, today=None):
    """One alert per month if this month's savings rate falls below the threshold."""
    from apps.dashboard.services import get_financial_health_score
    from apps.settings_app.services import get_or_create_settings

    if not get_or_create_settings(user).notify_low_savings_alerts:
        return []

    today = today or date.today()
    health = get_financial_health_score(user, today)
    created = []

    if health['savings_rate'] < threshold_percent:
        key = f'low-savings-{user.id}-{today.strftime("%Y-%m")}'
        n = _create_if_new(
            user, key, type='warning', category='low_savings_alert',
            title='Savings rate is low this month',
            message=f'You\'ve saved {health["savings_rate"]}% of your income this month — below your {threshold_percent}% target.',
        )
        if n:
            created.append(n)
    return created


def check_monthly_reminder(user, trigger_day=25, today=None):
    """A single nudge each month (from `trigger_day` onward) to review finances."""
    from apps.settings_app.services import get_or_create_settings

    if not get_or_create_settings(user).notify_monthly_summary:
        return []

    today = today or date.today()
    created = []

    if today.day >= trigger_day:
        key = f'monthly-reminder-{user.id}-{today.strftime("%Y-%m")}'
        n = _create_if_new(
            user, key, type='info', category='monthly_reminder',
            title='Time for your monthly review',
            message=f'{today.strftime("%B")} is wrapping up — review your budgets, goals, and savings.',
        )
        if n:
            created.append(n)
    return created


def run_notification_checks(user, today=None):
    """Runs every rule-based check — called on demand (e.g. dashboard load) rather than on a schedule, since this phase has no task queue."""
    today = today or timezone.localdate()
    created = []
    created += check_budget_alerts(user, today)
    created += check_goal_reminders(user, today=today)
    created += check_bill_reminders(user, today=today)
    created += check_low_savings_alert(user, today=today)
    created += check_monthly_reminder(user, today=today)
    return created
