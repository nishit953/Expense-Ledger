from datetime import date, timedelta

from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase

from apps.authentication.models import User
from apps.budgets.models import Budget
from apps.expenses.models import Expense
from apps.goals.models import Goal
from .models import Notification
from .services import check_budget_alerts, check_goal_reminders, run_notification_checks


class NotificationServiceTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='a@x.com', email='a@x.com', password='StrongPass123!')

    def test_budget_alert_created_when_exceeded(self):
        today = date.today()
        Budget.objects.create(user=self.user, category='food', monthly_limit=1000, month=today.replace(day=1))
        Expense.objects.create(user=self.user, title='Big spend', category='food', amount=1500, payment_method='upi', expense_date=today)

        created = check_budget_alerts(self.user, today)
        self.assertEqual(len(created), 1)
        self.assertEqual(created[0].category, 'budget_alert')

    def test_budget_alert_not_duplicated(self):
        today = date.today()
        Budget.objects.create(user=self.user, category='food', monthly_limit=1000, month=today.replace(day=1))
        Expense.objects.create(user=self.user, title='Big spend', category='food', amount=1500, payment_method='upi', expense_date=today)

        check_budget_alerts(self.user, today)
        second_run = check_budget_alerts(self.user, today)
        self.assertEqual(len(second_run), 0)
        self.assertEqual(Notification.objects.filter(user=self.user).count(), 1)

    def test_goal_reminder_within_threshold(self):
        today = date.today()
        Goal.objects.create(
            user=self.user, name='Trip', category='vacation', target_amount=10000,
            target_date=today + timedelta(days=5),
        )
        created = check_goal_reminders(self.user, days_threshold=14, today=today)
        self.assertEqual(len(created), 1)

    def test_run_all_checks_does_not_error(self):
        created = run_notification_checks(self.user)
        self.assertIsInstance(created, list)


class NotificationEndpointTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='b@x.com', email='b@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)
        self.notification = Notification.objects.create(
            user=self.user, type='info', category='general', title='Welcome', message='Hi there',
        )

    def test_list_notifications(self):
        response = self.client.get(reverse('notification-list'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)

    def test_mark_as_read(self):
        url = reverse('notification-mark-read', args=[self.notification.id])
        response = self.client.patch(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.notification.refresh_from_db()
        self.assertTrue(self.notification.is_read)

    def test_unread_count(self):
        response = self.client.get(reverse('notification-unread-count'))
        self.assertEqual(response.data['data']['unread_count'], 1)

    def test_delete_notification(self):
        url = reverse('notification-detail', args=[self.notification.id])
        response = self.client.delete(url)
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)

    def test_generate_endpoint(self):
        response = self.client.post(reverse('notification-generate'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_page_size_query_param_is_honored(self):
        # Regression test: DRF's default PageNumberPagination silently
        # ignores ?page_size= unless page_size_query_param is configured.
        # The frontend notification bell relies on this working.
        for i in range(15):
            Notification.objects.create(
                user=self.user, type='info', category='general', title=f'Note {i}', message='x',
            )
        response = self.client.get(reverse('notification-list'), {'page_size': 20})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 16)  # 15 new + 1 from setUp
