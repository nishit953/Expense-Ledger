"""
Manual retraining entrypoint — there's no task queue in this project (same
precedent as notifications/services.py::run_notification_checks), so
training is a deliberate CLI action, not a scheduled job.

Usage (once there's data worth training on — NOT run as part of this
infrastructure setup):
    python manage.py train_ml_models --model category_classifier
    python manage.py train_ml_models --model all
"""
from django.core.management.base import BaseCommand, CommandError

TRAINERS = {
    'category_classifier': 'apps.ml.pipeline.train_category_classifier',
    'budget_risk_model': 'apps.ml.pipeline.train_budget_risk_model',
    'expense_forecaster': 'apps.ml.pipeline.train_expense_forecaster',
    'anomaly_detector': 'apps.ml.pipeline.train_anomaly_detector',
    'goal_forecaster': 'apps.ml.pipeline.train_goal_forecaster',
}


class Command(BaseCommand):
    help = 'Trains one or all ExpenseLedger ML models and logs the result to MLModelVersion.'

    def add_arguments(self, parser):
        parser.add_argument(
            '--model', type=str, default='all',
            choices=list(TRAINERS.keys()) + ['all'],
            help='Which model to train. Defaults to "all".',
        )

    def handle(self, *args, **options):
        import importlib

        selected = options['model']
        targets = list(TRAINERS.keys()) if selected == 'all' else [selected]

        for model_name in targets:
            module_path = TRAINERS[model_name]
            self.stdout.write(f'Training {model_name}...')
            try:
                module = importlib.import_module(module_path)
                result = module.train()
            except Exception as exc:
                raise CommandError(f'{model_name} training failed: {exc}') from exc

            if result is None:
                self.stdout.write(self.style.WARNING(
                    f'{model_name}: skipped (not enough data yet — see log output above).'
                ))
            else:
                self.stdout.write(self.style.SUCCESS(f'{model_name}: done. {result}'))
