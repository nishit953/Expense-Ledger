"""
Thin orchestration layer bridging Django (MLModelVersion) and the
framework-agnostic pipeline/ package.

Training scripts call `record_version()` after saving an artifact.
Prediction scripts call `get_active_model_path()` before loading one.
Neither `pipeline/` module imports Django directly — this file is the
only place that does, keeping the ML code testable outside a Django
request/response cycle.
"""
from django.utils import timezone


def record_version(model_name, file_path, training_samples=0, metric_name='', metric_value=None, notes='', activate=True):
    """Logs a newly trained artifact and, by default, makes it the active version for its model_name."""
    from .models import MLModelVersion

    version_label = timezone.now().strftime('%Y-%m-%dT%H-%M-%S')

    entry = MLModelVersion.objects.create(
        model_name=model_name,
        version=version_label,
        file_path=file_path,
        training_samples=training_samples,
        metric_name=metric_name,
        metric_value=metric_value,
        notes=notes,
        is_active=False,
    )

    if activate:
        entry = activate_version(entry.id)

    return entry


def activate_version(version_id):
    """Marks one version active for its model_name, deactivating any previous active version."""
    from .models import MLModelVersion

    entry = MLModelVersion.objects.get(id=version_id)
    MLModelVersion.objects.filter(model_name=entry.model_name, is_active=True).update(is_active=False)
    entry.is_active = True
    entry.save(update_fields=['is_active'])
    return entry


def get_active_version(model_name):
    """Returns the active MLModelVersion row for a model, or None if nothing has been trained yet."""
    from .models import MLModelVersion

    return MLModelVersion.objects.filter(model_name=model_name, is_active=True).first()


def get_active_model_path(model_name):
    """Convenience wrapper for prediction scripts — returns just the artifact path, or None."""
    version = get_active_version(model_name)
    return version.file_path if version else None


def has_trained_model(model_name):
    """Lets prediction scripts cheaply check whether to even attempt loading a model before falling back."""
    return get_active_version(model_name) is not None


# --- Bridge functions: shape Django ORM data into exactly what each ---
# --- pipeline predict_*() function expects. Views stay thin by calling ---
# --- these rather than assembling feature payloads inline. ---

def get_user_monthly_history(user, months=12):
    """
    Gap-filled monthly expense totals for one user, most recent last —
    the exact shape predict_expense_forecast.predict_next_month_expense()
    expects. Uses the SAME gap-filling helper training uses, so a
    prediction is never built from data shaped differently than what the
    model learned from.
    """
    from .pipeline import data_loader
    from .pipeline.preprocessing import fill_missing_months

    df = data_loader.load_monthly_expense_totals(user=user)
    if df.empty:
        return []

    collapsed = df.groupby(['user_id', 'month'], as_index=False)['total'].sum()
    filled = fill_missing_months(collapsed, group_col='user_id', month_col='month', value_col='total')
    filled = filled.sort_values('month').tail(months)

    return [{'month': row.month.date(), 'total': float(row.total)} for row in filled.itertuples()]


def get_budget_risk_context(budget):
    """Builds the feature inputs predict_budget_risk.predict_budget_risk() needs for one budget."""
    import calendar

    from django.utils import timezone

    from apps.budgets.services import get_current_spending

    today = timezone.localdate()
    days_in_month = calendar.monthrange(budget.month.year, budget.month.month)[1]
    # If this budget is for a past (already-closed) month, treat it as
    # fully elapsed rather than using today's day-of-month, which would
    # be meaningless for a month that isn't the current one.
    is_current_month = budget.month.year == today.year and budget.month.month == today.month
    day_of_month = today.day if is_current_month else days_in_month

    current_spending = get_current_spending(budget)

    return {
        'monthly_limit': float(budget.monthly_limit),
        'current_spending': float(current_spending),
        'day_of_month': day_of_month,
        'days_in_month': days_in_month,
        'category': budget.category,
    }


def compute_goal_velocity(goal):
    """Builds the feature inputs predict_goal_forecast.predict_goal_forecast() needs for one goal."""
    from django.utils import timezone

    today = timezone.localdate()
    created = goal.created_at.date()
    total_contributed = sum(c.amount for c in goal.contributions.all())
    days_active = max((today - created).days, 1)
    daily_velocity = float(total_contributed) / days_active

    return {
        'target_amount': float(goal.target_amount),
        'saved_amount': float(goal.saved_amount),
        'daily_velocity': daily_velocity,
        'target_date': goal.target_date,
        'today': today,
        'created_at': created,
    }


def get_recent_expenses_with_category_history(user, days=30, history_window=20):
    """
    For anomaly detection: each of the user's recent expenses, paired
    with its own prior same-category amount history (excluding itself) —
    exactly what predict_anomaly.predict_anomaly() needs to judge "unusual
    relative to this user's own past spending in this category".
    """
    from datetime import timedelta

    from django.utils import timezone

    from apps.expenses.models import Expense

    cutoff = timezone.localdate() - timedelta(days=days)
    recent = Expense.objects.filter(user=user, expense_date__gte=cutoff).order_by('-expense_date')

    results = []
    for expense in recent:
        history_qs = Expense.objects.filter(
            user=user, category=expense.category, expense_date__lt=expense.expense_date,
        ).order_by('-expense_date')[:history_window]
        history = [float(e.amount) for e in history_qs]
        results.append((expense, history))
    return results
