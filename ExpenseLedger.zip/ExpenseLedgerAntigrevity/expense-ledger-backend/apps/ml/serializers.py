from rest_framework import serializers

from .models import MLModelVersion


class MLModelVersionSerializer(serializers.ModelSerializer):
    model_name_display = serializers.CharField(source='get_model_name_display', read_only=True)

    class Meta:
        model = MLModelVersion
        fields = [
            'id', 'model_name', 'model_name_display', 'version', 'training_samples',
            'metric_name', 'metric_value', 'is_active', 'notes', 'trained_at',
        ]
        read_only_fields = fields


# --- Prediction request/response serializers ---
# Length limits below intentionally mirror the corresponding fields on
# Expense (title max_length=200, description max_length=500) — validating
# to the same bounds the data will eventually be saved with, not an
# arbitrary separate limit.

class CategorySuggestionRequestSerializer(serializers.Serializer):
    title = serializers.CharField(max_length=200, required=True, allow_blank=False, trim_whitespace=True)
    description = serializers.CharField(max_length=500, required=False, allow_blank=True, default='')

    def validate_title(self, value):
        if not value.strip():
            raise serializers.ValidationError('Title cannot be empty or whitespace only.')
        return value


class CategorySuggestionResponseSerializer(serializers.Serializer):
    category = serializers.CharField()
    confidence = serializers.FloatField()
    method = serializers.ChoiceField(choices=['model', 'keyword_fallback'])


class ExpenseForecastResponseSerializer(serializers.Serializer):
    prediction = serializers.FloatField()
    method = serializers.ChoiceField(choices=['model', 'average_fallback'])
    months_used = serializers.IntegerField()


class BudgetRiskResponseSerializer(serializers.Serializer):
    budget_id = serializers.IntegerField()
    risk_score = serializers.FloatField()
    method = serializers.ChoiceField(choices=['model', 'rule_based_fallback'])


class AnomalyResultSerializer(serializers.Serializer):
    expense_id = serializers.IntegerField()
    title = serializers.CharField()
    amount = serializers.DecimalField(max_digits=12, decimal_places=2)
    expense_date = serializers.DateField()
    is_anomaly = serializers.BooleanField()
    score = serializers.FloatField()
    method = serializers.ChoiceField(choices=['model', 'zscore_fallback', 'insufficient_history'])


class GoalForecastResponseSerializer(serializers.Serializer):
    goal_id = serializers.IntegerField()
    estimated_days_remaining = serializers.IntegerField(allow_null=True)
    estimated_completion_date = serializers.DateField(allow_null=True)
    pace_status = serializers.ChoiceField(choices=['ahead', 'on_track', 'behind', 'stalled'])
    method = serializers.ChoiceField(choices=['model', 'model_blended', 'arithmetic_projection', 'none'])
