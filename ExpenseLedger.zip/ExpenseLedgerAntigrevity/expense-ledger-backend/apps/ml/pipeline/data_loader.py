"""
Pulls data out of Django and into pandas DataFrames. This is the one
module in `pipeline/` that imports Django models — extraction has to
touch the ORM somewhere. Every other pipeline module (preprocessing,
feature_engineering, model_registry, utils) operates purely on
DataFrames/arrays and has no Django dependency.

Imports are deferred inside each function (not at module top), matching
the pattern used everywhere else in this project's services.py files —
avoids requiring Django to be configured just to import this module, and
avoids any risk of circular imports with the app that owns each model.
"""
from .utils import logger


def load_expenses(user=None, since=None):
    """
    All expenses, optionally scoped to one user and/or a start date.
    `user=None` pulls across every user — used by the (global) category
    classifier, which benefits from pooling everyone's title→category
    examples. Per-user models pass an explicit user.
    """
    import pandas as pd
    from apps.expenses.models import Expense

    qs = Expense.objects.all()
    if user is not None:
        qs = qs.filter(user=user)
    if since is not None:
        qs = qs.filter(expense_date__gte=since)

    df = pd.DataFrame(qs.values(
        'id', 'user_id', 'title', 'category', 'amount', 'payment_method',
        'expense_date', 'description', 'notes', 'is_recurring', 'recurring_frequency', 'created_at',
    ))
    logger.info(f'Loaded {len(df)} expense row(s)' + (f' for user {user.id}' if user else ' (all users)'))
    return df


def load_income(user=None, since=None):
    import pandas as pd
    from apps.income.models import Income

    qs = Income.objects.all()
    if user is not None:
        qs = qs.filter(user=user)
    if since is not None:
        qs = qs.filter(income_date__gte=since)

    df = pd.DataFrame(qs.values(
        'id', 'user_id', 'source', 'amount', 'income_date', 'description', 'is_recurring', 'created_at',
    ))
    logger.info(f'Loaded {len(df)} income row(s)')
    return df


def load_budget_history_with_actuals(user=None):
    """
    One row per (user, category, month) budget, joined with the actual
    spend for that category/month — this is the labeled dataset the
    budget-risk model trains on (label = whether the budget ended up
    exceeded). Only *closed* months (month fully in the past) are
    included, since an in-progress month doesn't have a final label yet.
    """
    import pandas as pd
    from django.utils import timezone

    from apps.budgets.models import Budget
    from apps.budgets.services import get_current_spending

    today = timezone.localdate()
    current_month_start = today.replace(day=1)

    qs = Budget.objects.filter(month__lt=current_month_start)
    if user is not None:
        qs = qs.filter(user=user)

    rows = []
    for budget in qs.select_related('user'):
        actual_spend = get_current_spending(budget)
        rows.append({
            'budget_id': budget.id,
            'user_id': budget.user_id,
            'category': budget.category,
            'month': budget.month,
            'monthly_limit': float(budget.monthly_limit),
            'actual_spend': float(actual_spend),
            'exceeded': actual_spend > budget.monthly_limit,
        })

    df = pd.DataFrame(rows)
    logger.info(f'Loaded {len(df)} closed budget-month row(s)')
    return df


def load_monthly_expense_totals(user=None):
    """
    Expenses aggregated to one row per (user, month, category) — the base
    table the expense forecaster builds lag/rolling features from, rather
    than each script re-aggregating raw transactions itself.
    """
    import pandas as pd
    from django.db.models import Sum
    from django.db.models.functions import TruncMonth

    from apps.expenses.models import Expense

    qs = Expense.objects.all()
    if user is not None:
        qs = qs.filter(user=user)

    rows = (
        qs.annotate(month=TruncMonth('expense_date'))
        .values('user_id', 'month', 'category')
        .annotate(total=Sum('amount'))
        .order_by('user_id', 'month')
    )
    df = pd.DataFrame(list(rows))
    if not df.empty:
        df['total'] = df['total'].astype(float)
    logger.info(f'Loaded {len(df)} monthly-expense-total row(s)')
    return df


def load_goal_contributions(user=None, goal=None):
    import pandas as pd
    from apps.goals.models import GoalContribution

    qs = GoalContribution.objects.select_related('goal')
    if goal is not None:
        qs = qs.filter(goal=goal)
    elif user is not None:
        qs = qs.filter(goal__user=user)

    df = pd.DataFrame(qs.values(
        'id', 'goal_id', 'goal__user_id', 'goal__target_amount', 'goal__saved_amount',
        'goal__target_date', 'goal__created_at', 'amount', 'date',
    ))
    logger.info(f'Loaded {len(df)} goal contribution row(s)')
    return df


def load_completed_goals_with_outcomes(user=None):
    """
    One row per *completed* goal: target_amount, how many days it actually
    took from creation to completion, and the average daily contribution
    velocity over that period. This is the supervised training signal for
    the goal forecaster — target_amount + velocity → actual days-to-complete.

    Only completed goals have a real outcome to learn from; active goals
    are what the trained model is later applied *to*, not trained *on*.
    """
    import pandas as pd
    from apps.goals.models import Goal

    qs = Goal.objects.filter(status='completed')
    if user is not None:
        qs = qs.filter(user=user)

    rows = []
    for goal in qs:
        days_to_complete = (goal.updated_at.date() - goal.created_at.date()).days
        if days_to_complete <= 0:
            continue  # same-day completion isn't a useful training signal
        total_contributed = sum(c.amount for c in goal.contributions.all())
        rows.append({
            'goal_id': goal.id,
            'target_amount': float(goal.target_amount),
            'days_to_complete': days_to_complete,
            'daily_velocity': float(total_contributed) / days_to_complete,
        })

    df = pd.DataFrame(rows)
    logger.info(f'Loaded {len(df)} completed goal row(s) with outcomes')
    return df
