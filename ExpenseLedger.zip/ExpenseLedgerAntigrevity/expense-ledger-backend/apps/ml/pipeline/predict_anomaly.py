"""
Flags whether a single expense looks unusual for that user/category.

Fallback (insufficient per-user/category history or no trained model):
a plain z-score threshold — the same statistical idea the trained
IsolationForest generalizes, just without the model.
"""
from .config import MIN_TRANSACTIONS_FOR_ANOMALY_DETECTION
from .utils import logger

Z_SCORE_FALLBACK_THRESHOLD = 2.5


def _zscore_fallback(amount, category_history):
    """`category_history`: list of past amounts (floats) for this user+category, excluding the new one."""
    if len(category_history) < MIN_TRANSACTIONS_FOR_ANOMALY_DETECTION:
        return {'is_anomaly': False, 'score': 0.0, 'method': 'insufficient_history'}

    import statistics

    mean = statistics.mean(category_history)
    std = statistics.pstdev(category_history) or 1.0
    z = (amount - mean) / std
    return {'is_anomaly': abs(z) >= Z_SCORE_FALLBACK_THRESHOLD, 'score': round(float(z), 2), 'method': 'zscore_fallback'}


def predict_anomaly(amount, category_history, day_of_week=None):
    """
    Returns {'is_anomaly': bool, 'score': float, 'method': str}.
    Positive score = higher than usual; the sign is preserved (unlike a
    raw IsolationForest score) so the caller can tell "unusually high"
    from "unusually low" in the response, not just "unusual".
    """
    from apps.ml.services import get_active_model_path

    from .model_registry import model_cache

    model_path = get_active_model_path('anomaly_detector')
    if not model_path:
        logger.info('predict_anomaly: no trained model yet — using z-score fallback.')
        return _zscore_fallback(amount, category_history)

    loaded = model_cache.get_or_load('anomaly_detector', model_path)
    if loaded is None:
        return _zscore_fallback(amount, category_history)

    if len(category_history) < MIN_TRANSACTIONS_FOR_ANOMALY_DETECTION:
        # Trust the per-user guard even when a global model exists — a
        # brand-new user/category combo has nothing for a rolling stat
        # to be relative to yet, model or no model.
        return {'is_anomaly': False, 'score': 0.0, 'method': 'insufficient_history'}

    bundle, _metadata = loaded
    import statistics

    import pandas as pd

    mean = statistics.mean(category_history)
    std = statistics.pstdev(category_history) or 1.0
    row = {
        'amount': amount,
        'amount_zscore': (amount - mean) / std,
        'amount_rolling_mean': mean,
        'amount_rolling_std': std,
        'day_of_week': day_of_week if day_of_week is not None else 0,
        'is_weekend': int(day_of_week in (5, 6)) if day_of_week is not None else 0,
    }
    X = pd.DataFrame([row])[bundle['feature_columns']]

    raw_prediction = bundle['model'].predict(X)[0]  # -1 = anomaly, 1 = normal
    raw_score = bundle['model'].decision_function(X)[0]  # lower = more anomalous
    return {'is_anomaly': raw_prediction == -1, 'score': round(float(-raw_score), 3), 'method': 'model'}
