"""
Predicts an expense category from its title/description.

Works in two modes:
- Trained model available (apps.ml MLModelVersion has an active
  category_classifier): uses the TF-IDF + LogisticRegression bundle.
- No trained model yet: falls back to a small keyword heuristic, so this
  function is usable — and testable end-to-end — immediately, before any
  training has happened.
"""
from .preprocessing import clean_text
from .utils import logger

# Deliberately small and conservative — only fires on unambiguous keywords.
# This is NOT meant to be a good classifier, just a reasonable placeholder
# so the feature isn't simply broken before the real model exists.
_KEYWORD_FALLBACK_RULES = {
    'food': ['restaurant', 'grocery', 'groceries', 'zomato', 'swiggy', 'cafe', 'coffee', 'lunch', 'dinner'],
    'transport': ['uber', 'ola', 'petrol', 'fuel', 'metro', 'bus', 'taxi', 'cab'],
    'shopping': ['amazon', 'flipkart', 'myntra', 'mall', 'clothes', 'shopping'],
    'medical': ['pharmacy', 'hospital', 'doctor', 'medicine', 'clinic'],
    'bills': ['electricity', 'water bill', 'wifi', 'internet', 'phone bill', 'utility'],
    'education': ['course', 'tuition', 'books', 'college', 'exam fee'],
    'entertainment': ['movie', 'netflix', 'spotify', 'concert', 'game'],
    'investment': ['sip', 'mutual fund', 'stocks', 'shares'],
    'rent': ['rent', 'landlord'],
}


def _keyword_fallback(title, description=''):
    text = clean_text(f'{title} {description}')
    for category, keywords in _KEYWORD_FALLBACK_RULES.items():
        if any(keyword in text for keyword in keywords):
            return category, 0.4, 'keyword_fallback'  # low, honest confidence — this is a heuristic, not a model
    return 'others', 0.1, 'keyword_fallback'


def predict_category(title, description=''):
    """
    Returns (category, confidence, method). `method` is explicit — 'model'
    or 'keyword_fallback' — rather than left for the caller to infer from
    the confidence value, which would be fragile (a genuinely uncertain
    model prediction and a fallback both produce "low confidence" for
    different reasons; only this function actually knows which happened).
    """
    from apps.ml.services import get_active_model_path

    from .model_registry import model_cache

    model_path = get_active_model_path('category_classifier')
    if not model_path:
        logger.info('predict_category: no trained model yet — using keyword fallback.')
        return _keyword_fallback(title, description)

    loaded = model_cache.get_or_load('category_classifier', model_path)
    if loaded is None:
        logger.warning('predict_category: MLModelVersion points at a missing file — using keyword fallback.')
        return _keyword_fallback(title, description)

    bundle, _metadata = loaded
    text = clean_text(f'{title} {description}')
    if not text:
        return _keyword_fallback(title, description)

    vectorized = bundle['vectorizer'].transform([text])
    category = bundle['classifier'].predict(vectorized)[0]
    proba = bundle['classifier'].predict_proba(vectorized).max()
    return category, round(float(proba), 3), 'model'
