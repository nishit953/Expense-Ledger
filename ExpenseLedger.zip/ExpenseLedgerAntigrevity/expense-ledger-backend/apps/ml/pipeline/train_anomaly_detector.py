"""
Trains the unusual-transaction detector (design doc Model 4).

Unsupervised — no labels exist for "this was anomalous", so there's no
train/test split with a y to evaluate against. Trained as ONE global
Isolation Forest, not per-user: the input features (amount_zscore,
per-user rolling mean/std from build_anomaly_features) are already
normalized relative to each user's own history, so a single global model
can still make a per-user-relevant judgment without needing enough data
to train a separate model per individual user. NOT executed here.
"""
from .config import MIN_TRANSACTIONS_FOR_ANOMALY_DETECTION
from .feature_engineering import build_anomaly_features
from .utils import logger, set_random_seed


def train(contamination=0.05):
    """`contamination` is IsolationForest's expected fraction of anomalies — 5% is a reasonable starting default."""
    from sklearn.ensemble import IsolationForest

    from . import data_loader, model_registry

    set_random_seed()

    expenses_df = data_loader.load_expenses(user=None)
    features = build_anomaly_features(expenses_df)

    if len(features['X']) < MIN_TRANSACTIONS_FOR_ANOMALY_DETECTION * 10:
        logger.warning(
            f'Only {len(features["X"])} expense(s) available — likely too few for a stable '
            f'global anomaly model yet. Training will proceed, but predict_anomaly.py should '
            f'still apply its own per-user minimum-history guard before trusting a flag.'
        )

    model = IsolationForest(contamination=contamination, random_state=42, n_estimators=200)
    model.fit(features['X'])

    # No y to score against — log how many training rows it flagged on
    # itself as a sanity-check figure, not a real evaluation metric.
    self_predictions = model.predict(features['X'])
    flagged_fraction = (self_predictions == -1).mean()
    logger.info(f'anomaly_detector: flagged {flagged_fraction:.1%} of training rows as anomalous (self-check only).')

    bundle = {'model': model, 'feature_columns': features['feature_columns']}
    relative_path = model_registry.save_model(
        bundle, model_name='anomaly_detector',
        metadata={'flagged_fraction': flagged_fraction, 'n_samples': len(features['X'])},
    )

    from apps.ml.services import record_version
    record_version(
        model_name='anomaly_detector',
        file_path=relative_path,
        training_samples=len(features['X']),
        metric_name='flagged_fraction',
        metric_value=flagged_fraction,
        notes=f'IsolationForest(contamination={contamination}). Unsupervised — no accuracy metric applies.',
    )

    return {'flagged_fraction': flagged_fraction}


if __name__ == '__main__':
    train()
