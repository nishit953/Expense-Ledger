"""
Predicts next month's total expense for a user.

Fallback (insufficient history or no trained model): the user's own
recent average — an honest, simple estimate rather than a model output
dressed up as more reliable than it is. This is the cold-start behavior
documented explicitly in the design doc §5/§6.
"""
from .config import MIN_MONTHS_FOR_EXPENSE_FORECAST
from .utils import logger


def _average_fallback(recent_monthly_totals):
    """Flat average of whatever history is available — used for brand-new users or an untrained model."""
    if not recent_monthly_totals:
        return 0.0
    return round(sum(recent_monthly_totals) / len(recent_monthly_totals), 2)


def predict_next_month_expense(user_id, monthly_history):
    """
    `monthly_history`: list of dicts, chronological (most recent last),
    each shaped like {'month': date, 'total': float} — the caller (a
    future DRF view) builds this from the same gap-filled aggregation
    feature_engineering.build_forecast_features uses during training,
    scoped to one user. Gaps (months with zero expenses) should already
    be filled with 0 by the caller, exactly as training data is — an
    ungapped history here would silently mismatch what the model learned.

    Returns {'prediction': float, 'method': 'model'|'average_fallback', 'months_used': int}.
    """
    from apps.ml.services import get_active_model_path

    from .model_registry import model_cache

    recent_totals = [row['total'] for row in monthly_history]

    if len(monthly_history) < MIN_MONTHS_FOR_EXPENSE_FORECAST:
        logger.info(f'predict_next_month_expense: user {user_id} has only {len(monthly_history)} month(s) — using average fallback.')
        return {'prediction': _average_fallback(recent_totals), 'method': 'average_fallback', 'months_used': len(monthly_history)}

    model_path = get_active_model_path('expense_forecaster')
    if not model_path:
        return {'prediction': _average_fallback(recent_totals), 'method': 'average_fallback', 'months_used': len(monthly_history)}

    loaded = model_cache.get_or_load('expense_forecaster', model_path)
    if loaded is None:
        return {'prediction': _average_fallback(recent_totals), 'method': 'average_fallback', 'months_used': len(monthly_history)}

    bundle, _metadata = loaded
    import pandas as pd

    last_3 = recent_totals[-3:]
    lag_1 = recent_totals[-1]
    lag_2 = recent_totals[-2] if len(recent_totals) >= 2 else recent_totals[-1]
    lag_3 = recent_totals[-3] if len(recent_totals) >= 3 else recent_totals[-1]
    rolling_mean_3 = sum(last_3) / len(last_3)
    rolling_std_3 = pd.Series(last_3).std() if len(last_3) > 1 else 0.0
    if pd.isna(rolling_std_3):
        rolling_std_3 = 0.0

    next_month_date = monthly_history[-1]['month']
    next_month_number = (next_month_date.month % 12) + 1
    next_quarter = ((next_month_number - 1) // 3) + 1

    row = {
        'lag_1': lag_1, 'lag_2': lag_2, 'lag_3': lag_3,
        'rolling_mean_3': rolling_mean_3, 'rolling_std_3': rolling_std_3,
        'momentum': lag_1 - lag_2,
        'month_number': next_month_number, 'quarter': next_quarter,
    }
    X = pd.DataFrame([row])[bundle['feature_columns']]
    prediction = float(bundle['model'].predict(X)[0])

    return {'prediction': round(max(0.0, prediction), 2), 'method': 'model', 'months_used': len(monthly_history)}
