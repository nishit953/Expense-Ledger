"""
Central configuration for the ML pipeline.

Deliberately has zero Django imports — everything in `pipeline/` should be
runnable and testable as plain Python, independent of the web framework.
Django-aware glue (pulling querysets, logging MLModelVersion rows) lives in
apps/ml/services.py and the data_loader functions that accept a queryset,
not here.
"""
from pathlib import Path

PIPELINE_DIR = Path(__file__).resolve().parent
ARTIFACTS_DIR = PIPELINE_DIR / 'artifacts'

RANDOM_SEED = 42

# Mirrors apps.expenses.models.Expense.CATEGORY_CHOICES. Duplicated as a
# plain constant (rather than importing the Django model) so pipeline/
# stays import-safe outside a configured Django environment — e.g. if
# someone runs a training script standalone or in a notebook.
EXPENSE_CATEGORIES = [
    'food', 'transport', 'shopping', 'medical', 'bills',
    'education', 'entertainment', 'investment', 'rent', 'others',
]

INCOME_SOURCES = [
    'salary', 'freelancing', 'business', 'rental', 'interest', 'bonus', 'other',
]

# --- Cold-start thresholds ---
# Below these, prediction scripts use a documented fallback instead of a
# model output — see design doc §6 "cold-start guardrails".
MIN_SAMPLES_CATEGORY_CLASSIFIER_GLOBAL = 200          # global model, pooled across users
MIN_TRANSACTIONS_FOR_ANOMALY_DETECTION = 5            # per user, per category
MIN_MONTHS_FOR_EXPENSE_FORECAST = 3                   # per user
MIN_BUDGET_MONTHS_FOR_RISK_MODEL = 30                 # global training set (budget-months, pooled)
MIN_CONTRIBUTIONS_FOR_GOAL_FORECAST = 2                # per goal

# --- Model file names (relative to ARTIFACTS_DIR) ---
MODEL_FILENAMES = {
    'category_classifier': 'category_classifier/model.joblib',
    'budget_risk_model': 'budget_risk_model/model.joblib',
    'expense_forecaster': 'expense_forecaster/model.joblib',
    'anomaly_detector': 'anomaly_detector/model.joblib',
    'goal_forecaster': 'goal_forecaster/model.joblib',
}

WARNING_THRESHOLD_PERCENT = 80  # mirrors apps.budgets.services — reused as a feature, not re-derived
