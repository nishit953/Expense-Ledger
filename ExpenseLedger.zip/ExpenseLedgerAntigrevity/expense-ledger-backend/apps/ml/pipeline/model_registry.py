"""
File-system side of model management: saving/loading joblib artifacts and
resolving their paths. The Django side (logging a version row, tracking
which one is "active") lives in apps/ml/services.py, which calls into
this module for the actual disk I/O — kept separate so this module has
no Django dependency and can be unit-tested or used from a notebook.
"""
from datetime import datetime

from .config import ARTIFACTS_DIR
from .utils import logger


def resolve_artifact_path(model_name, filename=None):
    """
    Builds a path like artifacts/category_classifier/2026-07-21T14-30-00.joblib
    (or artifacts/<model_name>/<filename> if filename is given explicitly).
    """
    model_dir = ARTIFACTS_DIR / model_name
    if filename:
        return model_dir / filename
    timestamp = datetime.now().strftime('%Y-%m-%dT%H-%M-%S')
    return model_dir / f'{timestamp}.joblib'


def save_model(model_object, model_name, filename=None, metadata=None):
    """
    Persists a fitted model (or any picklable object — a dict of {model,
    vectorizer, encoder} bundles is common and fine) via joblib.

    Returns the path relative to ARTIFACTS_DIR, which is what gets stored
    in MLModelVersion.file_path — relative so artifacts stay portable if
    the project directory ever moves.
    """
    import joblib

    path = resolve_artifact_path(model_name, filename)
    path.parent.mkdir(parents=True, exist_ok=True)

    payload = {'model': model_object, 'metadata': metadata or {}}
    joblib.dump(payload, path)

    relative_path = path.relative_to(ARTIFACTS_DIR)
    logger.info(f'Saved {model_name} artifact to {relative_path}')
    return str(relative_path)


def load_model(relative_path):
    """
    Loads a previously saved artifact by its path (as stored in
    MLModelVersion.file_path). Returns None if the file doesn't exist
    rather than raising — callers (prediction scripts) are expected to
    treat "no model on disk yet" as a normal, coldstart-fallback case,
    not an error.
    """
    import joblib

    path = ARTIFACTS_DIR / relative_path
    if not path.exists():
        logger.warning(f'No artifact found at {relative_path} — caller should fall back.')
        return None

    payload = joblib.load(path)
    return payload['model'], payload.get('metadata', {})


def artifact_exists(relative_path):
    return (ARTIFACTS_DIR / relative_path).exists()


def ensure_artifacts_dir():
    """Called once at pipeline import/setup time to make sure the artifacts tree exists."""
    ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)


class ModelCache:
    """
    Tiny in-process cache so a loaded model isn't deserialized from disk on
    every single prediction request within the same process — loaded once,
    reused until the process restarts or `invalidate()` is called (e.g.
    after a retrain activates a new version).
    """

    def __init__(self):
        self._cache = {}

    def get_or_load(self, model_name, relative_path):
        cache_key = (model_name, relative_path)
        if cache_key not in self._cache:
            loaded = load_model(relative_path)
            self._cache[cache_key] = loaded
        return self._cache[cache_key]

    def invalidate(self, model_name=None):
        if model_name is None:
            self._cache.clear()
        else:
            for key in list(self._cache):
                if key[0] == model_name:
                    del self._cache[key]


# Process-wide singleton — imported by prediction scripts rather than each
# one keeping its own cache.
model_cache = ModelCache()
