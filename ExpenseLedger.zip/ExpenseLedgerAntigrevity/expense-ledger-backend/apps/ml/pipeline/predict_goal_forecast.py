"""
Estimates a goal's completion date and pace status.

The arithmetic projection (remaining_amount / current_velocity) is
ALWAYS computed, regardless of whether a trained model exists — per the
design doc's honest note that a plain projection may outperform a model
at this data scale. A trained model, if available, only refines the
days-to-complete estimate; it never replaces the baseline outright.
"""
from datetime import timedelta

from .utils import logger


def _arithmetic_projection(remaining_amount, daily_velocity):
    if daily_velocity <= 0:
        return None  # no contributions yet, or stalled — can't project a completion date at all
    return remaining_amount / daily_velocity


def predict_goal_forecast(target_amount, saved_amount, daily_velocity, target_date, today, created_at):
    """
    Returns {'estimated_days_remaining', 'estimated_completion_date',
    'pace_status', 'method'} — pace_status is one of 'ahead', 'on_track',
    'behind', or 'stalled' (no recent contributions to project from).
    """
    from apps.ml.services import get_active_model_path

    from .model_registry import model_cache

    remaining_amount = max(0.0, float(target_amount) - float(saved_amount))
    baseline_days = _arithmetic_projection(remaining_amount, daily_velocity)

    estimated_days = baseline_days
    method = 'arithmetic_projection'

    model_path = get_active_model_path('goal_forecaster')
    if model_path and daily_velocity > 0:
        loaded = model_cache.get_or_load('goal_forecaster', model_path)
        if loaded is not None:
            bundle, _metadata = loaded
            import pandas as pd

            X = pd.DataFrame([{'target_amount': float(target_amount), 'daily_velocity': daily_velocity}])[bundle['feature_columns']]
            total_days_predicted = float(bundle['model'].predict(X)[0])
            days_elapsed = (today - created_at).days
            model_days_remaining = max(0.0, total_days_predicted - days_elapsed)

            # Blend rather than fully replace the arithmetic baseline —
            # a single Ridge regression on a small completed-goals sample
            # can extrapolate poorly for target amounts far outside what
            # it's seen; averaging with the baseline bounds that risk.
            if baseline_days is not None:
                estimated_days = (model_days_remaining + baseline_days) / 2
                method = 'model_blended'
            else:
                estimated_days = model_days_remaining
                method = 'model'
        else:
            logger.info('predict_goal_forecast: model path set but artifact missing — using arithmetic projection only.')

    if estimated_days is None:
        return {
            'estimated_days_remaining': None, 'estimated_completion_date': None,
            'pace_status': 'stalled', 'method': 'none',
        }

    estimated_completion_date = today + timedelta(days=round(estimated_days))

    if estimated_completion_date <= target_date:
        pace_status = 'ahead' if estimated_completion_date < target_date - timedelta(days=7) else 'on_track'
    else:
        pace_status = 'behind'

    return {
        'estimated_days_remaining': round(estimated_days),
        'estimated_completion_date': estimated_completion_date,
        'pace_status': pace_status,
        'method': method,
    }
