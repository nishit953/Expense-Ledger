"""
Trains the expense category auto-suggestion model (design doc Model 1).

Global model, pooled across all users — text→category generalizes across
users even though amounts don't, so this deliberately does NOT filter by
user (see data_loader.load_expenses(user=None)).

Run manually via the management command, e.g.:
    python manage.py train_ml_models --model category_classifier

NOT executed as part of this infrastructure setup — per instructions, no
model is actually trained yet. This file is complete and runnable on
demand once there's enough data.
"""
from .config import MIN_SAMPLES_CATEGORY_CLASSIFIER_GLOBAL
from .feature_engineering import build_category_classifier_features
from .utils import compute_classification_metrics, logger, set_random_seed


def train():
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.linear_model import LogisticRegression

    from . import data_loader, model_registry

    set_random_seed()

    expenses_df = data_loader.load_expenses(user=None)
    if len(expenses_df) < MIN_SAMPLES_CATEGORY_CLASSIFIER_GLOBAL:
        logger.warning(
            f'Only {len(expenses_df)} expense(s) available, below the recommended minimum '
            f'{MIN_SAMPLES_CATEGORY_CLASSIFIER_GLOBAL} for a global classifier. '
            f'Training will proceed, but expect low accuracy until more data accumulates — '
            f'predict_category.py falls back to a keyword heuristic in the meantime.'
        )

    features = build_category_classifier_features(expenses_df)

    vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=2, max_features=5000)
    X_train_vec = vectorizer.fit_transform(features['X_train'])
    X_test_vec = vectorizer.transform(features['X_test'])

    classifier = LogisticRegression(max_iter=1000, class_weight='balanced')
    classifier.fit(X_train_vec, features['y_train'])

    y_pred = classifier.predict(X_test_vec)
    metrics = compute_classification_metrics(features['y_test'], y_pred)
    logger.info(f'category_classifier metrics: {metrics}')

    # Bundle vectorizer + classifier together — predict_category.py needs
    # both, and joblib.dump()-ing them as one payload keeps them from ever
    # drifting out of sync with each other on disk.
    bundle = {'vectorizer': vectorizer, 'classifier': classifier}
    relative_path = model_registry.save_model(
        bundle, model_name='category_classifier',
        metadata={'metrics': metrics, 'n_samples': len(expenses_df)},
    )

    from apps.ml.services import record_version
    record_version(
        model_name='category_classifier',
        file_path=relative_path,
        training_samples=len(expenses_df),
        metric_name='f1',
        metric_value=metrics['f1'],
        notes=f'LogisticRegression + TF-IDF(1,2). accuracy={metrics["accuracy"]:.3f}',
    )

    return metrics


if __name__ == '__main__':
    train()
