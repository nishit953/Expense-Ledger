"""
Trains the next-month total-expense forecaster (design doc Model 3).

Full pipeline: data preparation -> feature engineering -> model selection
(cross-validated comparison of multiple candidates, not an assumed
default) -> training -> evaluation (against both the held-out test set
AND naive baselines, so "the model works" is actually demonstrated, not
asserted) -> model saving.

Global model over all users' monthly totals — see build_forecast_features
in feature_engineering.py for the per-user lag/rolling features that give
it user-specific context despite being trained globally.

NOT executed as part of infrastructure setup; run explicitly via
`python manage.py train_ml_models --model expense_forecaster`.
"""
from .config import MIN_MONTHS_FOR_EXPENSE_FORECAST
from .feature_engineering import build_forecast_features
from .utils import compare_regressors_cv, compute_regression_metrics, logger, set_random_seed


def _candidate_models():
    """
    The comparison set for model selection. Includes a DummyRegressor
    (predicts the training mean, ignoring all features) deliberately —
    if a "real" model can't beat literally guessing the average, that's
    important to know rather than silently shipping a model that adds
    no value over a constant.
    """
    from sklearn.dummy import DummyRegressor
    from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor
    from sklearn.linear_model import Ridge

    return {
        'mean_baseline': DummyRegressor(strategy='mean'),
        'ridge': Ridge(alpha=1.0, random_state=42),
        'random_forest': RandomForestRegressor(n_estimators=100, max_depth=5, random_state=42),
        'gradient_boosting': HistGradientBoostingRegressor(random_state=42, max_iter=100),
    }


def _naive_persistence_baseline(X_test):
    """'Next month = same as last month' — the simplest possible forecast, used as an evaluation floor, not a candidate to train."""
    return X_test['lag_1'].values


def train():
    from . import data_loader, model_registry

    set_random_seed()

    # --- 1. Data preparation ---
    logger.info('Step 1/6: loading and preparing data...')
    monthly_totals_df = data_loader.load_monthly_expense_totals(user=None)

    if monthly_totals_df.empty:
        logger.warning('No expense data available at all — nothing to train on.')
        return None

    # --- 2. Feature engineering ---
    logger.info('Step 2/6: engineering features (gap-filled lags, rolling stats, momentum, calendar)...')
    features = build_forecast_features(monthly_totals_df)

    n_users_ready = features['df_ready']['user_id'].nunique() if len(features['df_ready']) else 0
    logger.info(
        f'{len(features["df_ready"])} trainable (user, month) row(s) across {n_users_ready} user(s) '
        f'after requiring {MIN_MONTHS_FOR_EXPENSE_FORECAST}+ months of gap-filled history.'
    )

    if len(features['X_train']) < 5:
        logger.warning(
            f'Only {len(features["X_train"])} training row(s) — too few for meaningful model selection '
            f'or evaluation. Training will proceed for demonstration, but treat any metrics from a run '
            f'this small as illustrative only, not a real accuracy claim. predict_expense_forecast.py '
            f'will keep using the average fallback for individual users regardless until more data exists.'
        )

    # --- 3. Model selection ---
    logger.info('Step 3/6: comparing candidate models via time-series cross-validation...')
    candidates = _candidate_models()
    if len(features['X_train']) >= 4:
        best_name, best_estimator, cv_scores = compare_regressors_cv(
            candidates, features['X_train'], features['y_train'], n_splits=3,
        )
        logger.info(f'Selected "{best_name}" (lowest CV MAE among: {cv_scores})')
    else:
        # Too little data for cross-validation folds to mean anything —
        # fall back to the simplest reasonable choice rather than a
        # comparison that would just be noise.
        best_name, best_estimator, cv_scores = 'ridge', candidates['ridge'], {}
        logger.info('Too few rows for cross-validated selection — defaulting to Ridge.')

    # --- 4. Training ---
    logger.info(f'Step 4/6: training final "{best_name}" model on the full training set...')
    best_estimator.fit(features['X_train'], features['y_train'])

    # --- 5. Evaluation ---
    logger.info('Step 5/6: evaluating on the held-out (most recent) time period...')
    y_pred = best_estimator.predict(features['X_test'])
    metrics = compute_regression_metrics(features['y_test'], y_pred)

    baseline_pred = _naive_persistence_baseline(features['X_test'])
    baseline_metrics = compute_regression_metrics(features['y_test'], baseline_pred)

    beats_baseline = metrics['mae'] < baseline_metrics['mae']
    logger.info(f'Model MAE: {metrics["mae"]:.2f} | Naive persistence MAE: {baseline_metrics["mae"]:.2f} | Beats baseline: {beats_baseline}')

    if not beats_baseline:
        logger.warning(
            'Selected model does NOT beat the naive "next month = last month" baseline on this data. '
            'Saving it anyway (so the pipeline is verifiably complete end-to-end), but this is a real '
            'signal to gather more data before trusting this model in production over the fallback.'
        )

    # --- 6. Model saving ---
    logger.info('Step 6/6: saving model artifact and logging version...')
    bundle = {'model': best_estimator, 'feature_columns': features['feature_columns'], 'model_type': best_name}
    relative_path = model_registry.save_model(
        bundle, model_name='expense_forecaster',
        metadata={
            'metrics': metrics, 'baseline_metrics': baseline_metrics, 'cv_scores': cv_scores,
            'beats_baseline': beats_baseline, 'n_samples': len(features['X_train']), 'model_type': best_name,
        },
    )

    from apps.ml.services import record_version
    record_version(
        model_name='expense_forecaster',
        file_path=relative_path,
        training_samples=len(features['X_train']),
        metric_name='mae',
        metric_value=metrics['mae'],
        notes=(
            f'{best_name} selected via CV from {list(candidates.keys())}. '
            f'MAE={metrics["mae"]:.2f} (baseline={baseline_metrics["mae"]:.2f}, beats_baseline={beats_baseline}). '
            f'Features: {features["feature_columns"]}.'
        ),
    )

    return {'model_type': best_name, 'metrics': metrics, 'baseline_metrics': baseline_metrics, 'beats_baseline': beats_baseline}


if __name__ == '__main__':
    train()
