"""
Shared preprocessing steps used by more than one model's feature builder.
Operates purely on DataFrames — no Django imports, fully unit-testable
with hand-built fixtures.
"""
import re

import numpy as np
import pandas as pd


def clean_text(text):
    """Lowercase, strip punctuation, collapse whitespace — used before TF-IDF vectorization."""
    if not isinstance(text, str) or not text:
        return ''
    text = text.lower()
    text = re.sub(r'[^a-z0-9\s]', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def combine_text_fields(df, fields=('title', 'description')):
    """Concatenates the given text columns into one 'text' column, cleaning each first."""
    df = df.copy()
    parts = [df[f].fillna('').map(clean_text) for f in fields if f in df.columns]
    df['text'] = parts[0]
    for part in parts[1:]:
        df['text'] = df['text'] + ' ' + part
    df['text'] = df['text'].str.strip()
    return df


def add_temporal_features(df, date_column):
    """Adds day_of_week, day_of_month, month, is_weekend derived from a date column."""
    df = df.copy()
    dates = pd.to_datetime(df[date_column])
    df['day_of_week'] = dates.dt.dayofweek  # 0=Monday
    df['day_of_month'] = dates.dt.day
    df['month'] = dates.dt.month
    df['is_weekend'] = df['day_of_week'].isin([5, 6]).astype(int)
    return df


def add_per_user_rolling_stats(df, group_cols, value_col, window=5, min_periods=1):
    """
    Adds a rolling mean/std of `value_col`, computed within each group
    (typically user_id + category), so "is this amount unusual" is judged
    relative to that user's own history — not a global average, since
    spending scale varies hugely by individual income.

    Uses `.shift(1)` before rolling so a row's own value never leaks into
    its own rolling statistic (that would make every value look "normal"
    relative to a window that includes itself).
    """
    df = df.copy()
    grouped = df.groupby(group_cols)[value_col]
    df[f'{value_col}_rolling_mean'] = grouped.transform(
        lambda s: s.shift(1).rolling(window=window, min_periods=min_periods).mean()
    )
    df[f'{value_col}_rolling_std'] = grouped.transform(
        lambda s: s.shift(1).rolling(window=window, min_periods=min_periods).std()
    )
    # Rows early in a group's history won't have enough prior data for a
    # std — fill with 0 rather than NaN so downstream models don't choke.
    df[f'{value_col}_rolling_std'] = df[f'{value_col}_rolling_std'].fillna(0)
    return df


def z_score_relative_to_group(df, group_cols, value_col):
    """
    Per-group z-score: how many standard deviations is this row's value
    from its group's mean? Used by the anomaly detector so "unusual"
    is judged per (user, category), not globally.
    """
    df = df.copy()
    stats = df.groupby(group_cols)[value_col].transform(['mean', 'std'])
    mean, std = stats['mean'], stats['std'].replace(0, np.nan)
    df[f'{value_col}_zscore'] = ((df[value_col] - mean) / std).fillna(0)
    return df


def one_hot_encode(df, columns):
    """Thin wrapper over pd.get_dummies with a consistent prefix convention across every feature builder."""
    return pd.get_dummies(df, columns=columns, prefix=columns)


def time_based_train_test_split(df, date_column, test_fraction=0.2):
    """
    Splits chronologically (earliest rows → train, most recent → test)
    rather than randomly — a random split would leak future information
    into training for time-series data, which is the single most common
    mistake in this kind of pipeline.
    """
    df_sorted = df.sort_values(date_column).reset_index(drop=True)
    split_index = int(len(df_sorted) * (1 - test_fraction))
    train_df = df_sorted.iloc[:split_index]
    test_df = df_sorted.iloc[split_index:]
    return train_df, test_df


def fill_missing_months(df, group_col, month_col, value_col, fill_value=0.0):
    """
    Reindexes each group (typically per user) to a continuous monthly
    calendar between its own first and last observed month, filling gaps
    with `fill_value`.

    This matters more than it looks: if a user logged nothing in, say,
    March, that month simply doesn't appear as a row from a GROUP BY
    aggregation — not a zero row, a *missing* one. Without filling that
    gap, a naive lag_1 feature would silently pull April's "1 month ago"
    value from February instead, quietly corrupting every lag/rolling
    feature downstream. This function exists specifically to prevent that.
    """
    df = df.copy()
    df[month_col] = pd.to_datetime(df[month_col])

    filled_frames = []
    for group_value, group_df in df.groupby(group_col):
        group_df = group_df.sort_values(month_col)
        full_range = pd.date_range(group_df[month_col].min(), group_df[month_col].max(), freq='MS')
        reindexed = group_df.set_index(month_col).reindex(full_range)
        reindexed[value_col] = reindexed[value_col].fillna(fill_value)
        reindexed[group_col] = group_value
        reindexed.index.name = month_col
        filled_frames.append(reindexed.reset_index())

    if not filled_frames:
        return df
    return pd.concat(filled_frames, ignore_index=True)
    """
    After one-hot encoding, train/test can end up with different columns
    (a category only present in one split). Aligns test_df's columns to
    match train_df's, filling anything missing with `fill_value` — avoids
    a shape mismatch at predict time.
    """
    train_df, test_df = train_df.align(test_df, join='left', axis=1, fill_value=fill_value)
    return train_df, test_df
