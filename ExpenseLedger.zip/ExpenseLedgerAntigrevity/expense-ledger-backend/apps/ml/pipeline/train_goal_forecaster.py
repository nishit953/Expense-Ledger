"""
Trains the goal-completion forecaster (design doc Model 5).

Honest scope note (also called out in the design doc): with this little
data, a plain arithmetic projection (remaining_amount / current_velocity)
may well outperform a fitted model — predict_goal_forecaster.py always
computes that projection as a guaranteed fallback regardless of whether a
trained model exists. This training script is a lightweight enhancement
on top of that baseline, learning from *completed* goals how
target_amount and early velocity relate to actual total days-to-complete,
rather than assuming a perfectly linear pace the whole way through.
NOT executed here.
"""
from .config import MIN_CONTRIBUTIONS_FOR_GOAL_FORECAST
from .utils import compute_regression_metrics, logger, set_random_seed


def train():
    from sklearn.linear_model import Ridge

    from . import data_loader, model_registry

    set_random_seed()

    completed_df = data_loader.load_completed_goals_with_outcomes(user=None)
    min_goals_needed = MIN_CONTRIBUTIONS_FOR_GOAL_FORECAST * 5  # need enough *completed goals*, not just contributions
    if len(completed_df) < min_goals_needed:
        logger.warning(
            f'Only {len(completed_df)} completed goal(s) with outcomes — below a useful training '
            f'size. predict_goal_forecaster.py will rely entirely on the arithmetic projection '
            f'fallback until more goals have been completed.'
        )
        return None

    feature_cols = ['target_amount', 'daily_velocity']
    # No natural date column to split on chronologically here (goals
    # complete at different, sparse times) — a random split is acceptable
    # for this one model specifically, since each row is an independent
    # completed goal rather than a sequential time series.
    from sklearn.model_selection import train_test_split
    train_df, test_df = train_test_split(completed_df, test_size=0.2, random_state=42)

    model = Ridge(alpha=1.0, random_state=42)
    model.fit(train_df[feature_cols], train_df['days_to_complete'])

    y_pred = model.predict(test_df[feature_cols])
    metrics = compute_regression_metrics(test_df['days_to_complete'], y_pred)
    logger.info(f'goal_forecaster metrics: {metrics}')

    bundle = {'model': model, 'feature_columns': feature_cols}
    relative_path = model_registry.save_model(
        bundle, model_name='goal_forecaster',
        metadata={'metrics': metrics, 'n_samples': len(completed_df)},
    )

    from apps.ml.services import record_version
    record_version(
        model_name='goal_forecaster',
        file_path=relative_path,
        training_samples=len(completed_df),
        metric_name='mae',
        metric_value=metrics['mae'],
        notes='Ridge regression on (target_amount, daily_velocity) -> days_to_complete, trained on completed goals only.',
    )

    return metrics


if __name__ == '__main__':
    train()
