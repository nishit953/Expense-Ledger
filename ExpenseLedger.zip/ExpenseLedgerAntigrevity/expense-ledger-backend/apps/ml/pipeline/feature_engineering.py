"""
One feature-builder function per model. Each takes the raw DataFrame(s)
from data_loader.py and returns model-ready X (and y, for supervised
models) — this is where each model's §5 "input features" from the design
doc actually gets assembled.
"""
from .config import WARNING_THRESHOLD_PERCENT
from .preprocessing import (
    add_per_user_rolling_stats,
    add_temporal_features,
    combine_text_fields,
    time_based_train_test_split,
    z_score_relative_to_group,
)


def build_category_classifier_features(expenses_df):
    """
    Model 1 — Category Auto-Suggestion.
    X: cleaned title+description text (vectorized by the training script itself,
       since TF-IDF fitting is stateful and belongs with the model, not here).
    y: category label.
    Returns (text_series, category_series), plus a train/test split done
    chronologically per the design doc's preprocessing rules.
    """
    df = combine_text_fields(expenses_df, fields=('title', 'description'))
    df = df[df['text'].str.len() > 0]  # rows with no usable text can't train or evaluate this model

    train_df, test_df = time_based_train_test_split(df, date_column='expense_date')
    return {
        'X_train': train_df['text'], 'y_train': train_df['category'],
        'X_test': test_df['text'], 'y_test': test_df['category'],
    }


def build_budget_risk_features(budget_history_df):
    """
    Model 2 — Budget Overspending Risk.
    X: monthly_limit, actual_spend-so-far proxy features, category (one-hot).
    y: exceeded (bool).

    NOTE: `load_budget_history_with_actuals()` only returns *closed* months
    with their final actual_spend — that's correct for building training
    labels, but at *prediction* time (an in-progress month) the caller
    must instead pass the partial-month spend-so-far computed the same way
    `budgets/services.py::get_current_spending()` already does. That's
    intentionally a separate concern from this training-feature builder.
    """
    import pandas as pd

    df = budget_history_df.copy()
    df['spend_to_limit_ratio'] = df['actual_spend'] / df['monthly_limit'].replace(0, pd.NA)
    df['spend_to_limit_ratio'] = df['spend_to_limit_ratio'].fillna(0)
    df['over_warning_threshold'] = (df['spend_to_limit_ratio'] * 100 >= WARNING_THRESHOLD_PERCENT).astype(int)

    feature_cols = ['monthly_limit', 'spend_to_limit_ratio', 'over_warning_threshold']
    df_encoded = pd.get_dummies(df, columns=['category'], prefix='category')
    feature_cols += [c for c in df_encoded.columns if c.startswith('category_')]

    train_df, test_df = time_based_train_test_split(df_encoded, date_column='month')
    return {
        'X_train': train_df[feature_cols], 'y_train': train_df['exceeded'],
        'X_test': test_df[feature_cols], 'y_test': test_df['exceeded'],
        'feature_columns': feature_cols,
    }


def build_forecast_features(monthly_totals_df, lags=(1, 2, 3)):
    """
    Model 3 — Next-Month Expense Forecast.

    Pipeline:
    1. Collapse category-level monthly totals to one row per (user, month).
    2. Gap-fill missing months to a continuous calendar per user — see
       preprocessing.fill_missing_months for why this matters.
    3. Build lag/rolling/momentum/calendar features per user.

    Returns a dict with X_train/y_train/X_test/y_test (time-based split)
    plus the raw `df_ready` (pre-split) for callers — like model
    selection — that need to run their own cross-validation over the
    full training portion rather than a single fixed split.
    """
    import pandas as pd

    from .preprocessing import fill_missing_months

    collapsed = (
        monthly_totals_df.groupby(['user_id', 'month'], as_index=False)['total']
        .sum()
    )
    filled = fill_missing_months(collapsed, group_col='user_id', month_col='month', value_col='total')
    df = filled.sort_values(['user_id', 'month']).reset_index(drop=True)

    for lag in lags:
        df[f'lag_{lag}'] = df.groupby('user_id')['total'].shift(lag)

    df['rolling_mean_3'] = df.groupby('user_id')['total'].transform(
        lambda s: s.shift(1).rolling(window=3, min_periods=1).mean()
    )
    df['rolling_std_3'] = df.groupby('user_id')['total'].transform(
        lambda s: s.shift(1).rolling(window=3, min_periods=1).std()
    ).fillna(0)

    # Momentum: is spending accelerating or decelerating month over month?
    df['momentum'] = df['lag_1'] - df['lag_2']

    dates = pd.to_datetime(df['month'])
    df['month_number'] = dates.dt.month
    df['quarter'] = dates.dt.quarter

    feature_cols = [f'lag_{lag}' for lag in lags] + [
        'rolling_mean_3', 'rolling_std_3', 'momentum', 'month_number', 'quarter',
    ]

    # A row needs every lag populated to be trainable — this is exactly
    # the cold-start boundary from the design doc, made concrete: a user
    # needs `max(lags)` prior months of (now gap-filled) history before
    # their rows are usable for training or prediction.
    df_ready = df.dropna(subset=feature_cols).reset_index(drop=True)

    train_df, test_df = time_based_train_test_split(df_ready, date_column='month')
    return {
        'X_train': train_df[feature_cols], 'y_train': train_df['total'],
        'X_test': test_df[feature_cols], 'y_test': test_df['total'],
        'feature_columns': feature_cols,
        'df_ready': df_ready,
    }


def build_anomaly_features(expenses_df):
    """
    Model 4 — Unusual Transaction Detection.
    Unsupervised — no y. Features are all relative to the user's own
    history (rolling stats, z-score) rather than absolute amounts, per
    the design doc's explicit reasoning about income variance.
    """
    df = add_temporal_features(expenses_df, date_column='expense_date')
    df = add_per_user_rolling_stats(df, group_cols=['user_id', 'category'], value_col='amount', window=5)
    df = z_score_relative_to_group(df, group_cols=['user_id', 'category'], value_col='amount')

    feature_cols = ['amount', 'amount_zscore', 'amount_rolling_mean', 'amount_rolling_std', 'day_of_week', 'is_weekend']
    return {'X': df[feature_cols], 'feature_columns': feature_cols, 'row_ids': df['id']}


def build_goal_forecast_features(contributions_df):
    """
    Model 5 — Goal Completion Forecast.
    One row per goal: contribution velocity (avg ₹/day so far) and
    remaining amount — deliberately simple per the design doc's note that
    a straight projection may outperform a "real" model here.
    """
    import pandas as pd

    if contributions_df.empty:
        return {'X': contributions_df, 'feature_columns': [], 'goal_ids': contributions_df}

    df = contributions_df.copy()
    df['date'] = pd.to_datetime(df['date'])
    df['goal__created_at'] = pd.to_datetime(df['goal__created_at']).dt.tz_localize(None)

    grouped = df.groupby('goal_id').agg(
        target_amount=('goal__target_amount', 'first'),
        saved_amount=('goal__saved_amount', 'first'),
        created_at=('goal__created_at', 'first'),
        first_contribution=('date', 'min'),
        last_contribution=('date', 'max'),
        total_contributed=('amount', 'sum'),
        contribution_count=('amount', 'count'),
    ).reset_index()

    grouped['days_active'] = (grouped['last_contribution'] - grouped['created_at']).dt.days.clip(lower=1)
    grouped['daily_velocity'] = grouped['total_contributed'] / grouped['days_active']
    grouped['remaining_amount'] = (grouped['target_amount'] - grouped['saved_amount']).clip(lower=0)

    feature_cols = ['daily_velocity', 'remaining_amount', 'contribution_count', 'days_active']
    return {'X': grouped[feature_cols], 'feature_columns': feature_cols, 'goal_ids': grouped['goal_id']}
