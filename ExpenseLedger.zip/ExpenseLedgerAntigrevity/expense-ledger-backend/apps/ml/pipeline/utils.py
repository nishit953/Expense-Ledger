"""Small, generic helpers shared across every training/prediction script."""
import functools
import logging
import random

from .config import RANDOM_SEED

logger = logging.getLogger('ml_pipeline')
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('[ml_pipeline] %(levelname)s: %(message)s'))
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)


def set_random_seed(seed=RANDOM_SEED):
    """Seeds every RNG a training script might touch, for reproducible runs."""
    import numpy as np

    random.seed(seed)
    np.random.seed(seed)


def compute_classification_metrics(y_true, y_pred, y_proba=None):
    """Standard metric bundle for classifiers (category classifier, budget risk model)."""
    from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score

    metrics = {
        'accuracy': accuracy_score(y_true, y_pred),
        'precision': precision_score(y_true, y_pred, average='weighted', zero_division=0),
        'recall': recall_score(y_true, y_pred, average='weighted', zero_division=0),
        'f1': f1_score(y_true, y_pred, average='weighted', zero_division=0),
    }
    if y_proba is not None:
        try:
            from sklearn.metrics import roc_auc_score
            metrics['roc_auc'] = roc_auc_score(y_true, y_proba)
        except ValueError:
            # roc_auc is undefined with only one class present in y_true —
            # common on small/early datasets; skip rather than crash training.
            pass
    return metrics


def compute_regression_metrics(y_true, y_pred):
    """Standard metric bundle for regressors (expense forecaster, goal forecaster)."""
    from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

    return {
        'mae': mean_absolute_error(y_true, y_pred),
        'rmse': mean_squared_error(y_true, y_pred) ** 0.5,
        'r2': r2_score(y_true, y_pred) if len(set(y_true)) > 1 else None,
    }


def compare_regressors_cv(candidates, X, y, n_splits=3):
    """
    Cross-validated model selection for regression tasks, using
    TimeSeriesSplit (not a random KFold) since the data is chronological
    and a random split would let the model "see the future" during
    validation — the same rule enforced everywhere else in this pipeline.

    `candidates`: dict of {name: unfitted sklearn estimator}.
    Returns (best_name, best_estimator_unfitted, all_scores_dict) where
    all_scores_dict maps every candidate's name to its mean CV MAE — kept
    so the caller can log/report the full comparison, not just the winner.
    """
    from sklearn.model_selection import TimeSeriesSplit, cross_val_score

    n_splits = min(n_splits, max(2, len(X) - 1))  # can't have more splits than there are samples to split
    tscv = TimeSeriesSplit(n_splits=n_splits)

    scores = {}
    for name, estimator in candidates.items():
        cv_scores = cross_val_score(estimator, X, y, cv=tscv, scoring='neg_mean_absolute_error')
        mean_mae = -cv_scores.mean()
        scores[name] = round(float(mean_mae), 2)
        logger.info(f'  candidate "{name}": CV MAE = {mean_mae:.2f}')

    best_name = min(scores, key=scores.get)
    return best_name, candidates[best_name], scores


def compare_classifiers_cv(candidates, X, y, n_splits=3, scoring='f1_weighted'):
    """Same idea as compare_regressors_cv, for classification tasks (e.g. the budget risk model)."""
    from sklearn.model_selection import StratifiedKFold, cross_val_score

    n_splits = min(n_splits, max(2, min(y.value_counts()) if hasattr(y, 'value_counts') else 2))
    skf = StratifiedKFold(n_splits=n_splits, shuffle=False)

    scores = {}
    for name, estimator in candidates.items():
        cv_scores = cross_val_score(estimator, X, y, cv=skf, scoring=scoring)
        mean_score = cv_scores.mean()
        scores[name] = round(float(mean_score), 3)
        logger.info(f'  candidate "{name}": CV {scoring} = {mean_score:.3f}')

    best_name = max(scores, key=scores.get)
    return best_name, candidates[best_name], scores
    """
    Decorator for predict_*() functions: if the sample count passed in is
    below `min_samples`, returns `fallback_value` (or calls it, if
    callable) instead of running the model — the documented cold-start
    behavior from the design doc, enforced in one place rather than
    reimplemented per model.

    The decorated function's first positional arg (after any `self`-like
    leading arg is not expected here — these are plain functions, not
    methods) must be the sample count to check.
    """

    def decorator(func):
        @functools.wraps(func)
        def wrapper(sample_count, *args, **kwargs):
            if sample_count < min_samples:
                logger.info(
                    f'{func.__name__}: only {sample_count} sample(s), below minimum {min_samples} — using fallback.'
                )
                return fallback_value(*args, **kwargs) if callable(fallback_value) else fallback_value
            return func(sample_count, *args, **kwargs)

        return wrapper

    return decorator
