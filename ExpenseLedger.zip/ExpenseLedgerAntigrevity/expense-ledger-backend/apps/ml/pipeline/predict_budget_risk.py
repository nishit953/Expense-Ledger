"""
Predicts the probability a budget will be exceeded by month-end.

Fallback (no trained model yet): reuses the exact same rule already live
in apps/budgets/services.py (>=80% used this far into the month = at
risk) so behavior is never worse than what the app already does — this
model only makes it *more* informative once trained, never regresses it.
"""
from .config import WARNING_THRESHOLD_PERCENT
from .utils import logger


def _rule_based_fallback(percentage_used, day_of_month, days_in_month):
    """Mirrors budgets/services.py's status logic, expressed as a 0-1 risk score instead of a category label."""
    month_fraction_elapsed = day_of_month / days_in_month
    if month_fraction_elapsed == 0:
        return 0.0
    pace = (percentage_used / 100) / month_fraction_elapsed
    # pace > 1 means spending faster than the month is progressing.
    risk = min(1.0, max(0.0, (pace - 1) * 0.5 + (percentage_used / 100) * 0.5))
    return round(risk, 3)


def predict_budget_risk(monthly_limit, current_spending, day_of_month, days_in_month, category):
    """Returns (risk_score, method) — risk_score in [0, 1], method is 'model' or 'rule_based_fallback'."""
    from apps.ml.services import get_active_model_path

    from .model_registry import model_cache

    percentage_used = (float(current_spending) / float(monthly_limit) * 100) if monthly_limit else 100.0

    model_path = get_active_model_path('budget_risk_model')
    if not model_path:
        logger.info('predict_budget_risk: no trained model yet — using rule-based fallback.')
        return _rule_based_fallback(percentage_used, day_of_month, days_in_month), 'rule_based_fallback'

    loaded = model_cache.get_or_load('budget_risk_model', model_path)
    if loaded is None:
        return _rule_based_fallback(percentage_used, day_of_month, days_in_month), 'rule_based_fallback'

    bundle, _metadata = loaded
    import pandas as pd

    row = {
        'monthly_limit': float(monthly_limit),
        'spend_to_limit_ratio': percentage_used / 100,
        'over_warning_threshold': int(percentage_used >= WARNING_THRESHOLD_PERCENT),
    }
    for col in bundle['feature_columns']:
        if col.startswith('category_'):
            row[col] = int(col == f'category_{category}')
    X = pd.DataFrame([row])[bundle['feature_columns']]

    proba = bundle['classifier'].predict_proba(X)[0][1]  # P(exceeded)
    return round(float(proba), 3), 'model'
