"""
Trains the budget-overspending early-warning model (design doc Model 2).

Global model pooled across all users' closed budget-months — see
data_loader.load_budget_history_with_actuals(). NOT executed here.
"""
from .config import MIN_BUDGET_MONTHS_FOR_RISK_MODEL
from .feature_engineering import build_budget_risk_features
from .utils import compute_classification_metrics, logger, set_random_seed


def train():
    from sklearn.ensemble import HistGradientBoostingClassifier

    from . import data_loader, model_registry

    set_random_seed()

    history_df = data_loader.load_budget_history_with_actuals(user=None)
    if len(history_df) < MIN_BUDGET_MONTHS_FOR_RISK_MODEL:
        logger.warning(
            f'Only {len(history_df)} closed budget-month(s) available, below the recommended '
            f'minimum {MIN_BUDGET_MONTHS_FOR_RISK_MODEL}. Training will proceed once called, but '
            f'the existing rule-based threshold in budgets/services.py remains the safer default '
            f'until there is enough history for this model to be reliable.'
        )
        return None

    features = build_budget_risk_features(history_df)

    classifier = HistGradientBoostingClassifier(random_state=42, class_weight='balanced')
    classifier.fit(features['X_train'], features['y_train'])

    y_pred = classifier.predict(features['X_test'])
    y_proba = classifier.predict_proba(features['X_test'])[:, 1]
    metrics = compute_classification_metrics(features['y_test'], y_pred, y_proba=y_proba)
    logger.info(f'budget_risk_model metrics: {metrics}')

    bundle = {'classifier': classifier, 'feature_columns': features['feature_columns']}
    relative_path = model_registry.save_model(
        bundle, model_name='budget_risk_model',
        metadata={'metrics': metrics, 'n_samples': len(history_df)},
    )

    from apps.ml.services import record_version
    record_version(
        model_name='budget_risk_model',
        file_path=relative_path,
        training_samples=len(history_df),
        metric_name='f1',
        metric_value=metrics['f1'],
        notes=f'HistGradientBoostingClassifier. accuracy={metrics["accuracy"]:.3f}',
    )

    return metrics


if __name__ == '__main__':
    train()
