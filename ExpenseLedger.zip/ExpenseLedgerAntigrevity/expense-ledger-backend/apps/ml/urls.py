from django.urls import path

from .views import (
    AnomaliesView,
    BudgetRiskView,
    ExpenseForecastView,
    GoalForecastView,
    ModelVersionListView,
    SuggestCategoryView,
)

urlpatterns = [
    path('model-versions/', ModelVersionListView.as_view(), name='ml-model-versions'),
    path('suggest-category/', SuggestCategoryView.as_view(), name='ml-suggest-category'),
    path('expense-forecast/', ExpenseForecastView.as_view(), name='ml-expense-forecast'),
    path('budget-risk/<int:id>/', BudgetRiskView.as_view(), name='ml-budget-risk'),
    path('anomalies/', AnomaliesView.as_view(), name='ml-anomalies'),
    path('goal-forecast/<int:id>/', GoalForecastView.as_view(), name='ml-goal-forecast'),
]
