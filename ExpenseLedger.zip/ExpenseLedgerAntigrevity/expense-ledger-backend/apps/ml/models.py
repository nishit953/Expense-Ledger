from django.db import models


class MLModelVersion(models.Model):
    """
    Logs each time a model artifact is (re)trained — what was trained, when,
    on how much data, how it scored on validation, and which file on disk
    it lives in. This is the entire "model management" layer for this
    project: no external MLOps tool, just a Django table + admin, which is
    the right amount of infrastructure for this project's scale.

    Only one version per `model_name` should have `is_active=True` at a
    time — that's the one prediction scripts load. Enforced in
    services.py::activate_version(), not a DB constraint, so older
    versions can be kept on disk for rollback/comparison.
    """

    MODEL_NAME_CHOICES = [
        ('category_classifier', 'Expense Category Classifier'),
        ('budget_risk_model', 'Budget Overspending Risk Model'),
        ('expense_forecaster', 'Next-Month Expense Forecaster'),
        ('anomaly_detector', 'Unusual Transaction Detector'),
        ('goal_forecaster', 'Goal Completion Forecaster'),
    ]

    model_name = models.CharField(max_length=40, choices=MODEL_NAME_CHOICES, db_index=True)
    version = models.CharField(max_length=20, help_text='e.g. 2026-07-21T14-30-00')
    file_path = models.CharField(max_length=255, help_text='Path relative to pipeline/artifacts/')

    training_samples = models.PositiveIntegerField(default=0)
    metric_name = models.CharField(max_length=50, blank=True, help_text='e.g. accuracy, mae, f1')
    metric_value = models.FloatField(null=True, blank=True)

    is_active = models.BooleanField(default=False, db_index=True)
    notes = models.TextField(blank=True)

    trained_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'ml_model_versions'
        ordering = ['-trained_at']
        indexes = [
            models.Index(fields=['model_name', 'is_active']),
        ]

    def __str__(self):
        status = 'active' if self.is_active else 'inactive'
        return f'{self.get_model_name_display()} — {self.version} ({status})'
