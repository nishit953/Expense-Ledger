from django.shortcuts import get_object_or_404
from rest_framework.generics import ListAPIView
from rest_framework.permissions import IsAdminUser, IsAuthenticated
from rest_framework.response import Response
from rest_framework.throttling import ScopedRateThrottle
from rest_framework.views import APIView

from .models import MLModelVersion
from .serializers import (
    AnomalyResultSerializer,
    BudgetRiskResponseSerializer,
    CategorySuggestionRequestSerializer,
    CategorySuggestionResponseSerializer,
    ExpenseForecastResponseSerializer,
    GoalForecastResponseSerializer,
    MLModelVersionSerializer,
)
from .pipeline.utils import logger

# Every prediction view below follows the same shape:
#   1. IsAuthenticated (+ ownership check via get_object_or_404 on a
#      user-filtered queryset, for anything scoped to one Budget/Goal —
#      404, not 403, for another user's object, matching the IsOwner
#      convention used everywhere else in this project).
#   2. ScopedRateThrottle('ml_prediction') — ML inference is more
#      expensive per-request than a typical DB-backed view (TF-IDF
#      vectorization, model loading, sklearn inference), so these get a
#      dedicated, more conservative rate limit than the rest of the API.
#   3. The actual pipeline call wrapped in try/except — a corrupted
#      artifact or unexpected sklearn error should degrade to a safe
#      response, never a raw 500 with an internal traceback leaked to
#      the client.


class ModelVersionListView(ListAPIView):
    """GET /api/ml/model-versions/?model_name= — training/version history, staff-only."""

    serializer_class = MLModelVersionSerializer
    permission_classes = [IsAdminUser]

    def get_queryset(self):
        qs = MLModelVersion.objects.all()
        model_name = self.request.query_params.get('model_name')
        if model_name:
            qs = qs.filter(model_name=model_name)
        return qs


class SuggestCategoryView(APIView):
    """POST /api/ml/suggest-category/ — { title, description } -> category suggestion for the expense form."""

    permission_classes = [IsAuthenticated]
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'ml_prediction'

    def post(self, request):
        serializer = CategorySuggestionRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        from .pipeline.predict_category import predict_category

        try:
            category, confidence, method = predict_category(
                serializer.validated_data['title'], serializer.validated_data.get('description', ''),
            )
        except Exception:
            logger.exception('SuggestCategoryView: prediction failed')
            return Response(
                {'success': False, 'message': 'Category suggestion is temporarily unavailable.'},
                status=503,
            )

        data = {'category': category, 'confidence': confidence, 'method': method}
        return Response({'success': True, 'data': CategorySuggestionResponseSerializer(data).data})


class ExpenseForecastView(APIView):
    """GET /api/ml/expense-forecast/ — next month's predicted total expense for the current user."""

    permission_classes = [IsAuthenticated]
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'ml_prediction'

    def get(self, request):
        from .pipeline.predict_expense_forecast import predict_next_month_expense
        from .services import get_user_monthly_history

        try:
            history = get_user_monthly_history(request.user)
            result = predict_next_month_expense(request.user.id, history)
        except Exception:
            logger.exception('ExpenseForecastView: prediction failed')
            return Response(
                {'success': False, 'message': 'Expense forecast is temporarily unavailable.'},
                status=503,
            )

        return Response({'success': True, 'data': ExpenseForecastResponseSerializer(result).data})


class BudgetRiskView(APIView):
    """GET /api/ml/budget-risk/{id}/ — probability this budget will be exceeded by month-end."""

    permission_classes = [IsAuthenticated]
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'ml_prediction'

    def get(self, request, id):
        from apps.budgets.models import Budget

        budget = get_object_or_404(Budget, id=id, user=request.user)

        from .pipeline.predict_budget_risk import predict_budget_risk
        from .services import get_budget_risk_context

        try:
            context = get_budget_risk_context(budget)
            risk_score, method = predict_budget_risk(**context)
        except Exception:
            logger.exception('BudgetRiskView: prediction failed for budget %s', id)
            return Response(
                {'success': False, 'message': 'Budget risk prediction is temporarily unavailable.'},
                status=503,
            )

        data = {'budget_id': budget.id, 'risk_score': risk_score, 'method': method}
        return Response({'success': True, 'data': BudgetRiskResponseSerializer(data).data})


class AnomaliesView(APIView):
    """GET /api/ml/anomalies/?days=30 — recent expenses flagged as unusual for the current user."""

    permission_classes = [IsAuthenticated]
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'ml_prediction'

    MAX_DAYS = 90  # cap how far back a client can ask this to scan, to bound the work done per request

    def get(self, request):
        try:
            days = int(request.query_params.get('days', 30))
        except (TypeError, ValueError):
            return Response({'success': False, 'message': 'days must be an integer.'}, status=400)
        days = max(1, min(days, self.MAX_DAYS))

        from .pipeline.predict_anomaly import predict_anomaly
        from .services import get_recent_expenses_with_category_history

        try:
            expense_history_pairs = get_recent_expenses_with_category_history(request.user, days=days)
            results = []
            for expense, history in expense_history_pairs:
                outcome = predict_anomaly(
                    float(expense.amount), history, day_of_week=expense.expense_date.weekday(),
                )
                if outcome['method'] == 'insufficient_history':
                    continue  # not enough history for this category yet — nothing meaningful to report
                results.append({
                    'expense_id': expense.id, 'title': expense.title, 'amount': expense.amount,
                    'expense_date': expense.expense_date, **outcome,
                })
        except Exception:
            logger.exception('AnomaliesView: prediction failed')
            return Response(
                {'success': False, 'message': 'Anomaly detection is temporarily unavailable.'},
                status=503,
            )

        flagged_only = [r for r in results if r['is_anomaly']]
        return Response({'success': True, 'data': AnomalyResultSerializer(flagged_only, many=True).data})


class GoalForecastView(APIView):
    """GET /api/ml/goal-forecast/{id}/ — estimated completion date and pace for one goal."""

    permission_classes = [IsAuthenticated]
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'ml_prediction'

    def get(self, request, id):
        from apps.goals.models import Goal

        goal = get_object_or_404(Goal, id=id, user=request.user)

        from .pipeline.predict_goal_forecast import predict_goal_forecast
        from .services import compute_goal_velocity

        try:
            context = compute_goal_velocity(goal)
            result = predict_goal_forecast(**context)
        except Exception:
            logger.exception('GoalForecastView: prediction failed for goal %s', id)
            return Response(
                {'success': False, 'message': 'Goal forecast is temporarily unavailable.'},
                status=503,
            )

        data = {'goal_id': goal.id, **result}
        return Response({'success': True, 'data': GoalForecastResponseSerializer(data).data})
