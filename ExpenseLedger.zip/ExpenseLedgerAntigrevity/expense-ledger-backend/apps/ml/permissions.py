from rest_framework.permissions import IsAdminUser

# Model version history is operational/debug information, not user data —
# restricted to staff rather than every authenticated user. Per-model
# prediction endpoints (added alongside each model) will use their own
# IsAuthenticated + IsOwner pattern, matching the rest of the project.
__all__ = ['IsAdminUser']
