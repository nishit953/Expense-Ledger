from django.contrib import admin

from .models import MLModelVersion


@admin.register(MLModelVersion)
class MLModelVersionAdmin(admin.ModelAdmin):
    list_display = ['model_name', 'version', 'is_active', 'training_samples', 'metric_name', 'metric_value', 'trained_at']
    list_filter = ['model_name', 'is_active']
    search_fields = ['version', 'notes']
    readonly_fields = ['trained_at']
