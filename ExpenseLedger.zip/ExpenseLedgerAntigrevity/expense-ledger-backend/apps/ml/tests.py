from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase

from apps.authentication.models import User
from .services import activate_version, get_active_model_path, get_active_version, has_trained_model, record_version


class MLModelVersionServiceTests(APITestCase):
    def test_record_version_activates_by_default(self):
        entry = record_version('category_classifier', 'category_classifier/v1.joblib', training_samples=120, metric_name='accuracy', metric_value=0.87)
        self.assertTrue(entry.is_active)
        self.assertEqual(get_active_version('category_classifier').id, entry.id)

    def test_recording_new_version_deactivates_previous(self):
        first = record_version('category_classifier', 'category_classifier/v1.joblib')
        second = record_version('category_classifier', 'category_classifier/v2.joblib')

        first.refresh_from_db()
        self.assertFalse(first.is_active)
        self.assertTrue(second.is_active)

    def test_record_version_without_activating(self):
        entry = record_version('budget_risk_model', 'budget_risk_model/v1.joblib', activate=False)
        self.assertFalse(entry.is_active)
        self.assertIsNone(get_active_version('budget_risk_model'))

    def test_get_active_model_path(self):
        record_version('expense_forecaster', 'expense_forecaster/v1.joblib')
        self.assertEqual(get_active_model_path('expense_forecaster'), 'expense_forecaster/v1.joblib')

    def test_get_active_model_path_none_when_untrained(self):
        self.assertIsNone(get_active_model_path('anomaly_detector'))

    def test_has_trained_model(self):
        self.assertFalse(has_trained_model('goal_forecaster'))
        record_version('goal_forecaster', 'goal_forecaster/v1.joblib')
        self.assertTrue(has_trained_model('goal_forecaster'))

    def test_activate_version_directly(self):
        first = record_version('category_classifier', 'v1.joblib')
        second = record_version('category_classifier', 'v2.joblib', activate=False)
        activate_version(second.id)

        first.refresh_from_db()
        second.refresh_from_db()
        self.assertFalse(first.is_active)
        self.assertTrue(second.is_active)


class ModelVersionListViewTests(APITestCase):
    def setUp(self):
        self.staff_user = User.objects.create_user(
            username='staff@x.com', email='staff@x.com', password='StrongPass123!', is_staff=True,
        )
        self.regular_user = User.objects.create_user(
            username='user@x.com', email='user@x.com', password='StrongPass123!',
        )
        record_version('category_classifier', 'v1.joblib', training_samples=50)

    def test_staff_can_list_versions(self):
        self.client.force_authenticate(user=self.staff_user)
        response = self.client.get(reverse('ml-model-versions'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)

    def test_regular_user_forbidden(self):
        self.client.force_authenticate(user=self.regular_user)
        response = self.client.get(reverse('ml-model-versions'))
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_filter_by_model_name(self):
        record_version('budget_risk_model', 'v1.joblib')
        self.client.force_authenticate(user=self.staff_user)
        response = self.client.get(reverse('ml-model-versions'), {'model_name': 'budget_risk_model'})
        self.assertEqual(response.data['count'], 1)


class SuggestCategoryViewTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='cat@x.com', email='cat@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)
        self.url = reverse('ml-suggest-category')

    def test_requires_auth(self):
        self.client.force_authenticate(user=None)
        response = self.client.post(self.url, {'title': 'Groceries'})
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_missing_title_rejected(self):
        response = self.client.post(self.url, {})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_blank_title_rejected(self):
        response = self.client.post(self.url, {'title': '   '})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_title_over_max_length_rejected(self):
        response = self.client.post(self.url, {'title': 'x' * 201})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_keyword_fallback_used_when_no_model_trained(self):
        response = self.client.post(self.url, {'title': 'Zomato dinner order'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['data']['category'], 'food')
        self.assertEqual(response.data['data']['method'], 'keyword_fallback')

    def test_unrecognized_text_falls_back_to_others(self):
        response = self.client.post(self.url, {'title': 'xyz qwerty asdf'})
        self.assertEqual(response.data['data']['category'], 'others')


class ExpenseForecastViewTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='fc@x.com', email='fc@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)
        self.url = reverse('ml-expense-forecast')

    def test_requires_auth(self):
        self.client.force_authenticate(user=None)
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_no_history_returns_zero_fallback(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['data']['method'], 'average_fallback')
        self.assertEqual(response.data['data']['prediction'], 0.0)


class BudgetRiskViewTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='br@x.com', email='br@x.com', password='StrongPass123!')
        self.other_user = User.objects.create_user(username='br2@x.com', email='br2@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)

    def test_requires_auth(self):
        from datetime import date

        from apps.budgets.models import Budget
        budget = Budget.objects.create(user=self.user, category='food', monthly_limit=5000, month=date.today().replace(day=1))
        self.client.force_authenticate(user=None)
        response = self.client.get(reverse('ml-budget-risk', args=[budget.id]))
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_other_users_budget_returns_404(self):
        from datetime import date

        from apps.budgets.models import Budget
        other_budget = Budget.objects.create(user=self.other_user, category='food', monthly_limit=5000, month=date.today().replace(day=1))
        response = self.client.get(reverse('ml-budget-risk', args=[other_budget.id]))
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_own_budget_returns_rule_based_fallback(self):
        from datetime import date

        from apps.budgets.models import Budget
        budget = Budget.objects.create(user=self.user, category='food', monthly_limit=5000, month=date.today().replace(day=1))
        response = self.client.get(reverse('ml-budget-risk', args=[budget.id]))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['data']['method'], 'rule_based_fallback')
        self.assertGreaterEqual(response.data['data']['risk_score'], 0.0)
        self.assertLessEqual(response.data['data']['risk_score'], 1.0)

    def test_nonexistent_budget_returns_404(self):
        response = self.client.get(reverse('ml-budget-risk', args=[99999]))
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)


class AnomaliesViewTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='an@x.com', email='an@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)
        self.url = reverse('ml-anomalies')

    def test_requires_auth(self):
        self.client.force_authenticate(user=None)
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_no_expenses_returns_empty_list(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['data'], [])

    def test_invalid_days_param_rejected(self):
        response = self.client.get(self.url, {'days': 'not-a-number'})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_days_param_is_capped(self):
        response = self.client.get(self.url, {'days': 99999})
        self.assertEqual(response.status_code, status.HTTP_200_OK)  # doesn't error, just gets clamped server-side

    def test_insufficient_history_expenses_excluded(self):
        from datetime import date

        from apps.expenses.models import Expense
        Expense.objects.create(user=self.user, title='Coffee', category='food', amount=200, payment_method='upi', expense_date=date.today())
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Only 1 prior transaction in this category — below
        # MIN_TRANSACTIONS_FOR_ANOMALY_DETECTION, so nothing should be flagged.
        self.assertEqual(response.data['data'], [])


class GoalForecastViewTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='gf@x.com', email='gf@x.com', password='StrongPass123!')
        self.other_user = User.objects.create_user(username='gf2@x.com', email='gf2@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)

    def test_requires_auth(self):
        from datetime import date, timedelta

        from apps.goals.models import Goal
        goal = Goal.objects.create(user=self.user, name='Trip', category='vacation', target_amount=10000, target_date=date.today() + timedelta(days=90))
        self.client.force_authenticate(user=None)
        response = self.client.get(reverse('ml-goal-forecast', args=[goal.id]))
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_other_users_goal_returns_404(self):
        from datetime import date, timedelta

        from apps.goals.models import Goal
        other_goal = Goal.objects.create(user=self.other_user, name='Car', category='buy_car', target_amount=500000, target_date=date.today() + timedelta(days=365))
        response = self.client.get(reverse('ml-goal-forecast', args=[other_goal.id]))
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_goal_with_no_contributions_is_stalled(self):
        from datetime import date, timedelta

        from apps.goals.models import Goal
        goal = Goal.objects.create(user=self.user, name='Trip', category='vacation', target_amount=10000, target_date=date.today() + timedelta(days=90))
        response = self.client.get(reverse('ml-goal-forecast', args=[goal.id]))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['data']['pace_status'], 'stalled')
        self.assertIsNone(response.data['data']['estimated_completion_date'])

    def test_goal_with_contributions_gets_projection(self):
        from datetime import date, timedelta

        from apps.goals.models import Goal
        from apps.goals.services import add_contribution

        goal = Goal.objects.create(
            user=self.user, name='Trip', category='vacation', target_amount=10000,
            target_date=date.today() + timedelta(days=90),
        )
        add_contribution(goal, amount=1000, contribution_date=date.today())
        response = self.client.get(reverse('ml-goal-forecast', args=[goal.id]))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['data']['method'], 'arithmetic_projection')
        self.assertIsNotNone(response.data['data']['estimated_completion_date'])
