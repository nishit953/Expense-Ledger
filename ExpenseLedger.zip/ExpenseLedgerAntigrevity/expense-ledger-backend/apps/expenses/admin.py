from django.contrib import admin

from .models import Expense


@admin.register(Expense)
class ExpenseAdmin(admin.ModelAdmin):
    list_display = ['title', 'user', 'category', 'amount', 'payment_method', 'expense_date', 'is_recurring']
    list_filter = ['category', 'payment_method', 'is_recurring', 'expense_date']
    search_fields = ['title', 'description', 'notes', 'user__email']
    date_hierarchy = 'expense_date'
    autocomplete_fields = []
