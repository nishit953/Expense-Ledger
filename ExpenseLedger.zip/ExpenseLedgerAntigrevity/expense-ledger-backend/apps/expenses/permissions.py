from rest_framework.permissions import BasePermission, SAFE_METHODS


class IsOwner(BasePermission):
    """Object-level permission: only the record's owner may read/write it."""

    def has_object_permission(self, request, view, obj):
        if request.method in SAFE_METHODS:
            return obj.user_id == request.user.id
        return obj.user_id == request.user.id
