import django_filters
from rest_framework import viewsets
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser
from rest_framework.permissions import IsAuthenticated

from .models import Expense
from .permissions import IsOwner
from .serializers import ExpenseListSerializer, ExpenseSerializer


class ExpenseFilter(django_filters.FilterSet):
    date_from = django_filters.DateFilter(field_name='expense_date', lookup_expr='gte')
    date_to = django_filters.DateFilter(field_name='expense_date', lookup_expr='lte')
    amount_min = django_filters.NumberFilter(field_name='amount', lookup_expr='gte')
    amount_max = django_filters.NumberFilter(field_name='amount', lookup_expr='lte')

    class Meta:
        model = Expense
        fields = ['category', 'payment_method', 'is_recurring', 'date_from', 'date_to', 'amount_min', 'amount_max']


class ExpenseViewSet(viewsets.ModelViewSet):
    """
    Full CRUD for expenses, scoped to the logged-in user.

    Supports:
    - search:   ?search=groceries          (title, description, notes)
    - filter:   ?category=food&payment_method=upi&date_from=2026-06-01
    - sort:     ?ordering=-amount           (amount, expense_date, created_at)
    - paginate: ?page=2                     (page size set in DRF settings)
    """

    permission_classes = [IsAuthenticated, IsOwner]
    parser_classes = [MultiPartParser, FormParser, JSONParser]
    filterset_class = ExpenseFilter
    search_fields = ['title', 'description', 'notes']
    ordering_fields = ['amount', 'expense_date', 'created_at', 'title']
    ordering = ['-expense_date']

    def get_queryset(self):
        return Expense.objects.filter(user=self.request.user)

    def get_serializer_class(self):
        if self.action == 'list':
            return ExpenseListSerializer
        return ExpenseSerializer
