from datetime import date

from django.core.files.uploadedfile import SimpleUploadedFile
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase

from apps.authentication.models import User
from .models import Expense


class ExpenseTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='a@x.com', email='a@x.com', password='StrongPass123!')
        self.other_user = User.objects.create_user(username='b@x.com', email='b@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)
        self.list_url = reverse('expense-list')

        self.expense = Expense.objects.create(
            user=self.user, title='Groceries', category='food', amount=1200,
            payment_method='upi', expense_date=date(2026, 6, 1),
        )

    def test_list_only_returns_own_expenses(self):
        Expense.objects.create(
            user=self.other_user, title='Rent', category='rent', amount=15000,
            payment_method='net_banking', expense_date=date(2026, 6, 1),
        )
        response = self.client.get(self.list_url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)

    def test_create_expense(self):
        payload = {
            'title': 'Movie night', 'category': 'entertainment', 'amount': '650.00',
            'payment_method': 'credit_card', 'expense_date': '2026-06-15',
        }
        response = self.client.post(self.list_url, payload)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Expense.objects.filter(user=self.user).count(), 2)

    def test_recurring_requires_frequency(self):
        payload = {
            'title': 'Netflix', 'category': 'entertainment', 'amount': '499.00',
            'payment_method': 'upi', 'expense_date': '2026-06-01', 'is_recurring': True,
        }
        response = self.client.post(self.list_url, payload)
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_cannot_access_other_users_expense(self):
        other_expense = Expense.objects.create(
            user=self.other_user, title='Rent', category='rent', amount=15000,
            payment_method='net_banking', expense_date=date(2026, 6, 1),
        )
        url = reverse('expense-detail', args=[other_expense.id])
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_filter_by_category(self):
        response = self.client.get(self.list_url, {'category': 'food'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)

    def test_search_by_title(self):
        response = self.client.get(self.list_url, {'search': 'grocer'})
        self.assertEqual(response.data['count'], 1)

    def test_delete_expense(self):
        url = reverse('expense-detail', args=[self.expense.id])
        response = self.client.delete(url)
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.assertFalse(Expense.objects.filter(id=self.expense.id).exists())


class ExpenseReceiptUploadTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='up@x.com', email='up@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)
        self.list_url = reverse('expense-list')

    def test_valid_receipt_upload_accepted(self):
        receipt = SimpleUploadedFile('receipt.jpg', b'fake-jpg-bytes', content_type='image/jpeg')
        payload = {
            'title': 'Grocery run', 'category': 'food', 'amount': '500.00',
            'payment_method': 'upi', 'expense_date': '2026-07-01', 'receipt': receipt,
        }
        response = self.client.post(self.list_url, payload, format='multipart')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertIsNotNone(response.data['receipt'])

    def test_invalid_file_extension_rejected(self):
        malicious = SimpleUploadedFile('malware.exe', b'fake-exe-bytes', content_type='application/octet-stream')
        payload = {
            'title': 'Suspicious', 'category': 'food', 'amount': '100.00',
            'payment_method': 'upi', 'expense_date': '2026-07-01', 'receipt': malicious,
        }
        response = self.client.post(self.list_url, payload, format='multipart')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_oversized_file_rejected(self):
        big_file = SimpleUploadedFile('big.jpg', b'x' * (6 * 1024 * 1024), content_type='image/jpeg')
        payload = {
            'title': 'Big receipt', 'category': 'food', 'amount': '100.00',
            'payment_method': 'upi', 'expense_date': '2026-07-01', 'receipt': big_file,
        }
        response = self.client.post(self.list_url, payload, format='multipart')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_pdf_receipt_accepted(self):
        pdf = SimpleUploadedFile('receipt.pdf', b'%PDF-1.4 fake', content_type='application/pdf')
        payload = {
            'title': 'Utility bill', 'category': 'bills', 'amount': '1200.00',
            'payment_method': 'net_banking', 'expense_date': '2026-07-01', 'receipt': pdf,
        }
        response = self.client.post(self.list_url, payload, format='multipart')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_expense_without_receipt_still_works(self):
        payload = {
            'title': 'Cash tip', 'category': 'food', 'amount': '50.00',
            'payment_method': 'cash', 'expense_date': '2026-07-01',
        }
        response = self.client.post(self.list_url, payload, format='multipart')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)


class ExpenseJSONContentTypeTests(APITestCase):
    """Regression test: parser_classes was previously restricted to multipart/form only, silently
    rejecting plain JSON requests (415 Unsupported Media Type) — found via live HTTP testing."""

    def setUp(self):
        self.user = User.objects.create_user(username='json@x.com', email='json@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)

    def test_create_expense_via_json(self):
        response = self.client.post(reverse('expense-list'), {
            'title': 'Coffee', 'category': 'food', 'amount': '250.00',
            'payment_method': 'upi', 'expense_date': '2026-07-25',
        }, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_update_expense_via_json(self):
        expense = Expense.objects.create(
            user=self.user, title='Coffee', category='food', amount=250,
            payment_method='upi', expense_date=date(2026, 7, 25),
        )
        response = self.client.patch(
            reverse('expense-detail', args=[expense.id]), {'amount': '300.00'}, format='json',
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
