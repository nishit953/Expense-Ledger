import uuid

from django.conf import settings
from decimal import Decimal

from django.core.validators import FileExtensionValidator, MinValueValidator
from django.db import models


def receipt_upload_path(instance, filename):
    ext = filename.split('.')[-1]
    return f'receipts/{instance.user_id}/{uuid.uuid4().hex}.{ext}'


class Expense(models.Model):
    CATEGORY_CHOICES = [
        ('food', 'Food'),
        ('transport', 'Transport'),
        ('shopping', 'Shopping'),
        ('medical', 'Medical'),
        ('bills', 'Bills'),
        ('education', 'Education'),
        ('entertainment', 'Entertainment'),
        ('investment', 'Investment'),
        ('rent', 'Rent'),
        ('others', 'Others'),
    ]

    PAYMENT_METHOD_CHOICES = [
        ('cash', 'Cash'),
        ('debit_card', 'Debit Card'),
        ('credit_card', 'Credit Card'),
        ('upi', 'UPI'),
        ('net_banking', 'Net Banking'),
        ('wallet', 'Wallet'),
        ('other', 'Other'),
    ]

    RECURRING_FREQUENCY_CHOICES = [
        ('daily', 'Daily'),
        ('weekly', 'Weekly'),
        ('monthly', 'Monthly'),
        ('yearly', 'Yearly'),
    ]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='expenses')

    title = models.CharField(max_length=200)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, db_index=True)
    amount = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal('0.01'))])
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHOD_CHOICES, default='cash')
    expense_date = models.DateField(db_index=True)
    description = models.CharField(max_length=500, blank=True)
    notes = models.TextField(max_length=1000, blank=True)
    receipt = models.FileField(
        upload_to=receipt_upload_path,
        blank=True,
        null=True,
        validators=[FileExtensionValidator(allowed_extensions=['jpg', 'jpeg', 'png', 'pdf'])],
    )

    is_recurring = models.BooleanField(default=False)
    recurring_frequency = models.CharField(
        max_length=10, choices=RECURRING_FREQUENCY_CHOICES, blank=True, null=True
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'expenses'
        ordering = ['-expense_date', '-created_at']
        indexes = [
            models.Index(fields=['user', 'expense_date']),
            models.Index(fields=['user', 'category']),
        ]

    def __str__(self):
        return f'{self.title} — ₹{self.amount} ({self.get_category_display()})'
