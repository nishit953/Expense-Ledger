from django.conf import settings
from rest_framework import serializers

from .models import Expense


class ExpenseSerializer(serializers.ModelSerializer):
    category_display = serializers.CharField(source='get_category_display', read_only=True)
    payment_method_display = serializers.CharField(source='get_payment_method_display', read_only=True)

    class Meta:
        model = Expense
        fields = [
            'id', 'title', 'category', 'category_display', 'amount', 'payment_method',
            'payment_method_display', 'expense_date', 'description', 'notes', 'receipt',
            'is_recurring', 'recurring_frequency', 'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']

    def validate_receipt(self, value):
        if value:
            max_bytes = settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024
            if value.size > max_bytes:
                raise serializers.ValidationError(
                    f'Receipt file too large. Max size is {settings.MAX_UPLOAD_SIZE_MB}MB.'
                )
        return value

    def validate(self, attrs):
        is_recurring = attrs.get('is_recurring', getattr(self.instance, 'is_recurring', False))
        frequency = attrs.get('recurring_frequency', getattr(self.instance, 'recurring_frequency', None))
        if is_recurring and not frequency:
            raise serializers.ValidationError(
                {'recurring_frequency': 'Select a frequency for recurring expenses.'}
            )
        if not is_recurring:
            attrs['recurring_frequency'] = None
        return attrs

    def create(self, validated_data):
        validated_data['user'] = self.context['request'].user
        return super().create(validated_data)


class ExpenseListSerializer(serializers.ModelSerializer):
    """Lighter serializer for list views — omits notes/description for smaller payloads."""

    category_display = serializers.CharField(source='get_category_display', read_only=True)

    class Meta:
        model = Expense
        fields = [
            'id', 'title', 'category', 'category_display', 'amount',
            'payment_method', 'expense_date', 'is_recurring', 'receipt',
        ]
