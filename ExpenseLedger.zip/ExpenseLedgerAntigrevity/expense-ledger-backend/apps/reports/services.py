import calendar
from datetime import date
from decimal import Decimal

from django.db.models import Avg, Sum


def _month_bounds(year, month):
    first = date(year, month, 1)
    last = date(year, month, calendar.monthrange(year, month)[1])
    return first, last


def _year_bounds(year):
    return date(year, 1, 1), date(year, 12, 31)


def expense_summary(user, start, end):
    from apps.analytics.services import expense_categories_breakdown
    from apps.expenses.models import Expense

    qs = Expense.objects.filter(user=user, expense_date__gte=start, expense_date__lte=end)
    agg = qs.aggregate(total=Sum('amount'), avg=Avg('amount'))
    return {
        'total': agg['total'] or Decimal('0'),
        'transaction_count': qs.count(),
        'average_transaction': round(agg['avg'] or Decimal('0'), 2),
        'by_category': expense_categories_breakdown(user, start, end),
    }


def income_summary(user, start, end):
    from apps.analytics.services import income_sources_breakdown
    from apps.income.models import Income

    qs = Income.objects.filter(user=user, income_date__gte=start, income_date__lte=end)
    agg = qs.aggregate(total=Sum('amount'), avg=Avg('amount'))
    return {
        'total': agg['total'] or Decimal('0'),
        'transaction_count': qs.count(),
        'average_transaction': round(agg['avg'] or Decimal('0'), 2),
        'by_source': income_sources_breakdown(user, start, end),
    }


def budget_summary(user, period_end):
    from apps.budgets.models import Budget
    from apps.budgets.services import annotate_budget, get_overall_budget_usage

    month = period_end.replace(day=1)
    overall = get_overall_budget_usage(user, month)
    breakdown = []
    for budget in Budget.objects.filter(user=user, month=month):
        annotated = annotate_budget(budget)
        breakdown.append({
            'category': budget.category,
            'category_display': budget.get_category_display(),
            'monthly_limit': budget.monthly_limit,
            **annotated,
        })
    return {**overall, 'breakdown': breakdown}


def savings_summary(user, start, end):
    from apps.savings.models import SavingsEntry
    from apps.savings.services import get_savings_growth_trend, get_total_savings

    saved_in_period = SavingsEntry.objects.filter(
        user=user, date__gte=start, date__lte=end
    ).aggregate(t=Sum('amount'))['t'] or Decimal('0')

    return {
        'saved_in_period': saved_in_period,
        'lifetime_total': get_total_savings(user),
        'growth_trend': get_savings_growth_trend(user, months=6),
    }


def goal_summary(user):
    from apps.goals.models import Goal
    from apps.goals.services import get_days_remaining, get_goals_summary, get_progress_percentage

    summary = get_goals_summary(user)
    nearing_completion = []
    for goal in Goal.objects.filter(user=user, status='active').order_by('target_date')[:5]:
        nearing_completion.append({
            'name': goal.name,
            'progress_percentage': get_progress_percentage(goal),
            'days_remaining': get_days_remaining(goal),
        })
    return {**summary, 'goals_nearing_deadline': nearing_completion}


def build_report(user, report_type, start, end):
    """The single entry point every report endpoint (monthly/yearly/custom, and both exporters) calls."""
    expenses = expense_summary(user, start, end)
    income = income_summary(user, start, end)
    budgets = budget_summary(user, end)
    savings = savings_summary(user, start, end)
    goals = goal_summary(user)

    top_expense_category = expenses['by_category'][0] if expenses['by_category'] else None
    highest_income_source = income['by_source'][0] if income['by_source'] else None

    return {
        'report_type': report_type,
        'period_start': start,
        'period_end': end,
        'monthly_overview': {
            'total_income': income['total'],
            'total_expense': expenses['total'],
            'net_savings': income['total'] - expenses['total'],
        },
        'expense_summary': expenses,
        'income_summary': income,
        'budget_summary': budgets,
        'savings_summary': savings,
        'goal_summary': goals,
        'top_expense_category': top_expense_category,
        'highest_income_source': highest_income_source,
        'budget_performance': budgets['percentage_used'],
    }


def monthly_report(user, year, month):
    start, end = _month_bounds(year, month)
    return build_report(user, 'monthly', start, end)


def yearly_report(user, year):
    start, end = _year_bounds(year)
    return build_report(user, 'yearly', start, end)


# --- Export generation ---------------------------------------------------
# Both exporters take the same dict build_report() returns, so the PDF and
# Excel files always match exactly what the on-screen report shows.

def generate_pdf_report(report_data, user):
    """Renders a report dict to a PDF and returns raw bytes."""
    import io

    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, topMargin=2 * cm, bottomMargin=2 * cm)
    styles = getSampleStyleSheet()
    story = []

    title = f'ExpenseLedger — {report_data["report_type"].title()} Report'
    subtitle = f'{report_data["period_start"]} to {report_data["period_end"]} · {user.email}'
    story.append(Paragraph(title, styles['Title']))
    story.append(Paragraph(subtitle, styles['Normal']))
    story.append(Spacer(1, 0.6 * cm))

    overview = report_data['monthly_overview']
    overview_table = Table(
        [
            ['Total Income', 'Total Expense', 'Net Savings'],
            [f'₹{overview["total_income"]}', f'₹{overview["total_expense"]}', f'₹{overview["net_savings"]}'],
        ],
        colWidths=[5.5 * cm] * 3,
    )
    overview_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#059669')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#E4E9E7')),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
    ]))
    story.append(overview_table)
    story.append(Spacer(1, 0.8 * cm))

    story.append(Paragraph('Expense by Category', styles['Heading2']))
    category_rows = [['Category', 'Amount', '% of Total']]
    for row in report_data['expense_summary']['by_category']:
        category_rows.append([row['category_display'], f'₹{row["total"]}', f'{row["percentage"]}%'])
    if len(category_rows) > 1:
        cat_table = Table(category_rows, colWidths=[6 * cm, 5 * cm, 4 * cm])
        cat_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#F8FAF9')),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#E4E9E7')),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
        ]))
        story.append(cat_table)
    else:
        story.append(Paragraph('No expenses recorded in this period.', styles['Normal']))
    story.append(Spacer(1, 0.6 * cm))

    story.append(Paragraph('Income by Source', styles['Heading2']))
    source_rows = [['Source', 'Amount', '% of Total']]
    for row in report_data['income_summary']['by_source']:
        source_rows.append([row['source_display'], f'₹{row["total"]}', f'{row["percentage"]}%'])
    if len(source_rows) > 1:
        src_table = Table(source_rows, colWidths=[6 * cm, 5 * cm, 4 * cm])
        src_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#F8FAF9')),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#E4E9E7')),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
        ]))
        story.append(src_table)
    else:
        story.append(Paragraph('No income recorded in this period.', styles['Normal']))
    story.append(Spacer(1, 0.6 * cm))

    story.append(Paragraph('Budget Performance', styles['Heading2']))
    budget = report_data['budget_summary']
    story.append(Paragraph(
        f'Spent ₹{budget["total_spent"]} of ₹{budget["total_limit"]} '
        f'({budget["percentage_used"]}%) across {budget["budget_count"]} budget(s).',
        styles['Normal'],
    ))
    story.append(Spacer(1, 0.4 * cm))

    story.append(Paragraph('Goals', styles['Heading2']))
    goals = report_data['goal_summary']
    story.append(Paragraph(
        f'{goals["active_goals"]} active, {goals["completed_goals"]} completed — '
        f'₹{goals["total_saved_amount"]} saved of ₹{goals["total_target_amount"]} targeted '
        f'({goals["overall_progress"]}%).',
        styles['Normal'],
    ))

    doc.build(story)
    return buffer.getvalue()


def generate_excel_report(report_data, user):
    """Renders a report dict to a multi-sheet .xlsx workbook and returns raw bytes."""
    import io

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill

    wb = Workbook()
    header_fill = PatternFill(start_color='059669', end_color='059669', fill_type='solid')
    header_font = Font(color='FFFFFF', bold=True)

    def style_header(ws, row=1):
        for cell in ws[row]:
            cell.fill = header_fill
            cell.font = header_font

    # Overview sheet
    ws = wb.active
    ws.title = 'Overview'
    ws.append(['ExpenseLedger Report', report_data['report_type'].title()])
    ws.append(['Period', f'{report_data["period_start"]} to {report_data["period_end"]}'])
    ws.append(['User', user.email])
    ws.append([])
    ws.append(['Metric', 'Amount'])
    style_header(ws, row=5)
    overview = report_data['monthly_overview']
    ws.append(['Total Income', float(overview['total_income'])])
    ws.append(['Total Expense', float(overview['total_expense'])])
    ws.append(['Net Savings', float(overview['net_savings'])])

    # Expenses by category
    ws2 = wb.create_sheet('Expenses by Category')
    ws2.append(['Category', 'Amount', 'Percentage'])
    style_header(ws2)
    for row in report_data['expense_summary']['by_category']:
        ws2.append([row['category_display'], float(row['total']), row['percentage']])

    # Income by source
    ws3 = wb.create_sheet('Income by Source')
    ws3.append(['Source', 'Amount', 'Percentage'])
    style_header(ws3)
    for row in report_data['income_summary']['by_source']:
        ws3.append([row['source_display'], float(row['total']), row['percentage']])

    # Budgets
    ws4 = wb.create_sheet('Budgets')
    ws4.append(['Category', 'Limit', 'Spent', 'Remaining', '% Used', 'Status'])
    style_header(ws4)
    for row in report_data['budget_summary']['breakdown']:
        ws4.append([
            row['category_display'], float(row['monthly_limit']), float(row['current_spending']),
            float(row['remaining_amount']), row['percentage_used'], row['status'],
        ])

    # Goals
    ws5 = wb.create_sheet('Goals')
    ws5.append(['Goal', 'Progress %', 'Days Remaining'])
    style_header(ws5)
    for row in report_data['goal_summary']['goals_nearing_deadline']:
        ws5.append([row['name'], row['progress_percentage'], row['days_remaining']])

    for sheet in wb.worksheets:
        for column_cells in sheet.columns:
            length = max(len(str(cell.value)) if cell.value is not None else 0 for cell in column_cells)
            sheet.column_dimensions[column_cells[0].column_letter].width = min(max(length + 2, 12), 40)

    buffer = io.BytesIO()
    wb.save(buffer)
    return buffer.getvalue()
