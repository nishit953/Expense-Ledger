from django.conf import settings
from django.db import models


class Report(models.Model):
    """
    A record of a generated report — history/audit only. The report's
    actual figures are never stored here; they're always recomputed live
    from expenses/income/budgets/savings/goals in services.py, so a report
    can't go stale. This model just answers "what did I generate, and when".
    """

    REPORT_TYPE_CHOICES = [
        ('monthly', 'Monthly'),
        ('yearly', 'Yearly'),
        ('custom', 'Custom Range'),
    ]

    FORMAT_CHOICES = [
        ('view', 'Viewed Only'),
        ('pdf', 'PDF Export'),
        ('excel', 'Excel Export'),
    ]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='reports')

    report_type = models.CharField(max_length=10, choices=REPORT_TYPE_CHOICES)
    period_start = models.DateField()
    period_end = models.DateField()
    export_format = models.CharField(max_length=10, choices=FORMAT_CHOICES, default='view')

    generated_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'reports'
        ordering = ['-generated_at']

    def __str__(self):
        return f'{self.get_report_type_display()} report ({self.period_start} to {self.period_end})'
