from django.urls import path

from .views import (
    ExportExcelView,
    ExportPDFView,
    MonthlyReportView,
    ReportHistoryView,
    ReportView,
    YearlyReportView,
)

urlpatterns = [
    path('', ReportView.as_view(), name='reports'),
    path('monthly/', MonthlyReportView.as_view(), name='reports-monthly'),
    path('yearly/', YearlyReportView.as_view(), name='reports-yearly'),
    path('history/', ReportHistoryView.as_view(), name='reports-history'),
    path('export/pdf/', ExportPDFView.as_view(), name='reports-export-pdf'),
    path('export/excel/', ExportExcelView.as_view(), name='reports-export-excel'),
]
