from datetime import date

from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase

from apps.authentication.models import User
from apps.expenses.models import Expense
from apps.income.models import Income
from .models import Report


class ReportTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='a@x.com', email='a@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)
        today = date.today()

        Expense.objects.create(user=self.user, title='Groceries', category='food', amount=1200, payment_method='upi', expense_date=today)
        Income.objects.create(user=self.user, source='salary', amount=84000, income_date=today)

    def test_default_report(self):
        response = self.client.get(reverse('reports'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.data['data']
        self.assertEqual(float(data['monthly_overview']['total_income']), 84000.0)
        self.assertEqual(float(data['monthly_overview']['total_expense']), 1200.0)

    def test_monthly_report(self):
        today = date.today()
        response = self.client.get(reverse('reports-monthly'), {'year': today.year, 'month': today.month})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['data']['report_type'], 'monthly')

    def test_yearly_report(self):
        response = self.client.get(reverse('reports-yearly'), {'year': date.today().year})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['data']['report_type'], 'yearly')

    def test_report_generation_logs_history(self):
        self.client.get(reverse('reports-monthly'))
        self.assertTrue(Report.objects.filter(user=self.user, report_type='monthly').exists())

    def test_history_list(self):
        self.client.get(reverse('reports-monthly'))
        response = self.client.get(reverse('reports-history'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertGreaterEqual(response.data['count'], 1)

    def test_export_pdf(self):
        response = self.client.get(reverse('reports-export-pdf'), {'type': 'monthly'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response['Content-Type'], 'application/pdf')
        self.assertTrue(Report.objects.filter(user=self.user, export_format='pdf').exists())

    def test_export_excel(self):
        response = self.client.get(reverse('reports-export-excel'), {'type': 'monthly'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('spreadsheetml', response['Content-Type'])
        self.assertTrue(Report.objects.filter(user=self.user, export_format='excel').exists())

    def test_export_custom_range(self):
        today = date.today()
        response = self.client.get(reverse('reports-export-pdf'), {
            'type': 'custom', 'date_from': today.replace(day=1).isoformat(), 'date_to': today.isoformat(),
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_requires_auth(self):
        self.client.force_authenticate(user=None)
        response = self.client.get(reverse('reports'))
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
