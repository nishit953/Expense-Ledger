from django.contrib import admin

from .models import Report


@admin.register(Report)
class ReportAdmin(admin.ModelAdmin):
    list_display = ['user', 'report_type', 'period_start', 'period_end', 'export_format', 'generated_at']
    list_filter = ['report_type', 'export_format']
    search_fields = ['user__email']
    date_hierarchy = 'generated_at'
