from datetime import date, datetime

from django.http import HttpResponse
from rest_framework.generics import ListAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from . import services
from .models import Report
from .serializers import ReportDataSerializer, ReportHistorySerializer


def _parse_date(value):
    if not value:
        return None
    return datetime.strptime(value, '%Y-%m-%d').date()


def _log_report(user, report_type, start, end, export_format='view'):
    Report.objects.create(
        user=user, report_type=report_type, period_start=start, period_end=end, export_format=export_format,
    )


class ReportView(APIView):
    """GET /api/reports/?date_from=&date_to= — custom range report; defaults to the current month."""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        date_from = _parse_date(request.query_params.get('date_from'))
        date_to = _parse_date(request.query_params.get('date_to'))

        if not date_from or not date_to:
            today = date.today()
            date_from = today.replace(day=1)
            date_to = today

        data = services.build_report(request.user, 'custom', date_from, date_to)
        _log_report(request.user, 'custom', date_from, date_to)
        return Response({'success': True, 'data': ReportDataSerializer(data).data})


class MonthlyReportView(APIView):
    """GET /api/reports/monthly/?year=2026&month=6"""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        today = date.today()
        year = int(request.query_params.get('year', today.year))
        month = int(request.query_params.get('month', today.month))

        data = services.monthly_report(request.user, year, month)
        _log_report(request.user, 'monthly', data['period_start'], data['period_end'])
        return Response({'success': True, 'data': ReportDataSerializer(data).data})


class YearlyReportView(APIView):
    """GET /api/reports/yearly/?year=2026"""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        year = int(request.query_params.get('year', date.today().year))

        data = services.yearly_report(request.user, year)
        _log_report(request.user, 'yearly', data['period_start'], data['period_end'])
        return Response({'success': True, 'data': ReportDataSerializer(data).data})


class ReportHistoryView(ListAPIView):
    """GET /api/reports/history/ — audit log of previously generated/exported reports."""

    serializer_class = ReportHistorySerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Report.objects.filter(user=self.request.user)


def _resolve_report_data(request):
    """Shared by both exporters — builds the same report the on-screen view would show."""
    report_type = request.query_params.get('type', 'monthly')
    today = date.today()

    if report_type == 'yearly':
        year = int(request.query_params.get('year', today.year))
        return services.yearly_report(request.user, year), 'yearly'

    if report_type == 'custom':
        date_from = _parse_date(request.query_params.get('date_from')) or today.replace(day=1)
        date_to = _parse_date(request.query_params.get('date_to')) or today
        return services.build_report(request.user, 'custom', date_from, date_to), 'custom'

    year = int(request.query_params.get('year', today.year))
    month = int(request.query_params.get('month', today.month))
    return services.monthly_report(request.user, year, month), 'monthly'


class ExportPDFView(APIView):
    """GET /api/reports/export/pdf/?type=monthly&year=&month= (or type=yearly / type=custom&date_from=&date_to=)"""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        data, report_type = _resolve_report_data(request)
        pdf_bytes = services.generate_pdf_report(data, request.user)
        _log_report(request.user, report_type, data['period_start'], data['period_end'], export_format='pdf')

        response = HttpResponse(pdf_bytes, content_type='application/pdf')
        filename = f'expenseledger-report-{data["period_start"]}-to-{data["period_end"]}.pdf'
        response['Content-Disposition'] = f'attachment; filename="{filename}"'
        return response


class ExportExcelView(APIView):
    """GET /api/reports/export/excel/?type=monthly&year=&month= (or type=yearly / type=custom&date_from=&date_to=)"""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        data, report_type = _resolve_report_data(request)
        excel_bytes = services.generate_excel_report(data, request.user)
        _log_report(request.user, report_type, data['period_start'], data['period_end'], export_format='excel')

        response = HttpResponse(
            excel_bytes, content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
        filename = f'expenseledger-report-{data["period_start"]}-to-{data["period_end"]}.xlsx'
        response['Content-Disposition'] = f'attachment; filename="{filename}"'
        return response
