from rest_framework.permissions import IsAuthenticated

# Report generation endpoints are scoped to request.user internally (there's
# no cross-user object being fetched by ID), so IsAuthenticated is enough.
__all__ = ['IsAuthenticated']
