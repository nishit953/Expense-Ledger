from rest_framework import serializers

from .models import Report


class ReportHistorySerializer(serializers.ModelSerializer):
    report_type_display = serializers.CharField(source='get_report_type_display', read_only=True)
    export_format_display = serializers.CharField(source='get_export_format_display', read_only=True)

    class Meta:
        model = Report
        fields = ['id', 'report_type', 'report_type_display', 'period_start', 'period_end',
                  'export_format', 'export_format_display', 'generated_at']
        read_only_fields = fields


class CategoryBreakdownSerializer(serializers.Serializer):
    category = serializers.CharField()
    category_display = serializers.CharField()
    total = serializers.DecimalField(max_digits=14, decimal_places=2)
    percentage = serializers.FloatField()


class SourceBreakdownSerializer(serializers.Serializer):
    source = serializers.CharField()
    source_display = serializers.CharField()
    total = serializers.DecimalField(max_digits=14, decimal_places=2)
    percentage = serializers.FloatField()


class ExpenseSummarySerializer(serializers.Serializer):
    total = serializers.DecimalField(max_digits=14, decimal_places=2)
    transaction_count = serializers.IntegerField()
    average_transaction = serializers.DecimalField(max_digits=14, decimal_places=2)
    by_category = CategoryBreakdownSerializer(many=True)


class IncomeSummarySerializer(serializers.Serializer):
    total = serializers.DecimalField(max_digits=14, decimal_places=2)
    transaction_count = serializers.IntegerField()
    average_transaction = serializers.DecimalField(max_digits=14, decimal_places=2)
    by_source = SourceBreakdownSerializer(many=True)


class BudgetSummarySerializer(serializers.Serializer):
    total_limit = serializers.DecimalField(max_digits=14, decimal_places=2)
    total_spent = serializers.DecimalField(max_digits=14, decimal_places=2)
    remaining = serializers.DecimalField(max_digits=14, decimal_places=2)
    percentage_used = serializers.FloatField()
    budget_count = serializers.IntegerField()
    breakdown = serializers.ListField()


class SavingsSummarySerializer(serializers.Serializer):
    saved_in_period = serializers.DecimalField(max_digits=14, decimal_places=2)
    lifetime_total = serializers.DecimalField(max_digits=14, decimal_places=2)
    growth_trend = serializers.ListField()


class GoalSummarySerializer(serializers.Serializer):
    total_goals = serializers.IntegerField()
    active_goals = serializers.IntegerField()
    completed_goals = serializers.IntegerField()
    total_target_amount = serializers.DecimalField(max_digits=14, decimal_places=2)
    total_saved_amount = serializers.DecimalField(max_digits=14, decimal_places=2)
    overall_progress = serializers.FloatField()
    goals_nearing_deadline = serializers.ListField()


class MonthlyOverviewSerializer(serializers.Serializer):
    total_income = serializers.DecimalField(max_digits=14, decimal_places=2)
    total_expense = serializers.DecimalField(max_digits=14, decimal_places=2)
    net_savings = serializers.DecimalField(max_digits=14, decimal_places=2)


class ReportDataSerializer(serializers.Serializer):
    report_type = serializers.CharField()
    period_start = serializers.DateField()
    period_end = serializers.DateField()
    monthly_overview = MonthlyOverviewSerializer()
    expense_summary = ExpenseSummarySerializer()
    income_summary = IncomeSummarySerializer()
    budget_summary = BudgetSummarySerializer()
    savings_summary = SavingsSummarySerializer()
    goal_summary = GoalSummarySerializer()
    top_expense_category = CategoryBreakdownSerializer(allow_null=True)
    highest_income_source = SourceBreakdownSerializer(allow_null=True)
    budget_performance = serializers.FloatField()
