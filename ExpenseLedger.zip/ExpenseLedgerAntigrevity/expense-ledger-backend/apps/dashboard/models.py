# The dashboard app is read-only and aggregates data from the `expenses`
# and `income` apps — it intentionally defines no models of its own.
