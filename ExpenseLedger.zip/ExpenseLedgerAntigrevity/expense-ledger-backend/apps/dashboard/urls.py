from django.urls import path

from .views import (
    ExpenseByCategoryView,
    FinancialHealthScoreView,
    IncomeBySourceView,
    MonthlyOverviewView,
    MonthlyTrendView,
    NetWorthView,
    RecentTransactionsView,
    SummaryView,
    UpcomingBillsView,
)

urlpatterns = [
    path('summary/', SummaryView.as_view(), name='dashboard-summary'),
    path('expense-by-category/', ExpenseByCategoryView.as_view(), name='dashboard-expense-by-category'),
    path('income-by-source/', IncomeBySourceView.as_view(), name='dashboard-income-by-source'),
    path('monthly-trend/', MonthlyTrendView.as_view(), name='dashboard-monthly-trend'),
    path('recent-transactions/', RecentTransactionsView.as_view(), name='dashboard-recent-transactions'),
    path('net-worth/', NetWorthView.as_view(), name='dashboard-net-worth'),
    path('financial-health/', FinancialHealthScoreView.as_view(), name='dashboard-financial-health'),
    path('upcoming-bills/', UpcomingBillsView.as_view(), name='dashboard-upcoming-bills'),
    path('monthly-overview/', MonthlyOverviewView.as_view(), name='dashboard-monthly-overview'),
]
