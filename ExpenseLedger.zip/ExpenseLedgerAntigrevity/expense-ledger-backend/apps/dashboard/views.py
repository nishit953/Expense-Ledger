import calendar
from datetime import date
from itertools import chain

from django.db.models import Sum
from django.db.models.functions import TruncMonth
from django.utils import timezone
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.expenses.models import Expense
from apps.income.models import Income

from . import services
from .serializers import (
    CategoryBreakdownSerializer,
    FinancialHealthScoreSerializer,
    MonthlyOverviewSerializer,
    NetWorthSerializer,
    RecentTransactionSerializer,
    SourceBreakdownSerializer,
    SummarySerializer,
    UpcomingBillSerializer,
)


def _month_bounds(today):
    start = today.replace(day=1)
    return start, today


class SummaryView(APIView):
    """GET /api/dashboard/summary/ — the top-row stat cards."""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        today = timezone.localdate()
        month_start, _ = _month_bounds(today)

        expenses = Expense.objects.filter(user=user)
        incomes = Income.objects.filter(user=user)

        total_expense = expenses.aggregate(t=Sum('amount'))['t'] or 0
        total_income = incomes.aggregate(t=Sum('amount'))['t'] or 0

        today_expense = expenses.filter(expense_date=today).aggregate(t=Sum('amount'))['t'] or 0
        today_income = incomes.filter(income_date=today).aggregate(t=Sum('amount'))['t'] or 0

        monthly_expense = expenses.filter(expense_date__gte=month_start).aggregate(t=Sum('amount'))['t'] or 0
        monthly_income = incomes.filter(income_date__gte=month_start).aggregate(t=Sum('amount'))['t'] or 0

        data = {
            'total_balance': total_income - total_expense,
            'today_income': today_income,
            'today_expense': today_expense,
            'monthly_income': monthly_income,
            'monthly_expense': monthly_expense,
            'total_income': total_income,
            'total_expense': total_expense,
        }
        return Response({'success': True, 'data': SummarySerializer(data).data})


class ExpenseByCategoryView(APIView):
    """GET /api/dashboard/expense-by-category/?date_from=&date_to= — for the category pie/bar chart."""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        qs = Expense.objects.filter(user=request.user)
        date_from = request.query_params.get('date_from')
        date_to = request.query_params.get('date_to')
        if date_from:
            qs = qs.filter(expense_date__gte=date_from)
        if date_to:
            qs = qs.filter(expense_date__lte=date_to)

        totals = qs.values('category').annotate(total=Sum('amount')).order_by('-total')
        grand_total = sum(row['total'] for row in totals) or 1

        category_labels = dict(Expense.CATEGORY_CHOICES)
        data = [
            {
                'category': row['category'],
                'category_display': category_labels.get(row['category'], row['category']),
                'total': row['total'],
                'percentage': round(float(row['total']) / float(grand_total) * 100, 1),
            }
            for row in totals
        ]
        return Response({'success': True, 'data': CategoryBreakdownSerializer(data, many=True).data})


class IncomeBySourceView(APIView):
    """GET /api/dashboard/income-by-source/?date_from=&date_to= — for the income source chart."""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        qs = Income.objects.filter(user=request.user)
        date_from = request.query_params.get('date_from')
        date_to = request.query_params.get('date_to')
        if date_from:
            qs = qs.filter(income_date__gte=date_from)
        if date_to:
            qs = qs.filter(income_date__lte=date_to)

        totals = qs.values('source').annotate(total=Sum('amount')).order_by('-total')
        grand_total = sum(row['total'] for row in totals) or 1

        source_labels = dict(Income.SOURCE_CHOICES)
        data = [
            {
                'source': row['source'],
                'source_display': source_labels.get(row['source'], row['source']),
                'total': row['total'],
                'percentage': round(float(row['total']) / float(grand_total) * 100, 1),
            }
            for row in totals
        ]
        return Response({'success': True, 'data': SourceBreakdownSerializer(data, many=True).data})


class MonthlyTrendView(APIView):
    """GET /api/dashboard/monthly-trend/?months=6 — spend vs. income over recent months, for the area chart."""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        months = int(request.query_params.get('months', 6))
        today = timezone.localdate()

        expense_totals = (
            Expense.objects.filter(user=request.user)
            .annotate(month=TruncMonth('expense_date'))
            .values('month')
            .annotate(total=Sum('amount'))
        )
        income_totals = (
            Income.objects.filter(user=request.user)
            .annotate(month=TruncMonth('income_date'))
            .values('month')
            .annotate(total=Sum('amount'))
        )
        expense_map = {row['month']: row['total'] for row in expense_totals}
        income_map = {row['month']: row['total'] for row in income_totals}

        results = []
        cursor = today.replace(day=1)
        buffer_months = []
        for _ in range(months):
            buffer_months.append(cursor)
            prev_month = cursor.month - 1 or 12
            prev_year = cursor.year - 1 if cursor.month == 1 else cursor.year
            cursor = date(prev_year, prev_month, 1)
        buffer_months.reverse()

        for m in buffer_months:
            results.append({
                'month': calendar.month_abbr[m.month],
                'spend': float(expense_map.get(m, 0) or 0),
                'saved': float(income_map.get(m, 0) or 0) - float(expense_map.get(m, 0) or 0),
                'income': float(income_map.get(m, 0) or 0),
            })

        return Response({'success': True, 'data': results})


class RecentTransactionsView(APIView):
    """GET /api/dashboard/recent-transactions/?limit=10 — merged, sorted feed of both expenses and income."""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        limit = int(request.query_params.get('limit', 10))
        user = request.user

        recent_expenses = [
            {
                'id': e.id, 'type': 'expense', 'title': e.title, 'amount': e.amount,
                'date': e.expense_date, 'category_or_source': e.get_category_display(),
            }
            for e in Expense.objects.filter(user=user).order_by('-expense_date', '-created_at')[:limit]
        ]
        recent_incomes = [
            {
                'id': i.id, 'type': 'income', 'title': i.get_source_display(), 'amount': i.amount,
                'date': i.income_date, 'category_or_source': i.get_source_display(),
            }
            for i in Income.objects.filter(user=user).order_by('-income_date', '-created_at')[:limit]
        ]

        merged = sorted(chain(recent_expenses, recent_incomes), key=lambda x: x['date'], reverse=True)[:limit]
        return Response({'success': True, 'data': RecentTransactionSerializer(merged, many=True).data})


class NetWorthView(APIView):
    """GET /api/dashboard/net-worth/"""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        data = services.get_net_worth(request.user)
        return Response({'success': True, 'data': NetWorthSerializer(data).data})


class FinancialHealthScoreView(APIView):
    """GET /api/dashboard/financial-health/ — temporary rule-based score (0-100)."""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        data = services.get_financial_health_score(request.user)
        return Response({'success': True, 'data': FinancialHealthScoreSerializer(data).data})


class UpcomingBillsView(APIView):
    """GET /api/dashboard/upcoming-bills/?days=30 — projected from recurring expenses."""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        days = int(request.query_params.get('days', 30))
        data = services.get_upcoming_bills(request.user, days_ahead=days)
        return Response({'success': True, 'data': UpcomingBillSerializer(data, many=True).data})


class MonthlyOverviewView(APIView):
    """GET /api/dashboard/monthly-overview/ — this month's income, expense, savings, and budget usage in one call."""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        data = services.get_monthly_overview(request.user)
        return Response({'success': True, 'data': MonthlyOverviewSerializer(data).data})
