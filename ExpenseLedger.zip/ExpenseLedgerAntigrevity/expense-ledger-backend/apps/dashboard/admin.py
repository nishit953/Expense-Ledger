# No models to register — dashboard is a read-only aggregation layer
# over the expenses and income apps, which manage their own admin views.
