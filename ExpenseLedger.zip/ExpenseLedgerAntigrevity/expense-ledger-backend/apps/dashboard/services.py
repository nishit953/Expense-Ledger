import calendar
from datetime import date, timedelta
from decimal import Decimal

from django.db.models import Sum

# --- Net worth -------------------------------------------------------------
# Rule-based, Phase 3 definition: everything the user has ever earned minus
# everything they've spent, plus whatever they've explicitly logged as
# savings. Savings entries are treated as a separate ledger (e.g. money
# moved to a savings account) rather than a subset of income/expense, so
# they're added on top rather than netted out of the balance below.


def get_net_worth(user):
    from apps.expenses.models import Expense
    from apps.income.models import Income
    from apps.savings.services import get_total_savings

    total_income = Income.objects.filter(user=user).aggregate(t=Sum('amount'))['t'] or Decimal('0')
    total_expense = Expense.objects.filter(user=user).aggregate(t=Sum('amount'))['t'] or Decimal('0')
    total_balance = total_income - total_expense
    total_savings = get_total_savings(user)

    return {
        'net_worth': total_balance + total_savings,
        'total_balance': total_balance,
        'total_savings': total_savings,
    }


# --- Financial health score --------------------------------------------------
# Temporary rule-based score (0-100), replacing a future ML-driven version.
# Weighted blend of: how much of this month's income was saved (40%), how
# well the user is staying inside their set budgets (30%), and how much of
# income this month went to expenses (30%). Documented here so it's easy to
# swap for a model later without hunting through the view layer.

def get_financial_health_score(user, today=None):
    from apps.budgets.services import get_overall_budget_usage
    from apps.expenses.models import Expense
    from apps.income.models import Income

    today = today or date.today()
    month_start = today.replace(day=1)

    monthly_income = Income.objects.filter(
        user=user, income_date__gte=month_start, income_date__lte=today
    ).aggregate(t=Sum('amount'))['t'] or Decimal('0')
    monthly_expense = Expense.objects.filter(
        user=user, expense_date__gte=month_start, expense_date__lte=today
    ).aggregate(t=Sum('amount'))['t'] or Decimal('0')

    if monthly_income > 0:
        savings_rate = float((monthly_income - monthly_expense) / monthly_income) * 100
        expense_ratio = float(monthly_expense / monthly_income) * 100
    else:
        savings_rate = 0.0
        expense_ratio = 100.0 if monthly_expense > 0 else 0.0

    savings_score = max(0.0, min(100.0, savings_rate))
    expense_score = max(0.0, min(100.0, 100 - expense_ratio))

    budget_usage = get_overall_budget_usage(user, today)
    if budget_usage['budget_count'] > 0:
        budget_score = max(0.0, min(100.0, 100 - budget_usage['percentage_used']))
    else:
        budget_score = 70.0  # neutral — no budgets set yet, neither rewarded nor penalized

    score = round(savings_score * 0.4 + budget_score * 0.3 + expense_score * 0.3)
    score = max(0, min(100, score))

    if score >= 80:
        rating = 'Excellent'
    elif score >= 60:
        rating = 'Good'
    elif score >= 40:
        rating = 'Fair'
    else:
        rating = 'Needs attention'

    return {
        'score': score,
        'rating': rating,
        'savings_rate': round(savings_rate, 1),
        'expense_ratio': round(expense_ratio, 1),
        'budget_adherence': round(budget_score, 1),
    }


# --- Upcoming bills ----------------------------------------------------------
# Derived from recurring expenses — there's no separate "bill" model, so a
# bill is inferred as the next occurrence of a recurring expense grouped by
# (title, category), projected forward from its most recent transaction.

def _advance_date(d, frequency):
    if frequency == 'daily':
        return d + timedelta(days=1)
    if frequency == 'weekly':
        return d + timedelta(weeks=1)
    if frequency == 'monthly':
        month = d.month + 1
        year = d.year + (month - 1) // 12
        month = ((month - 1) % 12) + 1
        day = min(d.day, calendar.monthrange(year, month)[1])
        return date(year, month, day)
    if frequency == 'yearly':
        try:
            return d.replace(year=d.year + 1)
        except ValueError:  # Feb 29 on a non-leap year
            return d.replace(year=d.year + 1, day=28)
    return d


def get_upcoming_bills(user, days_ahead=30, today=None):
    from apps.expenses.models import Expense

    today = today or date.today()
    recurring = Expense.objects.filter(user=user, is_recurring=True).order_by('-expense_date')

    latest_by_group = {}
    for exp in recurring:
        key = (exp.title, exp.category)
        if key not in latest_by_group:
            latest_by_group[key] = exp

    bills = []
    for exp in latest_by_group.values():
        if not exp.recurring_frequency:
            continue
        next_date = _advance_date(exp.expense_date, exp.recurring_frequency)
        # Catch up if the last logged occurrence is further in the past
        # than one cycle (avoids showing a "due" date that's already passed).
        guard = 0
        while next_date < today and guard < 500:
            next_date = _advance_date(next_date, exp.recurring_frequency)
            guard += 1

        if (next_date - today).days <= days_ahead:
            bills.append({
                'title': exp.title,
                'category': exp.category,
                'category_display': exp.get_category_display(),
                'amount': exp.amount,
                'due_date': next_date,
                'frequency': exp.recurring_frequency,
            })

    bills.sort(key=lambda b: b['due_date'])
    return bills


# --- Monthly overview ---------------------------------------------------------

def get_monthly_overview(user, today=None):
    from apps.budgets.services import get_overall_budget_usage
    from apps.expenses.models import Expense
    from apps.income.models import Income
    from apps.savings.services import get_monthly_savings

    today = today or date.today()
    month_start = today.replace(day=1)

    monthly_income = Income.objects.filter(
        user=user, income_date__gte=month_start, income_date__lte=today
    ).aggregate(t=Sum('amount'))['t'] or Decimal('0')
    monthly_expense = Expense.objects.filter(
        user=user, expense_date__gte=month_start, expense_date__lte=today
    ).aggregate(t=Sum('amount'))['t'] or Decimal('0')
    monthly_saved = get_monthly_savings(user, today)
    budget_usage = get_overall_budget_usage(user, today)

    return {
        'month': today.strftime('%B %Y'),
        'income': monthly_income,
        'expense': monthly_expense,
        'net': monthly_income - monthly_expense,
        'saved': monthly_saved,
        'budget_usage': budget_usage,
    }
