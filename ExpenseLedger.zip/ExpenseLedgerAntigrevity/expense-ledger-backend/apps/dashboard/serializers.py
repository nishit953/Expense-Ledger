from rest_framework import serializers


class SummarySerializer(serializers.Serializer):
    total_balance = serializers.DecimalField(max_digits=14, decimal_places=2)
    today_income = serializers.DecimalField(max_digits=14, decimal_places=2)
    today_expense = serializers.DecimalField(max_digits=14, decimal_places=2)
    monthly_income = serializers.DecimalField(max_digits=14, decimal_places=2)
    monthly_expense = serializers.DecimalField(max_digits=14, decimal_places=2)
    total_income = serializers.DecimalField(max_digits=14, decimal_places=2)
    total_expense = serializers.DecimalField(max_digits=14, decimal_places=2)


class CategoryBreakdownSerializer(serializers.Serializer):
    category = serializers.CharField()
    category_display = serializers.CharField()
    total = serializers.DecimalField(max_digits=14, decimal_places=2)
    percentage = serializers.FloatField()


class SourceBreakdownSerializer(serializers.Serializer):
    source = serializers.CharField()
    source_display = serializers.CharField()
    total = serializers.DecimalField(max_digits=14, decimal_places=2)
    percentage = serializers.FloatField()


class RecentTransactionSerializer(serializers.Serializer):
    """Unified shape so expenses and income can render in one activity feed."""

    id = serializers.IntegerField()
    type = serializers.ChoiceField(choices=['expense', 'income'])
    title = serializers.CharField()
    amount = serializers.DecimalField(max_digits=14, decimal_places=2)
    date = serializers.DateField()
    category_or_source = serializers.CharField()


class NetWorthSerializer(serializers.Serializer):
    net_worth = serializers.DecimalField(max_digits=14, decimal_places=2)
    total_balance = serializers.DecimalField(max_digits=14, decimal_places=2)
    total_savings = serializers.DecimalField(max_digits=14, decimal_places=2)


class FinancialHealthScoreSerializer(serializers.Serializer):
    score = serializers.IntegerField()
    rating = serializers.CharField()
    savings_rate = serializers.FloatField()
    expense_ratio = serializers.FloatField()
    budget_adherence = serializers.FloatField()


class UpcomingBillSerializer(serializers.Serializer):
    title = serializers.CharField()
    category = serializers.CharField()
    category_display = serializers.CharField()
    amount = serializers.DecimalField(max_digits=12, decimal_places=2)
    due_date = serializers.DateField()
    frequency = serializers.CharField()


class BudgetUsageSerializer(serializers.Serializer):
    total_limit = serializers.DecimalField(max_digits=14, decimal_places=2)
    total_spent = serializers.DecimalField(max_digits=14, decimal_places=2)
    remaining = serializers.DecimalField(max_digits=14, decimal_places=2)
    percentage_used = serializers.FloatField()
    budget_count = serializers.IntegerField()


class MonthlyOverviewSerializer(serializers.Serializer):
    month = serializers.CharField()
    income = serializers.DecimalField(max_digits=14, decimal_places=2)
    expense = serializers.DecimalField(max_digits=14, decimal_places=2)
    net = serializers.DecimalField(max_digits=14, decimal_places=2)
    saved = serializers.DecimalField(max_digits=14, decimal_places=2)
    budget_usage = BudgetUsageSerializer()
