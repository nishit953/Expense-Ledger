from django.urls import reverse
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase

from apps.authentication.models import User
from apps.expenses.models import Expense
from apps.income.models import Income


class DashboardTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='a@x.com', email='a@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)
        today = timezone.localdate()

        Expense.objects.create(user=self.user, title='Groceries', category='food', amount=1200, payment_method='upi', expense_date=today)
        Expense.objects.create(user=self.user, title='Rent', category='rent', amount=15000, payment_method='net_banking', expense_date=today)
        Income.objects.create(user=self.user, source='salary', amount=84000, income_date=today)

    def test_summary(self):
        response = self.client.get(reverse('dashboard-summary'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.data['data']
        self.assertEqual(float(data['total_expense']), 16200.0)
        self.assertEqual(float(data['total_income']), 84000.0)
        self.assertEqual(float(data['total_balance']), 67800.0)

    def test_expense_by_category(self):
        response = self.client.get(reverse('dashboard-expense-by-category'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['data']), 2)

    def test_recent_transactions(self):
        response = self.client.get(reverse('dashboard-recent-transactions'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['data']), 3)

    def test_monthly_trend(self):
        response = self.client.get(reverse('dashboard-monthly-trend'), {'months': 3})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['data']), 3)

    def test_requires_auth(self):
        self.client.force_authenticate(user=None)
        response = self.client.get(reverse('dashboard-summary'))
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)


class Phase3DashboardTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='c@x.com', email='c@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)
        self.today = timezone.localdate()

        Expense.objects.create(user=self.user, title='Netflix', category='entertainment', amount=499,
                                payment_method='upi', expense_date=self.today, is_recurring=True,
                                recurring_frequency='monthly')
        Income.objects.create(user=self.user, source='salary', amount=84000, income_date=self.today)

    def test_net_worth(self):
        from apps.savings.models import SavingsEntry
        SavingsEntry.objects.create(user=self.user, amount=10000, date=self.today, source='other')

        response = self.client.get(reverse('dashboard-net-worth'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.data['data']
        self.assertEqual(float(data['total_savings']), 10000.0)
        self.assertEqual(float(data['net_worth']), float(data['total_balance']) + 10000.0)

    def test_financial_health_score_in_range(self):
        response = self.client.get(reverse('dashboard-financial-health'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        score = response.data['data']['score']
        self.assertGreaterEqual(score, 0)
        self.assertLessEqual(score, 100)

    def test_upcoming_bills_includes_recurring_expense(self):
        response = self.client.get(reverse('dashboard-upcoming-bills'), {'days': 45})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        titles = [b['title'] for b in response.data['data']]
        self.assertIn('Netflix', titles)

    def test_monthly_overview(self):
        response = self.client.get(reverse('dashboard-monthly-overview'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.data['data']
        self.assertIn('budget_usage', data)
        self.assertEqual(float(data['income']), 84000.0)
