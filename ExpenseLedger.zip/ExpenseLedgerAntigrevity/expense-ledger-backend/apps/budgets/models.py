from django.conf import settings
from decimal import Decimal

from django.core.validators import MinValueValidator
from django.db import models


class Budget(models.Model):
    """
    A spending limit for one category in one calendar month.

    Current spending, remaining amount, and status are intentionally NOT
    stored here — they're derived on read (see services.py) from the
    `expenses` app, so a budget never drifts out of sync with actual
    transactions.
    """

    CATEGORY_CHOICES = [
        ('food', 'Food'),
        ('transport', 'Transport'),
        ('shopping', 'Shopping'),
        ('medical', 'Medical'),
        ('bills', 'Bills'),
        ('education', 'Education'),
        ('entertainment', 'Entertainment'),
        ('investment', 'Investment'),
        ('rent', 'Rent'),
        ('others', 'Others'),
    ]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='budgets')
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, db_index=True)
    monthly_limit = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal('0.01'))])

    # Always normalized to the first of the month — e.g. 2026-06-01 represents June 2026.
    month = models.DateField(db_index=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'budgets'
        ordering = ['-month', 'category']
        constraints = [
            models.UniqueConstraint(fields=['user', 'category', 'month'], name='unique_budget_per_category_month')
        ]
        indexes = [
            models.Index(fields=['user', 'month']),
        ]

    def __str__(self):
        return f'{self.get_category_display()} — {self.month.strftime("%B %Y")} — ₹{self.monthly_limit}'

    def save(self, *args, **kwargs):
        # Normalize to the 1st of the month regardless of what day was passed in.
        self.month = self.month.replace(day=1)
        super().save(*args, **kwargs)
