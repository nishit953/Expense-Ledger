import calendar
from decimal import Decimal

from django.db.models import Sum

STATUS_ON_TRACK = 'on_track'
STATUS_WARNING = 'warning'
STATUS_EXCEEDED = 'exceeded'

WARNING_THRESHOLD_PERCENT = 80


def month_date_range(month_date):
    """Given any date, return (first_day, last_day) of that calendar month."""
    first_day = month_date.replace(day=1)
    last_day = month_date.replace(day=calendar.monthrange(month_date.year, month_date.month)[1])
    return first_day, last_day


def get_current_spending(budget):
    """Sum of the user's expenses in `budget.category` during `budget.month`."""
    from apps.expenses.models import Expense

    first_day, last_day = month_date_range(budget.month)
    total = Expense.objects.filter(
        user=budget.user,
        category=budget.category,
        expense_date__gte=first_day,
        expense_date__lte=last_day,
    ).aggregate(total=Sum('amount'))['total']
    return total or Decimal('0')


def get_budget_status(current_spending, monthly_limit):
    if monthly_limit <= 0:
        return STATUS_EXCEEDED
    percentage = (current_spending / monthly_limit) * 100
    if percentage >= 100:
        return STATUS_EXCEEDED
    if percentage >= WARNING_THRESHOLD_PERCENT:
        return STATUS_WARNING
    return STATUS_ON_TRACK


def annotate_budget(budget):
    """Returns a dict of computed fields for a single Budget instance."""
    current_spending = get_current_spending(budget)
    remaining = budget.monthly_limit - current_spending
    percentage_used = round(float(current_spending) / float(budget.monthly_limit) * 100, 1) if budget.monthly_limit else 0
    status = get_budget_status(current_spending, budget.monthly_limit)

    return {
        'current_spending': current_spending,
        'remaining_amount': remaining,
        'percentage_used': min(percentage_used, 999.9),
        'status': status,
    }


def get_overall_budget_usage(user, month_date):
    """Aggregate usage across all of a user's budgets for one month — used on the dashboard."""
    from .models import Budget

    budgets = Budget.objects.filter(user=user, month=month_date.replace(day=1))
    total_limit = sum((b.monthly_limit for b in budgets), Decimal('0'))
    total_spent = sum((get_current_spending(b) for b in budgets), Decimal('0'))
    percentage_used = round(float(total_spent) / float(total_limit) * 100, 1) if total_limit else 0

    return {
        'total_limit': total_limit,
        'total_spent': total_spent,
        'remaining': total_limit - total_spent,
        'percentage_used': percentage_used,
        'budget_count': budgets.count(),
    }
