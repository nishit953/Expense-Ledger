from django.contrib import admin

from .models import Budget


@admin.register(Budget)
class BudgetAdmin(admin.ModelAdmin):
    list_display = ['category', 'user', 'monthly_limit', 'month']
    list_filter = ['category', 'month']
    search_fields = ['user__email']
    date_hierarchy = 'month'
