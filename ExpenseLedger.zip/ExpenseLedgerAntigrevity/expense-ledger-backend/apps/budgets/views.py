import django_filters
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated

from .models import Budget
from .permissions import IsOwner
from .serializers import BudgetSerializer


class BudgetFilter(django_filters.FilterSet):
    month = django_filters.DateFilter(field_name='month')
    month_from = django_filters.DateFilter(field_name='month', lookup_expr='gte')
    month_to = django_filters.DateFilter(field_name='month', lookup_expr='lte')

    class Meta:
        model = Budget
        fields = ['category', 'month', 'month_from', 'month_to']


class BudgetViewSet(viewsets.ModelViewSet):
    """Full CRUD for budgets, scoped to the logged-in user."""

    serializer_class = BudgetSerializer
    permission_classes = [IsAuthenticated, IsOwner]
    filterset_class = BudgetFilter
    search_fields = ['category']
    ordering_fields = ['monthly_limit', 'month', 'created_at']
    ordering = ['-month', 'category']

    def get_queryset(self):
        return Budget.objects.filter(user=self.request.user)
