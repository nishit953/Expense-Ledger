from datetime import date

from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase

from apps.authentication.models import User
from apps.expenses.models import Expense
from .models import Budget


class BudgetTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='a@x.com', email='a@x.com', password='StrongPass123!')
        self.other_user = User.objects.create_user(username='b@x.com', email='b@x.com', password='StrongPass123!')
        self.client.force_authenticate(user=self.user)
        self.list_url = reverse('budget-list')

        self.budget = Budget.objects.create(
            user=self.user, category='food', monthly_limit=5000, month=date(2026, 6, 1),
        )

    def test_create_budget(self):
        payload = {'category': 'transport', 'monthly_limit': '3000.00', 'month': '2026-06-01'}
        response = self.client.post(self.list_url, payload)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_duplicate_category_month_rejected(self):
        payload = {'category': 'food', 'monthly_limit': '4000.00', 'month': '2026-06-15'}
        response = self.client.post(self.list_url, payload)
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_month_normalized_to_first_day(self):
        self.budget.refresh_from_db()
        self.assertEqual(self.budget.month, date(2026, 6, 1))

    def test_current_spending_reflects_expenses(self):
        Expense.objects.create(
            user=self.user, title='Groceries', category='food', amount=1200,
            payment_method='upi', expense_date=date(2026, 6, 10),
        )
        response = self.client.get(reverse('budget-detail', args=[self.budget.id]))
        self.assertEqual(float(response.data['current_spending']), 1200.0)
        self.assertEqual(response.data['status'], 'on_track')

    def test_status_exceeded_when_over_limit(self):
        Expense.objects.create(
            user=self.user, title='Big shop', category='food', amount=6000,
            payment_method='upi', expense_date=date(2026, 6, 10),
        )
        response = self.client.get(reverse('budget-detail', args=[self.budget.id]))
        self.assertEqual(response.data['status'], 'exceeded')

    def test_cannot_access_other_users_budget(self):
        other_budget = Budget.objects.create(user=self.other_user, category='rent', monthly_limit=10000, month=date(2026, 6, 1))
        response = self.client.get(reverse('budget-detail', args=[other_budget.id]))
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
