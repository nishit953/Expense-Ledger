from rest_framework.permissions import BasePermission


class IsOwner(BasePermission):
    """Object-level permission: only the record's owner may read/write it."""

    def has_object_permission(self, request, view, obj):
        return obj.user_id == request.user.id
