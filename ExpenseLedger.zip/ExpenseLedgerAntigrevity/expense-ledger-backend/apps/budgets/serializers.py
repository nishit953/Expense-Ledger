from rest_framework import serializers

from .models import Budget
from .services import annotate_budget


class BudgetSerializer(serializers.ModelSerializer):
    category_display = serializers.CharField(source='get_category_display', read_only=True)
    current_spending = serializers.SerializerMethodField()
    remaining_amount = serializers.SerializerMethodField()
    percentage_used = serializers.SerializerMethodField()
    status = serializers.SerializerMethodField()

    class Meta:
        model = Budget
        fields = [
            'id', 'category', 'category_display', 'monthly_limit', 'month',
            'current_spending', 'remaining_amount', 'percentage_used', 'status',
            'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']

    def _annotated(self, obj):
        # Computed once per instance per request, cached on the instance to
        # avoid running the same aggregation query four times per row.
        if not hasattr(obj, '_annotated_cache'):
            obj._annotated_cache = annotate_budget(obj)
        return obj._annotated_cache

    def get_current_spending(self, obj):
        return self._annotated(obj)['current_spending']

    def get_remaining_amount(self, obj):
        return self._annotated(obj)['remaining_amount']

    def get_percentage_used(self, obj):
        return self._annotated(obj)['percentage_used']

    def get_status(self, obj):
        return self._annotated(obj)['status']

    def validate(self, attrs):
        user = self.context['request'].user
        category = attrs.get('category', getattr(self.instance, 'category', None))
        month = attrs.get('month', getattr(self.instance, 'month', None))

        if category and month:
            normalized_month = month.replace(day=1)
            qs = Budget.objects.filter(user=user, category=category, month=normalized_month)
            if self.instance:
                qs = qs.exclude(id=self.instance.id)
            if qs.exists():
                raise serializers.ValidationError(
                    'A budget for this category already exists for that month.'
                )
        return attrs

    def create(self, validated_data):
        validated_data['user'] = self.context['request'].user
        return super().create(validated_data)
