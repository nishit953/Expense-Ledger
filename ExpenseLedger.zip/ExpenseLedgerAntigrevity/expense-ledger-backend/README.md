# ExpenseLedger — Backend (Phase 2 + Phase 3 + Phase 4)

Django REST API for authentication, expenses, income, budgets, savings, dashboard, analytics, financial goals, reports, notifications, and settings. SQLite only, per spec.

## Stack
Django 5 · Django REST Framework · SimpleJWT · django-filter · django-cors-headers · Pillow · SQLite

## Getting started

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env            # adjust as needed
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

**Upgrading from an earlier phase?** Phase 4 added new models (`Goal`, `GoalContribution`, `Report`, `Notification`, `UserSettings`) and two new fields on `User` (`occupation`, `monthly_income`); Phase 6 adds one new model (`MLModelVersion`, in the new `ml` app). Run `makemigrations` and `migrate` again even if you already had the database set up, or these tables won't exist yet.

API is served at `http://localhost:8000/api/`. Admin at `http://localhost:8000/admin/`.

Emails (registration OTP, password reset) print to the **console** in dev — check the `runserver` terminal, nothing is actually sent.

## Apps

| App | Responsibility |
|---|---|
| `authentication` | Custom `User` model (email login), register/login/logout, profile, change password, forgot/reset password, email verification via OTP |
| `expenses` | `Expense` model + full CRUD, categories, receipt upload, recurring flag, search/filter/sort/pagination |
| `income` | `Income` model + full CRUD, sources, recurring flag, search/filter/sort/pagination |
| `dashboard` | Read-only aggregation endpoints (no models) — summary cards, category/source breakdowns, monthly trend, recent transactions, **net worth, financial health score, upcoming bills, monthly overview (Phase 3)** |
| `budgets` | `Budget` model (per user/category/month) + CRUD. Spending, remaining amount, and status are **computed live** from `expenses`, never stored, so a budget can't drift out of sync |
| `savings` | `SavingsEntry` model + CRUD, plus a `/stats/` endpoint (total, this month, emergency fund, 6-month growth trend) |
| `analytics` | Read-only, single aggregated endpoint covering monthly trends, category/source breakdowns, weekly spending pattern, savings trend, budget usage, financial overview, and statistics — all filterable by period |
| `goals` | `Goal` + `GoalContribution` models. Progress %, days remaining, and status are derived; contributions update `saved_amount` atomically and auto-complete the goal when the target is reached, firing a success notification |
| `reports` | `Report` model (generation history log only — figures are always computed live). Monthly/yearly/custom summaries across expenses, income, budgets, savings, and goals, plus PDF (reportlab) and Excel (openpyxl) export that render the exact same data as the on-screen report |
| `notifications` | `Notification` model + rule-based generator (`run_notification_checks`) — budget alerts, goal reminders, bill reminders, low-savings alerts, monthly nudge. Deduplicated per condition per period, and each category respects the user's `settings_app` preferences. No task queue in this phase, so generation runs on-demand (e.g. on dashboard/notification-bell load) rather than on a schedule |
| `settings_app` | `UserSettings` — one-to-one, auto-created on first access. Theme, currency, language, per-category notification toggles, two-factor flag |
| `ml` | **Phase 6 — infrastructure + Expense Forecaster fully built and verified; all 5 models now have live REST endpoints.** `MLModelVersion` logs training runs; `pipeline/` holds data loading, preprocessing, feature engineering, training scripts, and prediction scripts (each with a working non-ML fallback) for 5 models. See "Machine Learning module" below. |
| `insights` | **AI Insights engine** — synthesizes the 5 ML models' predictions plus existing rule-based analytics (financial health score, budget status) into personalized, prioritized, plain-language recommendations across 6 categories. Computed live on every request, nothing persisted. See "AI Insights module" below. |

Each app follows: `models.py`, `serializers.py`, `views.py`, `urls.py`, `admin.py`, `permissions.py`, `tests.py` (`budgets`, `savings`, `analytics`, `dashboard`, `goals`, `reports`, `notifications`, `settings_app` also have `services.py` — see below).

## Key endpoints

```
POST   /api/auth/register/
POST   /api/auth/login/                 { email, password, remember_me }
POST   /api/auth/logout/                { refresh }
POST   /api/auth/token/refresh/         { refresh }
GET    /api/auth/profile/
PATCH  /api/auth/profile/               multipart/form-data (avatar, bio, etc.)
POST   /api/auth/change-password/
POST   /api/auth/forgot-password/       { email }
POST   /api/auth/reset-password/        { email, code, new_password, confirm_new_password }
POST   /api/auth/verify-email/          { email, code }
POST   /api/auth/resend-otp/            { email, purpose }

GET    /api/expenses/                   ?search=&category=&payment_method=&date_from=&date_to=&ordering=&page=
POST   /api/expenses/                   multipart/form-data (for receipt)
GET    /api/expenses/{id}/
PATCH  /api/expenses/{id}/
DELETE /api/expenses/{id}/

GET    /api/income/                     ?search=&source=&date_from=&date_to=&ordering=&page=
POST   /api/income/
PATCH  /api/income/{id}/
DELETE /api/income/{id}/

GET    /api/dashboard/summary/
GET    /api/dashboard/expense-by-category/
GET    /api/dashboard/income-by-source/
GET    /api/dashboard/monthly-trend/?months=6
GET    /api/dashboard/recent-transactions/?limit=8
GET    /api/dashboard/net-worth/
GET    /api/dashboard/financial-health/
GET    /api/dashboard/upcoming-bills/?days=30
GET    /api/dashboard/monthly-overview/

GET    /api/budgets/                    ?category=&month=&month_from=&month_to=&search=&ordering=&page=
POST   /api/budgets/                    { category, monthly_limit, month }
PATCH  /api/budgets/{id}/
DELETE /api/budgets/{id}/

GET    /api/savings/                    ?source=&is_emergency_fund=&date_from=&date_to=&search=&ordering=&page=
POST   /api/savings/
PATCH  /api/savings/{id}/
DELETE /api/savings/{id}/
GET    /api/savings/stats/              total, this month, emergency fund, 6-month growth trend

GET    /api/analytics/?period=this_month
GET    /api/analytics/?period=custom&date_from=2026-01-01&date_to=2026-06-30

GET    /api/goals/                      ?category=&priority=&status=&search=&ordering=&page=
POST   /api/goals/                      { name, category, target_amount, target_date, priority, description }
PATCH  /api/goals/{id}/
DELETE /api/goals/{id}/
GET    /api/goals/{id}/                 includes full contribution history
GET    /api/goals/summary/
POST   /api/goals/{id}/contribute/      { amount, date, note } — auto-completes the goal if target is reached
POST   /api/goals/{id}/abandon/
POST   /api/goals/{id}/reactivate/

GET    /api/reports/                    ?date_from=&date_to= (defaults to current month)
GET    /api/reports/monthly/?year=&month=
GET    /api/reports/yearly/?year=
GET    /api/reports/history/
GET    /api/reports/export/pdf/?type=monthly|yearly|custom&year=&month=&date_from=&date_to=
GET    /api/reports/export/excel/?type=monthly|yearly|custom&year=&month=&date_from=&date_to=

GET    /api/notifications/              ?type=&category=&is_read=
DELETE /api/notifications/{id}/
PATCH  /api/notifications/{id}/read/
POST   /api/notifications/mark-all-read/
GET    /api/notifications/unread-count/
POST   /api/notifications/generate/     runs all rule-based checks on demand

GET    /api/settings/
PATCH  /api/settings/                   { theme, currency, language, notify_*, two_factor_enabled }

GET    /api/ml/model-versions/?model_name=   staff-only — training/version history (nothing trained yet)
POST   /api/ml/suggest-category/             { title, description } -> { category, confidence, method }
GET    /api/ml/expense-forecast/             -> { prediction, method, months_used }
GET    /api/ml/budget-risk/{id}/             -> { budget_id, risk_score, method } — 404 if not your budget
GET    /api/ml/anomalies/?days=30            -> [{ expense_id, title, amount, is_anomaly, score, method }] (flagged only)
GET    /api/ml/goal-forecast/{id}/           -> { goal_id, estimated_completion_date, pace_status, method } — 404 if not your goal
```

**Every prediction endpoint right now returns its documented fallback**, not a trained model's output — `method` in each response makes this explicit (`keyword_fallback`, `rule_based_fallback`, `average_fallback`, `zscore_fallback`, `arithmetic_projection`). This flips to `'model'` automatically the moment `python manage.py train_ml_models` is run against real data — no code or endpoint changes needed, since `services.get_active_model_path()` is what each `predict_*()` function checks.

**Security/production-readiness for these 5 endpoints specifically:**
- `IsAuthenticated` + a dedicated `ml_prediction` DRF throttle scope (`30/min`, configured additively in `REST_FRAMEWORK['DEFAULT_THROTTLE_RATES']` — doesn't affect any other endpoint's rate limit) — ML inference (TF-IDF vectorization, sklearn `.predict()`) is genuinely more expensive per-request than a typical DB-backed view.
- Budget/goal-scoped endpoints use `get_object_or_404(Model, id=id, user=request.user)` — a request for another user's budget/goal 404s, not 403s, matching the ID-enumeration-resistant pattern used everywhere else in this project.
- `suggest-category`'s request body is validated by a serializer with the *same* length limits as the `Expense` model it eventually feeds (`title` ≤200 chars, `description` ≤500) — not an arbitrary separate limit that could drift out of sync.
- Every view wraps its pipeline call in `try/except`, logs the real exception server-side, and returns a generic `503` — a corrupted model artifact or an unexpected sklearn error never leaks a stack trace to the client.

## Machine Learning module (Phase 6 — infrastructure only, no models trained yet)

`apps/ml/` is additive — nothing in any other app was touched. It has two layers:

- **`apps/ml/` (Django-aware):** `MLModelVersion` model + admin + a staff-only read endpoint for training history. `services.py` is the *only* bridge between Django and the ML code — it logs/activates versions and hands prediction scripts a file path to load.
- **`apps/ml/pipeline/` (framework-agnostic):** everything else. Verified via static AST analysis that no module here imports Django at the top level — every Django/`apps.*` touchpoint is deferred inside a function body, the same pattern used everywhere else in this project. `data_loader.py` is the one exception that legitimately needs the ORM (to pull data out of it in the first place), but even there the Django imports are deferred per-function.

| File | Role |
|---|---|
| `config.py` | Constants — artifact paths, category lists (mirrors `Expense.CATEGORY_CHOICES` without importing it), cold-start thresholds |
| `utils.py` | Logging, RNG seeding, classification/regression metric helpers, a `cold_start_guard` decorator |
| `data_loader.py` | Pulls Expense/Income/Budget/Goal data into pandas DataFrames |
| `preprocessing.py` | Text cleaning, temporal features, per-user rolling stats/z-scores, **time-based** (not random) train/test split |
| `feature_engineering.py` | One feature-builder function per model, assembling the exact inputs described in the design doc |
| `model_registry.py` | `joblib` save/load, artifact path resolution, a process-wide model cache |
| `train_*.py` (×5) | Complete, runnable training scripts — **not executed as part of this setup** |
| `predict_*.py` (×5) | Prediction functions — each has a **working non-ML fallback** (keyword rules, z-score, rule-based risk, arithmetic projection) so every prediction path is testable and usable *before* any model is trained, and degrades gracefully rather than erroring if a model is later deleted or fails to load |

**Models planned** (see the design doc from the prior phase for full reasoning): expense category auto-suggestion, budget overspending risk, next-month expense forecast, unusual-transaction detection, goal-completion forecast. Deliberately **not** planning to ML-ify the Financial Health Score — there's no ground-truth label for it in the schema, so it stays rule-based.

**Training is a manual CLI action**, not scheduled — consistent with this project's existing precedent (notifications are generated on-demand too, since there's no task queue):
```bash
python manage.py train_ml_models --model category_classifier
python manage.py train_ml_models --model all
```
Not run yet. New dependencies (`scikit-learn`, `pandas`, `numpy`, `joblib`) are in `requirements.txt` but nothing has been trained, so `pipeline/artifacts/` is empty and every `predict_*()` function currently returns its fallback value.

**Prediction API endpoints** (`/ml/suggest-category/`, `/ml/budget-risk/{id}/`, etc.) are intentionally not built yet — they land one at a time alongside each model's implementation, per the phased plan.

## Design notes for the Phase 4 additions

- **Goals never store a "false" status.** `saved_amount` and `status` only change inside `goals/services.py::add_contribution()`, wrapped in a single `@transaction.atomic` block, so a contribution and the resulting status flip (including the success notification) can't partially apply.
- **Notifications are rule-based and deduplicated, not scheduled.** There's no Celery/task queue in this phase, so `run_notification_checks()` is called on-demand — the frontend triggers it via `POST /notifications/generate/` when the notification bell loads. Every check writes a `dedupe_key` (e.g. `budget-exceeded-{id}-{month}`) so re-running the checks never creates duplicate alerts for the same underlying condition.
- **Notification preferences are enforced at generation time**, not at read time — each `check_*` function in `notifications/services.py` looks up the user's `UserSettings` and returns early if that category is turned off, rather than generating-then-filtering.
- **Reports never store figures.** The `Report` model is purely a history log (what was generated, when, in what format) — `reports/services.py::build_report()` recomputes everything live from `expenses`, `income`, `budgets`, `savings`, and `goals` every time, and both the PDF and Excel exporters consume that exact same dict, so the two file formats and the on-screen report can never drift apart from each other.
- **Profile Improvements** landed as an extension of the existing `authentication` app rather than a new one — `occupation` and `monthly_income` were added to `User`, and `GET /api/auth/profile/summary/` combines goal summary + account statistics + recent activity into one call (deferred imports from `goals`/`expenses`/`income`/`savings`, same pattern as everywhere else, since `authentication` is a foundational app other apps depend on).

## Design notes for the Phase 3 additions

- **`services.py`**: `budgets`, `savings`, `analytics`, and `dashboard` each have one. Anything that touches more than one app's models (e.g. a budget's spending pulling from `expenses`, net worth pulling from `income` + `expenses` + `savings`) lives in a service function, not inline in a view — keeps the aggregation logic testable and reusable across endpoints. All cross-app imports inside these are deferred (imported inside the function, not at module top) specifically to avoid circular imports between apps that reference each other.
- **Budget status is never stored.** `current_spending`, `remaining_amount`, `percentage_used`, and `status` are computed from live `Expense` rows every time a budget is serialized — a budget can never silently drift out of sync with actual transactions. Status: `on_track` (<80%), `warning` (80–100%), `exceeded` (≥100%).
- **Financial health score is explicitly rule-based, not ML** (per the brief — a real model is future work). It's a weighted blend: 40% savings rate this month, 30% budget adherence, 30% expense-to-income ratio. The weighting and thresholds are documented inline in `dashboard/services.py` so they're easy to find and swap out later.
- **Net worth** = (lifetime income − lifetime expense) + lifetime savings. Savings entries are treated as a separate ledger the user explicitly logs (e.g. money moved to a savings account), not a subset of expenses, so they're added on top rather than netted out — documented in `dashboard/services.py` since it's a modeling decision, not an obvious default.
- **Upcoming bills** are inferred, not a separate model — there's no "Bill" table. A bill is the next projected occurrence of a recurring expense, grouped by `(title, category)`, advanced forward from its most recent transaction date using its `recurring_frequency`.
- **Analytics periods** (`today`, `this_week`, `this_month`, `last_month`, `last_6_months`, `this_year`, `custom`) resolve to a `(start, end)` date pair in `analytics/services.py::resolve_date_range()`. `custom` requires both `date_from` and `date_to` or the endpoint returns a 400.

All endpoints except register/login/forgot-password/reset-password/verify-email/resend-otp require
`Authorization: Bearer <access_token>`.

## Auth design notes

- **Login by email**, not username — `User.USERNAME_FIELD = 'email'`. A `username` field still exists internally (set equal to the email) so Django's built-in auth machinery keeps working untouched.
- **Remember me** doesn't add a second auth mechanism. `CustomTokenObtainPairSerializer` just stretches the refresh token's expiry (`REMEMBER_ME_REFRESH_LIFETIME_DAYS`, default 30 days) when the client sends `remember_me: true`; otherwise it uses the normal short-lived refresh token.
- **Email verification & password reset** both use the same `EmailVerificationToken` model with a `purpose` field — a 6-digit OTP, 10-minute expiry, single use.
- **Ownership** is enforced at two layers: querysets are scoped to `request.user` in `get_queryset()`, and `IsOwner` double-checks at the object level — a 404 (not 403) is returned for another user's record, so IDs can't be enumerated.

## Running tests

```bash
python manage.py test
```

Covers registration/login/validation, profile updates, email verification, expense/income CRUD + ownership isolation + filtering, and dashboard aggregation math.

## Switching to MongoDB later

Per the brief, this phase is SQLite-only by design. When MongoDB integration begins, the cleanest path is `djongo` or a parallel read-model synced from Django signals — but that's explicitly out of scope here.

## AI Insights module

`apps/insights/` is a pure synthesis layer — it computes nothing new, it only phrases outputs already produced by `apps.ml`, `apps.budgets`, `apps.savings`, `apps.goals`, `apps.dashboard`, and `apps.reports` into readable, prioritized recommendations. It is **not itself a trained model**: there's no plausible labeled dataset for "which recommendation should be shown" without fabricating ground truth, the same reasoning that kept the Financial Health Score rule-based back in the Phase 6 design doc.

```
GET /api/insights/?category=overspending
```
`category` is optional — one of `overspending`, `budget`, `savings`, `goal`, `monthly_summary`, `health`. Omit it for the combined feed, sorted `high → medium → low → info`.

**The 6 categories and what feeds each one:**

| Category | Synthesizes |
|---|---|
| Overspending alerts | Already-exceeded budgets + the budget-risk model's predictions for at-risk budgets + the anomaly detector's flags on recent expenses |
| Budget suggestions | Categories with real recent spend but no budget set (from raw `Expense` aggregation) + existing budgets sitting well under their limit near month-end |
| Savings recommendations | Savings rate (from the existing financial health score) against a 20%-target rule of thumb + emergency fund coverage (from `savings.services`) against a 3-month rule of thumb |
| Goal progress advice | The goal-completion forecaster's `pace_status` for every active goal, translated into a specific required daily contribution when behind |
| Monthly financial summary | `reports.services.monthly_report()` — reused, not reimplemented — turned into one narrative paragraph |
| Financial health insights | The existing rule-based financial health score, decomposed into its three named components with specific advice for whichever is weak |

**Nothing here is persisted** — an insight like "you're overspending on Food" would actively mislead if cached and shown after the user fixes it, so every request recomputes fresh (same design choice as `analytics` and `dashboard`). Discrete alerts that genuinely need read/dismissed state already have a home in the `notifications` app; insights intentionally doesn't duplicate that.

**Security:** `IsAuthenticated`, plus its own `insights` throttle scope (`15/min` — more conservative than the `ml_prediction` scope, since one request here transitively runs the budget-risk and goal-forecast models across *every* one of a user's active budgets and goals, not just one). One category generator failing doesn't take the others down — logged and skipped.

**Frontend:** a new `/app/insights` page (added the same way every other module got its own page — new sidebar link, new route, zero new design components, built entirely from `Card`/`EmptyState`/`Skeleton` already in the project) plus a "Top 3" teaser card slotted into the Dashboard's existing right column next to Recent Transactions.
