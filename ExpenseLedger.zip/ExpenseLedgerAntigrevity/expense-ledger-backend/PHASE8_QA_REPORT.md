# ExpenseLedger — Phase 8: Testing & Quality Assurance Report

**A note on what changed about how this audit was done:** for every previous phase of this project, I had no working Django or Node.js install in my environment — everything was verified via static analysis (syntax checks, AST-based import tracing, manual logic tracing). Partway through this phase, `pip`/`npm` installs that had failed all along suddenly started working. That meant this was the **first time in the project's history I could actually run the real test suite, the real Django dev server, and a real production frontend build** — and it surfaced genuine bugs that months of static analysis had missed. This report reflects real execution, not just review.

---

## Summary

| | |
|---|---|
| Backend tests | **143/143 passing** (0 before this phase — the suite had never been run) |
| Frontend build | Clean production build, 2845 modules, 0 errors |
| Frontend lint | Clean, 0 errors/warnings (after fixing the lint tooling itself — see below) |
| Real bugs found & fixed | **6** |
| Dead code removed | 7 unused imports (Python) + 1 unused import (JS) |
| Live HTTP smoke tests | Full register → verify → login → CRUD → ML → Insights journey, all passing |

---

## Bugs found and fixed

### 1. `ResendOTPView` was completely missing — the app couldn't start
**Severity: Critical.** `apps/authentication/views.py` no longer defined `ResendOTPView`, even though `urls.py` imported and used it. This traces back to a str_replace edit several phases ago, when adding `ProfileSummaryView`: I used `ResendOTPView`'s body as the anchor text to insert after, and the replacement wholesale deleted it instead of inserting alongside it. **This has been silently breaking `python manage.py migrate`/`runserver` since that turn** — every static syntax check I ran (`py_compile`) passed, because each file was independently valid Python; only an actual import resolution (`from .views import ResendOTPView` failing with `ImportError`) could catch it. This is the single clearest example of why this phase needed real execution, not more static review.
**Fix:** restored the class in full.

### 2. `Decimal`/`float` type mismatch crashing analytics
**Severity: High.** `apps/analytics/services.py::compute_statistics()` did `Decimal - float`, which Python raises a `TypeError` for. Found via `python manage.py test` (2 of the original 4 failures).
**Fix:** cast both operands to `float` before subtracting.

### 3. `record_version()` returned a stale object after activation
**Severity: Medium.** `apps/ml/services.py::record_version()` called `activate_version(entry.id)` (which correctly updates the DB) but then returned the *original*, pre-activation Python object rather than the refreshed one — so `entry.is_active` read `False` immediately after the function that's supposed to activate it. Found via the same test run (2 of the original 4 failures).
**Fix:** capture and return `activate_version()`'s result instead of the stale local variable.

### 4. Expense and Profile endpoints silently rejected plain JSON requests
**Severity: High — real API design bug, not caught by any prior test.** `ExpenseViewSet` and `ProfileView` both explicitly set `parser_classes = [MultiPartParser, FormParser]` to support file uploads (receipt/avatar) — but that **replaced** DRF's default parsers instead of adding to them, so a completely standard `POST`/`PATCH` with `Content-Type: application/json` got a `415 Unsupported Media Type`. The React frontend never hit this (it always sends `multipart/form-data`, even without a file), which is exactly why no one — including 143 passing unit tests, which used DRF's test client with implicit multipart handling — had ever caught it. It only surfaced when I hit the live server with `curl` and plain JSON, simulating any other API consumer (mobile app, Postman, a script).
**Fix:** added `JSONParser` alongside the existing parsers on both views. Added regression tests (`ExpenseJSONContentTypeTests`, `ProfileJSONContentTypeTests`) exercising the JSON path specifically, so this can't silently regress again.

### 5. OTP emails failed completely silently
**Severity: Medium — real production observability gap.** `send_otp_email()` used `fail_silently=True`. When the configured Gmail SMTP credentials are wrong or unreachable (exactly the case in this sandbox, and a realistic risk for anyone who hasn't finished their Gmail App Password setup), the user gets told "Account created. Check your email for a verification code." and **the code never arrives, with zero trace anywhere** — not in the response, not in the server log, nowhere.
**Fix:** wrapped the send in `try/except`, logging the full exception via Python's `logging` module on failure, while still letting registration succeed (a flaky mail provider shouldn't block account creation — that resilience was correct and is preserved). Verified live: the same failure now produces a clear, traceback-included log entry instead of silence.

### 6. `MinValueValidator(0.01)` used a plain float instead of `Decimal`, across 6 model fields
**Severity: Low — real type-correctness issue, was firing a runtime warning on every request.** `Expense.amount`, `Income.amount`, `Budget.monthly_limit`, `SavingsEntry.amount`, `Goal.target_amount`, and `GoalContribution.amount` all validated against a bare `0.01` float instead of `Decimal('0.01')`, which doesn't match the field's own type and triggered `UserWarning: min_value should be a Decimal instance` on every single request touching these models — visible in every test run and, presumably, every production log line, from day one.
**Fix:** corrected all 6 to `Decimal('0.01')`, added the accompanying migrations, confirmed the warning is completely gone from a full test run.

---

## Tooling gap found and fixed: `npm run lint` was completely non-functional

`package.json` declared a `lint` script and the ESLint/React plugin dependencies, but **no ESLint config file was ever created** — running `npm run lint` failed immediately with "ESLint couldn't find a configuration file." Created `.eslintrc.cjs` with `eslint:recommended` + `react/recommended` + `react-hooks/recommended`.

**Second-order gotcha caught immediately after fixing the first one:** ESLint 8's `eslint .` only scans `.js` files by default, silently skipping `.jsx` — so the first real run reported "0 problems," which was a false clean bill of health, not an accurate one. Re-ran with `--ext .js,.jsx` and found 10 real issues (see below). Updated the `lint` script itself to `eslint . --ext .js,.jsx` so this can't silently regress.

## Dead code removed

**Backend (Python, found via AST-based unused-import analysis):**
- `authentication/serializers.py` — unused `timezone` import
- `dashboard/serializers.py` — unused `ExpenseListSerializer`, `IncomeSerializer` imports (leftover from an earlier design)
- `dashboard/tests.py` — unused `date` import
- `ml/pipeline/model_registry.py` — unused `Path` import
- `ml/pipeline/train_category_classifier.py` — unused `MODEL_FILENAMES` import
- `ml/pipeline/train_goal_forecaster.py` — unused `time_based_train_test_split` import (this model deliberately uses a random split, per its own documented reasoning — the import was just left over)
- `ml/tests.py` — unused `MLModelVersion` import (every test goes through the services layer)

**Not removed — confirmed intentional, not dead:** several `permissions.py` files (`analytics`, `insights`, `ml`, `reports`, `settings_app`) import `IsAuthenticated`/`IsAdminUser` purely to re-export via `__all__`, a legitimate Python idiom the AST scan flags as "unused" but isn't.

**Frontend (JS, found via real ESLint execution):**
- `components/layout/Navbar.jsx` — unused `Link` import
- 9x `react/no-unescaped-entities` violations (raw `'` in JSX text like "don't", "isn't") — fixed by switching to proper typographic apostrophes, which is both lint-clean and better typography than the `&apos;` HTML entity alternative.

---

## What was tested and how

| Checklist item | Method |
|---|---|
| 1. Every frontend page | Real Vite production build (2845 modules, 0 errors) + real ESLint pass |
| 2. Every DREST endpoint | 143 real Django tests + live `curl` smoke test against a running dev server |
| 3. Auth & authorization | Dedicated tests per app for `IsAuthenticated`/`IsOwner` (401 for anonymous, 404 for another user's object) + live register-verify-login journey |
| 4. CRUD per module | Existing per-app test suites, all passing for real for the first time |
| 5. ML prediction APIs | Existing test suites + live `curl` to `/ml/suggest-category/` |
| 6. AI Insights generation | Existing generator-level and endpoint-level tests, all passing + live `curl` to `/insights/` |
| 7. Validation & error handling | Existing validation tests + confirmed `custom_exception_handler`'s envelope live |
| 8. File uploads | **New tests added and run for real**: valid receipt, invalid extension (rejected), oversized file (rejected), PDF receipt, avatar upload with a real minimal PNG, non-image rejected as avatar |
| 9. Pagination/filtering/search | Existing per-app filter tests + the `page_size` regression test from the prior QA pass, all still passing |
| 10. Bug identification & fixes | 6 real bugs found and fixed, detailed above |
| 11. Dead code / unused imports | AST-based scan (backend) + real ESLint (frontend), detailed above |

## Known limitations of this audit

- **Networked email delivery is untestable in this sandbox** — there's no route to `smtp.gmail.com` here regardless of credentials. The OTP flow was verified by reading the code directly from the database rather than receiving a real email; the *code path* (register, create token, attempt send, verify with code) is fully exercised, but actual SMTP delivery to a real inbox is something only you can confirm from your own machine.
- **One observation, not a bug:** the production frontend bundle is a single 953KB (274KB gzipped) chunk — Vite's own build warning. Not wrong, but route-based code-splitting (`React.lazy()` per page) would be the standard next step if load time on slow connections becomes a concern. Left as a recommendation rather than an in-scope fix, given the "do not change architecture" scope of this task.
