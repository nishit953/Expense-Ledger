import sqlite3
import os

db_path = 'db.sqlite3'
if not os.path.exists(db_path):
    print("db.sqlite3 file not found.")
else:
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    tables = cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';").fetchall()
    
    print(f"=== DATABASE OVERVIEW ({len(tables)} tables) ===")
    print(f"Database File: {os.path.abspath(db_path)}")
    print("-" * 50)
    
    for t in sorted(tables):
        table_name = t[0]
        count = cur.execute(f"SELECT COUNT(*) FROM {table_name}").fetchone()[0]
        print(f"Table: {table_name:<30} | Rows: {count}")

    conn.close()
