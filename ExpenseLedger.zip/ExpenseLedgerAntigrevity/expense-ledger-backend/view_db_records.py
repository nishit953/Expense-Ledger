import sqlite3

conn = sqlite3.connect('db.sqlite3')
cur = conn.cursor()

tables = ['users', 'expenses', 'incomes', 'budgets', 'savings_entries', 'goals', 'notifications', 'reports']

for table in tables:
    print(f"\n==================== TABLE: {table} ====================")
    cur.execute(f"PRAGMA table_info({table})")
    cols = [col[1] for col in cur.fetchall()]
    print("COLUMNS:", " | ".join(cols))
    print("-" * 60)
    
    cur.execute(f"SELECT * FROM {table}")
    rows = cur.fetchall()
    if not rows:
        print("(No records found)")
    else:
        for row in rows:
            print(row)

conn.close()
