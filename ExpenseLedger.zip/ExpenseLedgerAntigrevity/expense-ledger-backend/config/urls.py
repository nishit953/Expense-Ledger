from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/auth/', include('apps.authentication.urls')),
    path('api/expenses/', include('apps.expenses.urls')),
    path('api/income/', include('apps.income.urls')),
    path('api/dashboard/', include('apps.dashboard.urls')),
    path('api/budgets/', include('apps.budgets.urls')),
    path('api/savings/', include('apps.savings.urls')),
    path('api/analytics/', include('apps.analytics.urls')),
    path('api/goals/', include('apps.goals.urls')),
    path('api/reports/', include('apps.reports.urls')),
    path('api/notifications/', include('apps.notifications.urls')),
    path('api/settings/', include('apps.settings_app.urls')),
    path('api/ml/', include('apps.ml.urls')),
    path('api/insights/', include('apps.insights.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
