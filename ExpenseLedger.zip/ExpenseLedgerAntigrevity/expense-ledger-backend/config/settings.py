"""
Django settings for the ExpenseLedger backend.

Phase 2 scope: authentication, expenses, income.
Database: SQLite only (as required for this phase).
"""
import os
from datetime import timedelta
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


def _load_env_file(path):
    """
    Minimal .env loader (stdlib only — no python-dotenv/decouple dependency).
    Only sets a variable if it isn't already set, so real environment
    variables (e.g. from a hosting platform) always take priority over
    what's in the .env file.
    """
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        key, _, value = line.partition('=')
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)


_load_env_file(BASE_DIR / '.env')


def env(key, default=None, cast=None):
    """Read an environment variable with an optional type cast — the one helper this file needs from decouple."""
    value = os.environ.get(key, default)
    if value is None:
        return value
    if cast is bool and isinstance(value, str):
        return value.strip().lower() in ('1', 'true', 'yes', 'on')
    if cast is int and isinstance(value, str):
        return int(value)
    if cast == 'csv' and isinstance(value, str):
        return [item.strip() for item in value.split(',') if item.strip()]
    return value


SECRET_KEY = env('SECRET_KEY', default='dev-only-insecure-secret-key')
DEBUG = env('DEBUG', default=True, cast=bool)
ALLOWED_HOSTS = env('ALLOWED_HOSTS', default='localhost,127.0.0.1', cast='csv')

FRONTEND_URL = env('FRONTEND_URL', default='http://localhost:5173')

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    # third-party
    'rest_framework',
    'rest_framework_simplejwt',
    'rest_framework_simplejwt.token_blacklist',
    'corsheaders',
    'django_filters',
    # local apps
    'apps.authentication',
    'apps.expenses',
    'apps.income',
    'apps.dashboard',
    'apps.budgets',
    'apps.savings',
    'apps.analytics',
    'apps.goals',
    'apps.reports',
    'apps.notifications',
    'apps.settings_app',
    'apps.ml',
    'apps.insights',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'corsheaders.middleware.CorsMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'config.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'config.wsgi.application'
ASGI_APPLICATION = 'config.asgi.application'

# --- Database: SQLite only, per Phase 2 requirements ---
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

AUTH_USER_MODEL = 'authentication.User'

AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator', 'OPTIONS': {'min_length': 8}},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Asia/Kolkata'
USE_I18N = True
USE_TZ = True

STATIC_URL = 'static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

# Max receipt upload size: 5 MB
MAX_UPLOAD_SIZE_MB = 5

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# --- CORS ---
CORS_ALLOWED_ORIGINS = env('CORS_ALLOWED_ORIGINS', default='http://localhost:5173', cast='csv')
CORS_ALLOW_CREDENTIALS = True

# --- Django REST Framework ---
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework_simplejwt.authentication.JWTAuthentication',
    ),
    'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.IsAuthenticated',
    ),
    'DEFAULT_FILTER_BACKENDS': (
        'django_filters.rest_framework.DjangoFilterBackend',
        'rest_framework.filters.SearchFilter',
        'rest_framework.filters.OrderingFilter',
    ),
    'DEFAULT_PAGINATION_CLASS': 'config.pagination.StandardResultsPagination',
    'PAGE_SIZE': 10,
    'DEFAULT_RENDERER_CLASSES': (
        'rest_framework.renderers.JSONRenderer',
    ),
    'EXCEPTION_HANDLER': 'apps.authentication.utils.custom_exception_handler',
    # Only views that explicitly set throttle_classes/throttle_scope are
    # affected — this doesn't add throttling to any existing endpoint.
    # ML inference (TF-IDF vectorization, sklearn predict) is genuinely
    # more expensive per-request than a typical DB-backed view, hence a
    # dedicated, more conservative rate for just those endpoints.
    'DEFAULT_THROTTLE_RATES': {
        'ml_prediction': '30/min',
        'insights': '15/min',
    },
}

# --- Simple JWT ---
# "Remember me" is implemented by issuing a longer-lived refresh token
# (see authentication/views.py CustomTokenObtainPairView), rather than a
# separate auth mechanism — keeps a single token flow for the frontend.
SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(minutes=env('ACCESS_TOKEN_LIFETIME_MINUTES', default=30, cast=int)),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=env('REFRESH_TOKEN_LIFETIME_DAYS', default=1, cast=int)),
    'ROTATE_REFRESH_TOKENS': True,
    'BLACKLIST_AFTER_ROTATION': True,
    'UPDATE_LAST_LOGIN': True,
    'AUTH_HEADER_TYPES': ('Bearer',),
    'USER_ID_FIELD': 'id',
    'USER_ID_CLAIM': 'user_id',
}

# Extended refresh lifetime used when the client requests "remember me"
REMEMBER_ME_REFRESH_LIFETIME_DAYS = env('REFRESH_TOKEN_LIFETIME_DAYS_REMEMBER_ME', default=30, cast=int)

# --- Email (Gmail SMTP) ---
# Requires a Gmail App Password (not your regular password) — generate one
# at myaccount.google.com/apppasswords after enabling 2-Step Verification.
# Credentials are pulled from .env, never hardcoded here.
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = env('EMAIL_HOST_USER')
EMAIL_HOST_PASSWORD = env('EMAIL_HOST_PASSWORD')
DEFAULT_FROM_EMAIL = EMAIL_HOST_USER
