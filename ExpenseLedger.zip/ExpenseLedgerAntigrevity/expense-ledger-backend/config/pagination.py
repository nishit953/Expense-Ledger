from rest_framework.pagination import PageNumberPagination


class StandardResultsPagination(PageNumberPagination):
    """
    Default pagination for every paginated list endpoint in the project.

    DRF's PageNumberPagination doesn't honor a client-supplied page size
    unless `page_size_query_param` is set — several frontend calls (e.g.
    the notification bell requesting `page_size=20`) were silently capped
    at the global default of 10 without this. `max_page_size` caps it so a
    client can't request an unbounded page.
    """

    page_size = 10
    page_size_query_param = 'page_size'
    max_page_size = 100
