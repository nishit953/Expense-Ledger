module.exports = {
  root: true,
  env: { browser: true, es2021: true, node: true },
  extends: [
    'eslint:recommended',
    'plugin:react/recommended',
    'plugin:react-hooks/recommended',
  ],
  parserOptions: {
    ecmaVersion: 'latest',
    sourceType: 'module',
    ecmaFeatures: { jsx: true },
  },
  settings: {
    react: { version: 'detect' },
  },
  ignorePatterns: ['dist', 'node_modules'],
  rules: {
    'react/prop-types': 'off', // no PropTypes convention used in this project
    'react/react-in-jsx-scope': 'off', // not needed with the React 17+ JSX transform
    'no-unused-vars': ['warn', { argsIgnorePattern: '^_' }],
  },
}
