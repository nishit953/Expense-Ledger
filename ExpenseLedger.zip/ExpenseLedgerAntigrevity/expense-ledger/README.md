# ExpenseLedger — Frontend (Phase 1 + Phase 2 + Phase 3 + Phase 4)

AI-powered personal finance platform — React frontend, wired to a real Django REST API covering auth, expenses, income, budgets, savings, dashboard, analytics, financial goals, reports, notifications, and settings.

## Stack
React (Vite) · Tailwind CSS · React Router DOM · Framer Motion · React Hook Form · Axios · React Hot Toast · Recharts · Lucide + React Icons

## Getting started

```bash
npm install
cp .env.example .env   # point VITE_API_BASE_URL at your backend
npm run dev
```

Visit `http://localhost:5173`. The backend (see `../expense-ledger-backend`) must be running at the URL in `.env` for anything past the landing page to work.

## Routes

| Route | Page | Auth |
|---|---|---|
| `/` | Landing page | Public |
| `/login` | Login | Public |
| `/register` | Register | Public |
| `/forgot-password` | Request password reset code | Public |
| `/reset-password` | Enter code + new password | Public |
| `/verify-email` | OTP email verification | Public |
| `/app/dashboard` | Summary cards, net worth, health score, charts, upcoming bills, recent activity | Protected |
| `/app/expenses` | Expense CRUD, search/filter/sort/paginate | Protected |
| `/app/income` | Income CRUD, search/filter/sort/paginate | Protected |
| `/app/budgets` | Budget CRUD, card/table view toggle, live progress bars | Protected |
| `/app/savings` | Savings CRUD, growth chart, emergency fund tracking | Protected |
| `/app/analytics` | Period-filterable charts and KPIs across all modules | Protected |
| `/app/goals` | Goal CRUD, contributions, abandon/reactivate, progress cards | Protected |
| `/app/reports` | Monthly/yearly/custom reports, PDF & Excel export | Protected |
| `/app/settings` | Theme, currency, language, notification preferences, security | Protected |
| `/app/profile` | Edit profile (incl. occupation, monthly income), avatar, change password, goal/account/activity summary | Protected |
| `*` | 404 | Public |

## Folder structure

```
src/
  components/
    layout/     Navbar, Footer, PublicLayout, Sidebar, AppLayout (authenticated shell)
    ui/         Button, Input, Select, Card, Modal, ConfirmDialog, Skeleton, EmptyState, Pagination...
    auth/       PasswordStrengthMeter, OTPInput
    landing/    Hero, Features, HowItWorks, Testimonials, Pricing, FAQ, CTA
    dashboard/  StatCard, BreakdownList, TrendChart, RecentTransactions, HealthScoreCard, UpcomingBills
    expenses/   ExpenseFilters, ExpenseForm, ExpenseTable
    income/     IncomeFilters, IncomeForm, IncomeTable
    budgets/    BudgetFilters, BudgetForm, BudgetCard, BudgetTable, BudgetProgressBar
    savings/    SavingsFilters, SavingsForm, SavingsTable, SavingsGrowthChart
    analytics/  PeriodFilter, StatisticsGrid, IncomeExpenseTrendChart, WeeklySpendingChart
    goals/      GoalForm, GoalCard, GoalFilters, ContributeForm, GoalsSummaryStrip
    reports/    ReportFilters, ExportButtons
    notifications/ NotificationBell, NotificationItem
    settings/   SettingsSection, ToggleRow
    profile/    ProfileStatsPanel
    routes/     ProtectedRoute
  pages/        one file per route (expenses/, income/, budgets/, savings/, goals/ list pages in subfolders)
  context/      ThemeContext (dark mode), AuthContext (real API-backed auth)
  hooks/        useExpenses, useIncome, useBudgets, useSavings, useAnalytics, useGoals, useReport,
                useNotifications, useSettings, useDashboard, useDebounce
  services/     api.js (axios + auto token refresh), authService, expenseService, incomeService,
                budgetService, savingsService, analyticsService, goalService, reportService,
                notificationService, settingsService, dashboardService
  routes/       AppRoutes.jsx
  utils/        format.js
  styles/       index.css
```

## Auth flow

- Tokens: JWT access + refresh (SimpleJWT). Stored in `sessionStorage` by default; **Remember me** promotes them to `localStorage` and requests a longer-lived refresh token from the backend.
- `services/api.js` attaches the access token to every request and transparently refreshes it on a 401, retrying the original request once.
- `AuthContext` bootstraps the session on load by calling `/auth/profile/` if a token is present.
- `ProtectedRoute` redirects unauthenticated visitors to `/login`, preserving the page they were headed to.

## Design system

Unchanged from Phase 1 — Emerald/Ink Blue/Violet palette, Space Grotesk + Inter + JetBrains Mono (tabular numbers throughout), ledger-rule background texture, full dark mode.

## Notes for Phase 3

- Receipt files are uploaded as `multipart/form-data`; `ExpenseForm` only sends a new file if one was picked (edits don't clobber an existing receipt).
- Recurring expense/income entries are stored as flags, not yet auto-generated as future transactions — that's Phase 3 scope.
- Dashboard charts pull from dedicated aggregation endpoints (`/dashboard/*`) rather than computing totals client-side.


## ML integration (Phase 6)

Five small, additive touches to existing components — no new pages, no layout changes:

| Where | What |
|---|---|
| `ExpenseForm` | Debounced category suggestion as you type the title (only while you haven't manually picked a category yourself) |
| `BudgetCard` | A risk badge appears only when the predicted risk of exceeding the budget is ≥60% |
| `Dashboard` | A "Next month's forecast" card next to the existing health score card |
| `ExpenseTable` | A small flag icon on rows the anomaly detector considers unusual for that category |
| `GoalCard` | A pace line ("Ahead of pace" / "Behind pace") under the progress bar |

All five are wrapped in silent `.catch(() => {})` — every one of these is a supplementary hint, and the page it lives on works exactly the same with or without a successful ML response. `services/mlService.js` holds all five API calls.

**Right now, every one of these will show fallback-derived output** (a keyword-matched category, a rule-based risk estimate, etc.), not a trained model's — see the backend README for why, and how that changes automatically once training is run.

## AI Insights (new)

- **`/app/insights`** — full feed, filterable by category (Overspending, Budget, Savings, Goals, Monthly Summary, Financial Health), built entirely from existing UI primitives (`Card`, `EmptyState`, `Skeleton`) — no new design system introduced
- **Dashboard teaser** — a "Top 3" card in the existing right-hand column, linking to the full page
- `services/insightsService.js` + `hooks/useInsights.js` hit `GET /api/insights/`
