import { createContext, useContext, useEffect, useState } from 'react'
import * as authService from '../services/authService'
import { clearTokens, getAccessToken } from '../services/api'

const AuthContext = createContext(null)

// Phase 2: real API-backed auth. Bootstraps from a stored access token on
// load, then keeps `user` in sync with the backend's /auth/profile/ record.
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const bootstrap = async () => {
      if (!getAccessToken()) {
        setLoading(false)
        return
      }
      try {
        const profile = await authService.fetchProfile()
        setUser(profile)
      } catch {
        clearTokens()
      } finally {
        setLoading(false)
      }
    }
    bootstrap()
  }, [])

  const register = (payload) => authService.registerUser(payload)

  const login = async ({ email, password, rememberMe }) => {
    const loggedInUser = await authService.loginUser({ email, password, rememberMe })
    setUser(loggedInUser)
    return loggedInUser
  }

  const logout = async () => {
    await authService.logoutUser()
    setUser(null)
  }

  const updateUser = (updated) => setUser((prev) => ({ ...prev, ...updated }))

  return (
    <AuthContext.Provider
      value={{ user, loading, isAuthenticated: !!user, register, login, logout, updateUser }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
