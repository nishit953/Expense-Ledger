import { Search, SlidersHorizontal, X } from 'lucide-react'
import { useState } from 'react'
import Input from '../ui/Input'
import { Select } from '../ui/Badge'
import Button from '../ui/Button'
import { EXPENSE_CATEGORIES, PAYMENT_METHODS } from '../../services/expenseService'

export default function ExpenseFilters({ filters, onChange }) {
  const [panelOpen, setPanelOpen] = useState(false)

  const update = (patch) => onChange({ ...filters, ...patch })

  const clearFilters = () =>
    onChange({ search: '', category: '', payment_method: '', date_from: '', date_to: '', ordering: '-expense_date' })

  const activeCount = ['category', 'payment_method', 'date_from', 'date_to'].filter((k) => filters[k]).length

  return (
    <div className="mb-5">
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex-1">
          <Input
            icon={Search}
            placeholder="Search expenses by title, notes..."
            value={filters.search}
            onChange={(e) => update({ search: e.target.value })}
          />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setPanelOpen((o) => !o)}>
            <SlidersHorizontal size={15} /> Filters{activeCount > 0 && ` (${activeCount})`}
          </Button>
          <Select
            value={filters.ordering}
            onChange={(e) => update({ ordering: e.target.value })}
            className="!py-3"
            options={[
              { value: '-expense_date', label: 'Newest first' },
              { value: 'expense_date', label: 'Oldest first' },
              { value: '-amount', label: 'Highest amount' },
              { value: 'amount', label: 'Lowest amount' },
            ]}
          />
        </div>
      </div>

      {panelOpen && (
        <div className="mt-4 p-5 rounded-xl border border-paper-line dark:border-night-line bg-white dark:bg-night-card grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Select
            label="Category"
            value={filters.category}
            onChange={(e) => update({ category: e.target.value })}
            options={[{ value: '', label: 'All categories' }, ...EXPENSE_CATEGORIES]}
          />
          <Select
            label="Payment method"
            value={filters.payment_method}
            onChange={(e) => update({ payment_method: e.target.value })}
            options={[{ value: '', label: 'All methods' }, ...PAYMENT_METHODS]}
          />
          <Input
            label="From date"
            type="date"
            value={filters.date_from}
            onChange={(e) => update({ date_from: e.target.value })}
          />
          <Input
            label="To date"
            type="date"
            value={filters.date_to}
            onChange={(e) => update({ date_to: e.target.value })}
          />
          <button
            onClick={clearFilters}
            className="lg:col-span-4 flex items-center justify-center gap-1.5 text-sm text-ink900/50 dark:text-night-muted hover:text-red-500 transition-colors pt-1"
          >
            <X size={14} /> Clear all filters
          </button>
        </div>
      )}
    </div>
  )
}
