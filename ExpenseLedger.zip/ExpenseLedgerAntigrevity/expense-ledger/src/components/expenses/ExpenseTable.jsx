import { Pencil, Trash2, Paperclip, Repeat, AlertOctagon } from 'lucide-react'
import { CategoryBadge } from '../ui/Badge'
import { formatCurrency } from '../../utils/format'
import { EXPENSE_CATEGORIES, PAYMENT_METHODS } from '../../services/expenseService'

const categoryLabel = (v) => EXPENSE_CATEGORIES.find((c) => c.value === v)?.label || v
const methodLabel = (v) => PAYMENT_METHODS.find((m) => m.value === v)?.label || v

export default function ExpenseTable({ expenses, onEdit, onDelete, anomalyIds }) {
  const isAnomaly = (id) => anomalyIds?.has(id)

  return (
    <>
      {/* Desktop table */}
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs uppercase tracking-wide text-ink900/40 dark:text-night-muted border-b border-paper-line dark:border-night-line">
              <th className="py-3 font-medium">Title</th>
              <th className="py-3 font-medium">Category</th>
              <th className="py-3 font-medium">Payment</th>
              <th className="py-3 font-medium">Date</th>
              <th className="py-3 font-medium text-right">Amount</th>
              <th className="py-3 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-paper-line dark:divide-night-line">
            {expenses.map((exp) => (
              <tr key={exp.id} className="group">
                <td className="py-3.5 pr-4">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-ink900 dark:text-night-text">{exp.title}</span>
                    {exp.is_recurring && <Repeat size={13} className="text-violet-500 flex-shrink-0" />}
                    {exp.receipt && <Paperclip size={13} className="text-ink900/30 dark:text-night-muted flex-shrink-0" />}
                    {isAnomaly(exp.id) && (
                      <AlertOctagon size={13} className="text-amber-500 flex-shrink-0" aria-label="Unusual amount for this category" />
                    )}
                  </div>
                </td>
                <td className="py-3.5 pr-4">
                  <CategoryBadge category={exp.category} label={exp.category_display || categoryLabel(exp.category)} />
                </td>
                <td className="py-3.5 pr-4 text-ink900/60 dark:text-night-muted">
                  {exp.payment_method_display || methodLabel(exp.payment_method)}
                </td>
                <td className="num py-3.5 pr-4 text-ink900/60 dark:text-night-muted">{exp.expense_date}</td>
                <td className="num py-3.5 pr-4 text-right font-semibold text-ink900 dark:text-night-text">
                  {formatCurrency(exp.amount)}
                </td>
                <td className="py-3.5 text-right">
                  <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => onEdit(exp)}
                      className="p-1.5 rounded-lg text-ink900/50 dark:text-night-muted hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20"
                      aria-label="Edit"
                    >
                      <Pencil size={15} />
                    </button>
                    <button
                      onClick={() => onDelete(exp)}
                      className="p-1.5 rounded-lg text-ink900/50 dark:text-night-muted hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/10"
                      aria-label="Delete"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile cards */}
      <div className="md:hidden divide-y divide-paper-line dark:divide-night-line">
        {expenses.map((exp) => (
          <div key={exp.id} className="py-4">
            <div className="flex items-start justify-between">
              <div>
                <p className="font-medium text-ink900 dark:text-night-text flex items-center gap-1.5">
                  {exp.title}
                  {exp.is_recurring && <Repeat size={12} className="text-violet-500" />}
                  {isAnomaly(exp.id) && <AlertOctagon size={12} className="text-amber-500" />}
                </p>
                <p className="text-xs text-ink900/45 dark:text-night-muted mt-0.5 num">{exp.expense_date}</p>
              </div>
              <p className="num font-semibold text-ink900 dark:text-night-text">{formatCurrency(exp.amount)}</p>
            </div>
            <div className="flex items-center justify-between mt-2.5">
              <CategoryBadge category={exp.category} label={exp.category_display || categoryLabel(exp.category)} />
              <div className="flex items-center gap-1">
                <button onClick={() => onEdit(exp)} className="p-1.5 text-ink900/50 dark:text-night-muted">
                  <Pencil size={15} />
                </button>
                <button onClick={() => onDelete(exp)} className="p-1.5 text-red-500">
                  <Trash2 size={15} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  )
}
