import { useForm } from 'react-hook-form'
import { useEffect, useState } from 'react'
import { UploadCloud, FileText, Sparkles } from 'lucide-react'
import Input from '../ui/Input'
import { Select } from '../ui/Badge'
import Button from '../ui/Button'
import { EXPENSE_CATEGORIES, PAYMENT_METHODS, RECURRING_FREQUENCIES } from '../../services/expenseService'
import { suggestCategory } from '../../services/mlService'
import useDebounce from '../../hooks/useDebounce'

export default function ExpenseForm({ initialValues, onSubmit, onCancel, submitting }) {
  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors, dirtyFields },
  } = useForm({
    defaultValues: initialValues || {
      title: '',
      category: 'food',
      amount: '',
      payment_method: 'upi',
      expense_date: new Date().toISOString().slice(0, 10),
      description: '',
      notes: '',
      is_recurring: false,
      recurring_frequency: '',
    },
  })
  const [fileName, setFileName] = useState(initialValues?.receiptName || '')
  const [suggestion, setSuggestion] = useState(null)
  const isRecurring = watch('is_recurring')
  const title = watch('title')
  const debouncedTitle = useDebounce(title, 600)

  // Category auto-suggestion — only for new expenses, and only while the
  // user hasn't manually picked a category themselves, so a suggestion
  // never overwrites an intentional choice.
  useEffect(() => {
    if (initialValues || dirtyFields.category) return
    if (!debouncedTitle || debouncedTitle.trim().length < 3) {
      setSuggestion(null)
      return
    }
    let cancelled = false
    suggestCategory(debouncedTitle)
      .then((result) => {
        if (cancelled) return
        setSuggestion(result)
        setValue('category', result.category, { shouldDirty: false })
      })
      .catch(() => {}) // suggestion is a nice-to-have — silent on failure, form stays fully usable
    return () => {
      cancelled = true
    }
  }, [debouncedTitle, initialValues, dirtyFields.category, setValue])

  const submit = (data) => onSubmit(data)

  return (
    <form onSubmit={handleSubmit(submit)} className="space-y-5">
      <Input
        label="Title"
        placeholder="e.g. Grocery run at BigBasket"
        {...register('title', { required: 'Title is required', maxLength: { value: 200, message: 'Too long' } })}
        error={errors.title?.message}
      />

      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <Select
            label="Category"
            options={EXPENSE_CATEGORIES}
            {...register('category', { required: true })}
          />
          {suggestion && !dirtyFields.category && (
            <p className="flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400 mt-1.5">
              <Sparkles size={11} /> Suggested from title
            </p>
          )}
        </div>
        <Input
          label="Amount (₹)"
          type="number"
          step="0.01"
          placeholder="0.00"
          {...register('amount', {
            required: 'Amount is required',
            min: { value: 0.01, message: 'Must be greater than 0' },
          })}
          error={errors.amount?.message}
        />
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <Select
          label="Payment method"
          options={PAYMENT_METHODS}
          {...register('payment_method', { required: true })}
        />
        <Input
          label="Expense date"
          type="date"
          {...register('expense_date', { required: 'Date is required' })}
          error={errors.expense_date?.message}
        />
      </div>

      <Input label="Description" placeholder="Optional short description" {...register('description')} />

      <div>
        <label className="block text-sm font-medium text-ink900/80 dark:text-night-text/80 mb-1.5">Notes</label>
        <textarea
          rows={3}
          placeholder="Optional notes"
          {...register('notes')}
          className="w-full rounded-xl border border-paper-line dark:border-night-line bg-white dark:bg-night-surface text-ink900 dark:text-night-text px-4 py-3 text-sm outline-none focus:border-emerald-600 transition-colors resize-none"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-ink900/80 dark:text-night-text/80 mb-1.5">
          Receipt (optional)
        </label>
        <label className="flex items-center gap-3 border border-dashed border-paper-line dark:border-night-line rounded-xl px-4 py-3.5 cursor-pointer hover:border-emerald-600 transition-colors">
          <UploadCloud size={18} className="text-ink900/40 dark:text-night-muted flex-shrink-0" />
          <span className="text-sm text-ink900/60 dark:text-night-muted truncate flex-1">
            {fileName || 'JPG, PNG or PDF, up to 5MB'}
          </span>
          <input
            type="file"
            accept=".jpg,.jpeg,.png,.pdf"
            className="hidden"
            {...register('receipt', {
              onChange: (e) => setFileName(e.target.files?.[0]?.name || ''),
            })}
          />
        </label>
        {fileName && (
          <p className="flex items-center gap-1.5 text-xs text-ink900/45 dark:text-night-muted mt-1.5">
            <FileText size={12} /> {fileName}
          </p>
        )}
      </div>

      <label className="flex items-center gap-2.5 text-sm text-ink900/70 dark:text-night-text/70 cursor-pointer select-none">
        <input type="checkbox" {...register('is_recurring')} className="w-4 h-4 rounded accent-emerald-600" />
        This is a recurring expense
      </label>

      {isRecurring && (
        <Select
          label="Frequency"
          options={[{ value: '', label: 'Select frequency' }, ...RECURRING_FREQUENCIES]}
          {...register('recurring_frequency', {
            validate: (v) => !isRecurring || !!v || 'Select a frequency for recurring expenses',
          })}
          error={errors.recurring_frequency?.message}
        />
      )}

      <div className="flex gap-3 pt-2">
        <Button type="submit" loading={submitting} className="flex-1">
          {initialValues ? 'Save changes' : 'Add expense'}
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  )
}
