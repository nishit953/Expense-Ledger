import { AlertTriangle, PiggyBank, Wallet, Target, Calendar, HeartPulse, Sparkles } from 'lucide-react'
import { Card } from '../ui/Card'
import { PRIORITY_STYLES } from '../../services/insightsService'

const categoryIcons = {
  overspending: AlertTriangle,
  budget: PiggyBank,
  savings: Wallet,
  goal: Target,
  monthly_summary: Calendar,
  health: HeartPulse,
}

export default function InsightCard({ insight }) {
  const Icon = categoryIcons[insight.category] || Sparkles
  const style = PRIORITY_STYLES[insight.priority] || PRIORITY_STYLES.info

  return (
    <Card className="p-5 flex gap-4">
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${style.bg}`}>
        <Icon size={18} className={style.color} />
      </div>
      <div className="min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <h3 className="font-display font-semibold text-sm text-ink900 dark:text-night-text">{insight.title}</h3>
          {insight.priority === 'high' && (
            <span className="text-[10px] uppercase tracking-wide font-medium px-1.5 py-0.5 rounded-full bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400">
              High
            </span>
          )}
        </div>
        <p className="text-sm text-ink900/60 dark:text-night-muted leading-relaxed">{insight.message}</p>
      </div>
    </Card>
  )
}
