import { INSIGHT_CATEGORIES } from '../../services/insightsService'
import { classNames } from '../../utils/format'

export default function InsightFilters({ category, onCategoryChange, countsByCategory }) {
  return (
    <div className="flex flex-wrap gap-2 mb-6">
      <button
        onClick={() => onCategoryChange(null)}
        className={classNames(
          'px-3.5 py-2 rounded-lg text-sm font-medium transition-colors',
          !category
            ? 'bg-emerald-600 text-white'
            : 'bg-white dark:bg-night-card border border-paper-line dark:border-night-line text-ink900/60 dark:text-night-muted hover:border-emerald-600'
        )}
      >
        All
      </button>
      {INSIGHT_CATEGORIES.map((c) => (
        <button
          key={c.value}
          onClick={() => onCategoryChange(c.value)}
          className={classNames(
            'px-3.5 py-2 rounded-lg text-sm font-medium transition-colors',
            category === c.value
              ? 'bg-emerald-600 text-white'
              : 'bg-white dark:bg-night-card border border-paper-line dark:border-night-line text-ink900/60 dark:text-night-muted hover:border-emerald-600'
          )}
        >
          {c.label}
          {countsByCategory?.[c.value] > 0 && (
            <span className="num ml-1.5 opacity-70">{countsByCategory[c.value]}</span>
          )}
        </button>
      ))}
    </div>
  )
}
