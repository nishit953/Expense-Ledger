import { useForm } from 'react-hook-form'
import Input from '../ui/Input'
import { Select } from '../ui/Badge'
import Button from '../ui/Button'
import { BUDGET_CATEGORIES } from '../../services/budgetService'

function currentMonthValue() {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-01`
}

export default function BudgetForm({ initialValues, onSubmit, onCancel, submitting }) {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    defaultValues: {
      category: initialValues?.category || 'food',
      monthly_limit: initialValues?.monthly_limit || '',
      month: initialValues?.month ? initialValues.month.slice(0, 7) : currentMonthValue().slice(0, 7),
    },
  })

  const submit = (values) => onSubmit({ ...values, month: `${values.month}-01` })

  return (
    <form onSubmit={handleSubmit(submit)} className="space-y-5">
      <Select label="Category" options={BUDGET_CATEGORIES} {...register('category', { required: true })} />

      <Input
        label="Monthly limit (₹)"
        type="number"
        step="0.01"
        placeholder="0.00"
        {...register('monthly_limit', {
          required: 'Monthly limit is required',
          min: { value: 0.01, message: 'Must be greater than 0' },
        })}
        error={errors.monthly_limit?.message}
      />

      <Input
        label="Month"
        type="month"
        {...register('month', { required: 'Month is required' })}
        error={errors.month?.message}
      />

      <div className="flex gap-3 pt-2">
        <Button type="submit" loading={submitting} className="flex-1">
          {initialValues ? 'Save changes' : 'Create budget'}
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  )
}
