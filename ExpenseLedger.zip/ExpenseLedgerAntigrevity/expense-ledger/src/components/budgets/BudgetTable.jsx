import { Pencil, Trash2 } from 'lucide-react'
import { CategoryBadge } from '../ui/Badge'
import BudgetProgressBar from './BudgetProgressBar'
import { formatCurrency } from '../../utils/format'
import { BUDGET_CATEGORIES, BUDGET_STATUS_LABELS } from '../../services/budgetService'

const categoryLabel = (v) => BUDGET_CATEGORIES.find((c) => c.value === v)?.label || v

const statusTextColors = {
  on_track: 'text-emerald-600',
  warning: 'text-amber-600',
  exceeded: 'text-red-500',
}

export default function BudgetTable({ budgets, onEdit, onDelete }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left text-xs uppercase tracking-wide text-ink900/40 dark:text-night-muted border-b border-paper-line dark:border-night-line">
            <th className="py-3 font-medium">Category</th>
            <th className="py-3 font-medium">Month</th>
            <th className="py-3 font-medium w-48">Progress</th>
            <th className="py-3 font-medium text-right">Spent / Limit</th>
            <th className="py-3 font-medium">Status</th>
            <th className="py-3 font-medium text-right">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-paper-line dark:divide-night-line">
          {budgets.map((b) => (
            <tr key={b.id} className="group">
              <td className="py-3.5 pr-4">
                <CategoryBadge category={b.category} label={b.category_display || categoryLabel(b.category)} />
              </td>
              <td className="num py-3.5 pr-4 text-ink900/60 dark:text-night-muted">{b.month}</td>
              <td className="py-3.5 pr-4">
                <BudgetProgressBar percentage={b.percentage_used} status={b.status} />
              </td>
              <td className="num py-3.5 pr-4 text-right text-ink900 dark:text-night-text">
                {formatCurrency(b.current_spending)} / {formatCurrency(b.monthly_limit)}
              </td>
              <td className={`py-3.5 pr-4 text-xs font-medium ${statusTextColors[b.status]}`}>
                {BUDGET_STATUS_LABELS[b.status] || b.status}
              </td>
              <td className="py-3.5 text-right">
                <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => onEdit(b)} className="p-1.5 text-ink900/50 dark:text-night-muted hover:text-emerald-600">
                    <Pencil size={15} />
                  </button>
                  <button onClick={() => onDelete(b)} className="p-1.5 text-ink900/50 dark:text-night-muted hover:text-red-500">
                    <Trash2 size={15} />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
