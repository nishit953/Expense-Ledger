import { LayoutGrid, List, X } from 'lucide-react'
import { Select } from '../ui/Badge'
import Input from '../ui/Input'
import { BUDGET_CATEGORIES } from '../../services/budgetService'
import { classNames } from '../../utils/format'

export default function BudgetFilters({ filters, onChange, view, onViewChange }) {
  const update = (patch) => onChange({ ...filters, ...patch })
  const clear = () => onChange({ category: '', month: '', ordering: '-month' })

  return (
    <div className="flex flex-col sm:flex-row gap-3 mb-6">
      <Select
        value={filters.category}
        onChange={(e) => update({ category: e.target.value })}
        className="sm:max-w-[200px]"
        options={[{ value: '', label: 'All categories' }, ...BUDGET_CATEGORIES]}
      />
      <Input
        type="month"
        value={filters.month ? filters.month.slice(0, 7) : ''}
        onChange={(e) => update({ month: e.target.value ? `${e.target.value}-01` : '' })}
        className="sm:max-w-[180px]"
      />
      {(filters.category || filters.month) && (
        <button
          onClick={clear}
          className="flex items-center gap-1.5 text-sm text-ink900/50 dark:text-night-muted hover:text-red-500 transition-colors px-2"
        >
          <X size={14} /> Clear
        </button>
      )}

      <div className="sm:ml-auto flex items-center gap-1 p-1 bg-paper-line/50 dark:bg-night-line/50 rounded-xl w-fit">
        <button
          onClick={() => onViewChange('cards')}
          className={classNames(
            'p-2 rounded-lg transition-colors',
            view === 'cards' ? 'bg-white dark:bg-night-card shadow-soft text-emerald-600' : 'text-ink900/40 dark:text-night-muted'
          )}
          aria-label="Card view"
        >
          <LayoutGrid size={16} />
        </button>
        <button
          onClick={() => onViewChange('table')}
          className={classNames(
            'p-2 rounded-lg transition-colors',
            view === 'table' ? 'bg-white dark:bg-night-card shadow-soft text-emerald-600' : 'text-ink900/40 dark:text-night-muted'
          )}
          aria-label="Table view"
        >
          <List size={16} />
        </button>
      </div>
    </div>
  )
}
