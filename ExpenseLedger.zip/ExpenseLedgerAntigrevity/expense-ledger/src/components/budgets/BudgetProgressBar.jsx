import { classNames } from '../../utils/format'

const statusColors = {
  on_track: 'bg-emerald-500',
  warning: 'bg-amber-500',
  exceeded: 'bg-red-500',
}

export default function BudgetProgressBar({ percentage, status, className = '' }) {
  const width = Math.min(percentage, 100)

  return (
    <div className={classNames('h-2 rounded-full bg-paper-line dark:bg-night-line overflow-hidden', className)}>
      <div
        className={classNames('h-full rounded-full transition-all duration-700', statusColors[status] || statusColors.on_track)}
        style={{ width: `${width}%` }}
      />
    </div>
  )
}
