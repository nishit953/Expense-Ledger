import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Pencil, Trash2, AlertTriangle, CheckCircle2, AlertCircle, Sparkles } from 'lucide-react'
import { CategoryBadge } from '../ui/Badge'
import BudgetProgressBar from './BudgetProgressBar'
import { formatCurrency } from '../../utils/format'
import { BUDGET_CATEGORIES, BUDGET_STATUS_LABELS } from '../../services/budgetService'
import { fetchBudgetRisk } from '../../services/mlService'

const categoryLabel = (v) => BUDGET_CATEGORIES.find((c) => c.value === v)?.label || v

const statusIcons = {
  on_track: CheckCircle2,
  warning: AlertCircle,
  exceeded: AlertTriangle,
}

const statusTextColors = {
  on_track: 'text-emerald-600',
  warning: 'text-amber-600',
  exceeded: 'text-red-500',
}

export default function BudgetCard({ budget, onEdit, onDelete }) {
  const StatusIcon = statusIcons[budget.status] || CheckCircle2
  const [risk, setRisk] = useState(null)

  useEffect(() => {
    // Only worth checking for budgets not already known to be exceeded —
    // silently ignored on failure, this is a supplementary hint, not
    // something the card depends on to function.
    if (budget.status === 'exceeded') return
    let cancelled = false
    fetchBudgetRisk(budget.id)
      .then((result) => {
        if (!cancelled && result.risk_score >= 0.6) setRisk(result)
      })
      .catch(() => {})
    return () => {
      cancelled = true
    }
  }, [budget.id, budget.status])

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
      className="rounded-xl2 border border-paper-line dark:border-night-line bg-white dark:bg-night-card p-5 hover:shadow-card transition-shadow group"
    >
      <div className="flex items-start justify-between mb-4">
        <CategoryBadge category={budget.category} label={budget.category_display || categoryLabel(budget.category)} />
        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={() => onEdit(budget)}
            className="p-1.5 rounded-lg text-ink900/50 dark:text-night-muted hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20"
            aria-label="Edit"
          >
            <Pencil size={14} />
          </button>
          <button
            onClick={() => onDelete(budget)}
            className="p-1.5 rounded-lg text-ink900/50 dark:text-night-muted hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/10"
            aria-label="Delete"
          >
            <Trash2 size={14} />
          </button>
        </div>
      </div>

      <div className="flex items-baseline justify-between mb-1">
        <span className="num text-xl font-semibold text-ink900 dark:text-night-text">
          {formatCurrency(budget.current_spending)}
        </span>
        <span className="num text-sm text-ink900/45 dark:text-night-muted">
          of {formatCurrency(budget.monthly_limit)}
        </span>
      </div>

      <BudgetProgressBar percentage={budget.percentage_used} status={budget.status} className="my-3" />

      <div className="flex items-center justify-between text-xs">
        <span className={`flex items-center gap-1.5 font-medium ${statusTextColors[budget.status]}`}>
          <StatusIcon size={13} />
          {BUDGET_STATUS_LABELS[budget.status] || budget.status}
        </span>
        <span className="num text-ink900/45 dark:text-night-muted">
          {budget.remaining_amount >= 0
            ? `${formatCurrency(budget.remaining_amount)} left`
            : `${formatCurrency(Math.abs(budget.remaining_amount))} over`}
        </span>
      </div>

      {risk && (
        <p className="flex items-center gap-1.5 text-xs text-amber-600 dark:text-amber-400 mt-3 pt-3 border-t border-paper-line dark:border-night-line">
          <Sparkles size={12} /> {Math.round(risk.risk_score * 100)}% likely to exceed by month-end
        </p>
      )}
    </motion.div>
  )
}
