import { classNames } from '../../utils/format'

function getStrength(password) {
  if (!password) return 0
  let score = 0
  if (password.length >= 8) score++
  if (/[A-Z]/.test(password)) score++
  if (/[0-9]/.test(password)) score++
  if (/[^A-Za-z0-9]/.test(password)) score++
  return score
}

const labels = ['Too weak', 'Weak', 'Fair', 'Good', 'Strong']
const colors = ['bg-red-400', 'bg-red-400', 'bg-amber-400', 'bg-emerald-400', 'bg-emerald-600']

export default function PasswordStrengthMeter({ password }) {
  const strength = getStrength(password)
  if (!password) return null

  return (
    <div className="mt-2">
      <div className="flex gap-1.5">
        {[0, 1, 2, 3].map((i) => (
          <div
            key={i}
            className={classNames(
              'h-1.5 flex-1 rounded-full transition-colors duration-300',
              i < strength ? colors[strength] : 'bg-paper-line dark:bg-night-line'
            )}
          />
        ))}
      </div>
      <p className="text-xs mt-1.5 text-ink900/55 dark:text-night-muted">{labels[strength]}</p>
    </div>
  )
}
