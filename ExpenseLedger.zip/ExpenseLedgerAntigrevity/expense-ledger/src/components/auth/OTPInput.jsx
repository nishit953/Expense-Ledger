import { useRef, useState } from 'react'

export default function OTPInput({ length = 6, onComplete }) {
  const [values, setValues] = useState(Array(length).fill(''))
  const inputsRef = useRef([])

  const handleChange = (index, val) => {
    if (!/^[0-9]?$/.test(val)) return
    const next = [...values]
    next[index] = val
    setValues(next)

    if (val && index < length - 1) {
      inputsRef.current[index + 1]?.focus()
    }
    if (next.every((v) => v !== '')) {
      onComplete?.(next.join(''))
    }
  }

  const handleKeyDown = (index, e) => {
    if (e.key === 'Backspace' && !values[index] && index > 0) {
      inputsRef.current[index - 1]?.focus()
    }
  }

  const handlePaste = (e) => {
    const pasted = e.clipboardData.getData('text').trim().slice(0, length)
    if (!/^[0-9]+$/.test(pasted)) return
    const next = pasted.split('')
    while (next.length < length) next.push('')
    setValues(next)
    if (next.every((v) => v !== '')) onComplete?.(next.join(''))
  }

  return (
    <div className="flex gap-2.5 sm:gap-3 justify-center" onPaste={handlePaste}>
      {values.map((val, i) => (
        <input
          key={i}
          ref={(el) => (inputsRef.current[i] = el)}
          value={val}
          onChange={(e) => handleChange(i, e.target.value)}
          onKeyDown={(e) => handleKeyDown(i, e)}
          inputMode="numeric"
          maxLength={1}
          className="num w-11 h-13 sm:w-12 sm:h-14 text-center text-xl font-semibold rounded-xl border border-paper-line dark:border-night-line bg-white dark:bg-night-surface text-ink900 dark:text-night-text outline-none focus:border-emerald-600 transition-colors"
        />
      ))}
    </div>
  )
}
