import { Pencil, Trash2, Repeat } from 'lucide-react'
import { CategoryBadge } from '../ui/Badge'
import { formatCurrency } from '../../utils/format'
import { INCOME_SOURCES } from '../../services/incomeService'

const sourceLabel = (v) => INCOME_SOURCES.find((s) => s.value === v)?.label || v

export default function IncomeTable({ incomes, onEdit, onDelete }) {
  return (
    <>
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs uppercase tracking-wide text-ink900/40 dark:text-night-muted border-b border-paper-line dark:border-night-line">
              <th className="py-3 font-medium">Source</th>
              <th className="py-3 font-medium">Description</th>
              <th className="py-3 font-medium">Date</th>
              <th className="py-3 font-medium text-right">Amount</th>
              <th className="py-3 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-paper-line dark:divide-night-line">
            {incomes.map((inc) => (
              <tr key={inc.id} className="group">
                <td className="py-3.5 pr-4">
                  <div className="flex items-center gap-2">
                    <CategoryBadge category={inc.source} label={inc.source_display || sourceLabel(inc.source)} />
                    {inc.is_recurring && <Repeat size={13} className="text-violet-500 flex-shrink-0" />}
                  </div>
                </td>
                <td className="py-3.5 pr-4 text-ink900/60 dark:text-night-muted">
                  {inc.description || '—'}
                </td>
                <td className="num py-3.5 pr-4 text-ink900/60 dark:text-night-muted">{inc.income_date}</td>
                <td className="num py-3.5 pr-4 text-right font-semibold text-emerald-600">
                  +{formatCurrency(inc.amount)}
                </td>
                <td className="py-3.5 text-right">
                  <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => onEdit(inc)}
                      className="p-1.5 rounded-lg text-ink900/50 dark:text-night-muted hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20"
                      aria-label="Edit"
                    >
                      <Pencil size={15} />
                    </button>
                    <button
                      onClick={() => onDelete(inc)}
                      className="p-1.5 rounded-lg text-ink900/50 dark:text-night-muted hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/10"
                      aria-label="Delete"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="md:hidden divide-y divide-paper-line dark:divide-night-line">
        {incomes.map((inc) => (
          <div key={inc.id} className="py-4">
            <div className="flex items-start justify-between">
              <div>
                <CategoryBadge category={inc.source} label={inc.source_display || sourceLabel(inc.source)} />
                <p className="text-xs text-ink900/45 dark:text-night-muted mt-1.5 num">{inc.income_date}</p>
              </div>
              <p className="num font-semibold text-emerald-600">+{formatCurrency(inc.amount)}</p>
            </div>
            <div className="flex items-center justify-between mt-2.5">
              <p className="text-xs text-ink900/50 dark:text-night-muted truncate">{inc.description || '—'}</p>
              <div className="flex items-center gap-1 flex-shrink-0">
                <button onClick={() => onEdit(inc)} className="p-1.5 text-ink900/50 dark:text-night-muted">
                  <Pencil size={15} />
                </button>
                <button onClick={() => onDelete(inc)} className="p-1.5 text-red-500">
                  <Trash2 size={15} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  )
}
