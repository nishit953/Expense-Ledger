import { useForm } from 'react-hook-form'
import Input from '../ui/Input'
import { Select } from '../ui/Badge'
import Button from '../ui/Button'
import { INCOME_SOURCES } from '../../services/incomeService'
import { RECURRING_FREQUENCIES } from '../../services/expenseService'

export default function IncomeForm({ initialValues, onSubmit, onCancel, submitting }) {
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm({
    defaultValues: initialValues || {
      source: 'salary',
      amount: '',
      income_date: new Date().toISOString().slice(0, 10),
      description: '',
      is_recurring: false,
      recurring_frequency: '',
    },
  })
  const isRecurring = watch('is_recurring')

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
      <div className="grid sm:grid-cols-2 gap-4">
        <Select label="Source" options={INCOME_SOURCES} {...register('source', { required: true })} />
        <Input
          label="Amount (₹)"
          type="number"
          step="0.01"
          placeholder="0.00"
          {...register('amount', {
            required: 'Amount is required',
            min: { value: 0.01, message: 'Must be greater than 0' },
          })}
          error={errors.amount?.message}
        />
      </div>

      <Input
        label="Date"
        type="date"
        {...register('income_date', { required: 'Date is required' })}
        error={errors.income_date?.message}
      />

      <Input label="Description" placeholder="Optional description" {...register('description')} />

      <label className="flex items-center gap-2.5 text-sm text-ink900/70 dark:text-night-text/70 cursor-pointer select-none">
        <input type="checkbox" {...register('is_recurring')} className="w-4 h-4 rounded accent-emerald-600" />
        This is recurring income
      </label>

      {isRecurring && (
        <Select
          label="Frequency"
          options={[{ value: '', label: 'Select frequency' }, ...RECURRING_FREQUENCIES]}
          {...register('recurring_frequency', {
            validate: (v) => !isRecurring || !!v || 'Select a frequency for recurring income',
          })}
          error={errors.recurring_frequency?.message}
        />
      )}

      <div className="flex gap-3 pt-2">
        <Button type="submit" loading={submitting} className="flex-1">
          {initialValues ? 'Save changes' : 'Add income'}
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  )
}
