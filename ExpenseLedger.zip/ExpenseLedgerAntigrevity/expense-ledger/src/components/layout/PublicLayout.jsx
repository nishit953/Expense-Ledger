import Navbar from './Navbar'
import Footer from './Footer'

export default function PublicLayout({ children }) {
  return (
    <div className="min-h-screen flex flex-col bg-paper-light dark:bg-night-bg">
      <Navbar />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  )
}
