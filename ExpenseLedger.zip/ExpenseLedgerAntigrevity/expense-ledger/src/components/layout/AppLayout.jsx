import { useState } from 'react'
import { Menu } from 'lucide-react'
import Sidebar from './Sidebar'
import ThemeToggle from '../ui/ThemeToggle'
import NotificationBell from '../notifications/NotificationBell'

export default function AppLayout({ children, title, subtitle }) {
  const [drawerOpen, setDrawerOpen] = useState(false)

  return (
    <div className="min-h-screen flex bg-paper-light dark:bg-night-bg">
      <Sidebar open={drawerOpen} onClose={() => setDrawerOpen(false)} />

      <div className="flex-1 min-w-0">
        <header className="sticky top-0 z-30 bg-white/80 dark:bg-night-bg/80 backdrop-blur-xl border-b border-paper-line dark:border-night-line">
          <div className="flex items-center justify-between px-5 sm:px-8 h-16 sm:h-20">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setDrawerOpen(true)}
                className="lg:hidden p-2 -ml-2 text-ink900 dark:text-night-text"
                aria-label="Open menu"
              >
                <Menu size={22} />
              </button>
              <div>
                <h1 className="font-display font-semibold text-lg sm:text-xl text-ink900 dark:text-night-text">
                  {title}
                </h1>
                {subtitle && (
                  <p className="text-xs text-ink900/45 dark:text-night-muted hidden sm:block">{subtitle}</p>
                )}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <NotificationBell />
              <ThemeToggle />
            </div>
          </div>
        </header>

        <main className="px-5 sm:px-8 py-8">{children}</main>
      </div>
    </div>
  )
}
