import { useState } from 'react'
import { FiTwitter, FiGithub, FiLinkedin, FiInstagram } from 'react-icons/fi'
import Logo from '../ui/Logo'
import Button from '../ui/Button'
import Input from '../ui/Input'

const columns = [
  {
    title: 'Product',
    links: ['Features', 'Pricing', 'AI Insights', 'Security'],
  },
  {
    title: 'Company',
    links: ['About', 'Careers', 'Blog', 'Contact'],
  },
  {
    title: 'Resources',
    links: ['Help Center', 'Guides', 'API Docs', 'Status'],
  },
  {
    title: 'Legal',
    links: ['Privacy Policy', 'Terms of Service', 'Cookie Policy'],
  },
]

const socials = [
  { icon: FiTwitter, href: '#', label: 'Twitter' },
  { icon: FiGithub, href: '#', label: 'GitHub' },
  { icon: FiLinkedin, href: '#', label: 'LinkedIn' },
  { icon: FiInstagram, href: '#', label: 'Instagram' },
]

export default function Footer() {
  const [email, setEmail] = useState('')
  const [subscribed, setSubscribed] = useState(false)

  const handleSubscribe = (e) => {
    e.preventDefault()
    if (!email) return
    setSubscribed(true)
    setEmail('')
    setTimeout(() => setSubscribed(false), 3000)
  }

  return (
    <footer className="border-t border-paper-line dark:border-night-line bg-white dark:bg-night-surface">
      <div className="container-page py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          <div className="lg:col-span-4">
            <Logo />
            <p className="mt-4 text-sm text-ink900/60 dark:text-night-muted max-w-xs">
              A single ledger for spending, budgets, and investments — kept honest by AI.
            </p>
            <form onSubmit={handleSubscribe} className="mt-6 flex gap-2 max-w-sm">
              <Input
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="!py-2.5"
              />
              <Button type="submit" variant="primary" size="md">
                {subscribed ? 'Sent' : 'Subscribe'}
              </Button>
            </form>
          </div>

          <div className="lg:col-span-8 grid grid-cols-2 sm:grid-cols-4 gap-8">
            {columns.map((col) => (
              <div key={col.title}>
                <h4 className="text-sm font-semibold text-ink900 dark:text-night-text mb-3.5">
                  {col.title}
                </h4>
                <ul className="space-y-2.5">
                  {col.links.map((link) => (
                    <li key={link}>
                      <a
                        href="#"
                        className="text-sm text-ink900/55 dark:text-night-muted hover:text-emerald-700 dark:hover:text-emerald-400 transition-colors"
                      >
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-14 pt-8 border-t border-paper-line dark:border-night-line flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-ink900/45 dark:text-night-muted">
            © {new Date().getFullYear()} ExpenseLedger. Built as a final-year major project.
          </p>
          <div className="flex items-center gap-4">
            {socials.map((s) => (
              <a
                key={s.label}
                href={s.href}
                aria-label={s.label}
                className="w-9 h-9 rounded-lg flex items-center justify-center text-ink900/50 dark:text-night-muted hover:text-emerald-700 hover:bg-emerald-50 dark:hover:bg-night-card transition-colors"
              >
                <s.icon size={16} />
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}
