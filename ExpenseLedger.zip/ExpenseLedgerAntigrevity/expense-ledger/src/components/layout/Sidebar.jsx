import { NavLink, useNavigate } from 'react-router-dom'
import { LayoutDashboard, Receipt, Wallet, User, LogOut, X, PiggyBank, TrendingUp, BarChart3, Target, FileText, Settings as SettingsIcon, Sparkles } from 'lucide-react'
import toast from 'react-hot-toast'
import Logo from '../ui/Logo'
import { useAuth } from '../../context/AuthContext'

const links = [
  { to: '/app/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/app/insights', label: 'AI Insights', icon: Sparkles },
  { to: '/app/expenses', label: 'Expenses', icon: Receipt },
  { to: '/app/income', label: 'Income', icon: Wallet },
  { to: '/app/budgets', label: 'Budgets', icon: PiggyBank },
  { to: '/app/savings', label: 'Savings', icon: TrendingUp },
  { to: '/app/goals', label: 'Goals', icon: Target },
  { to: '/app/analytics', label: 'Analytics', icon: BarChart3 },
  { to: '/app/reports', label: 'Reports', icon: FileText },
  { to: '/app/settings', label: 'Settings', icon: SettingsIcon },
  { to: '/app/profile', label: 'Profile', icon: User },
]

export default function Sidebar({ open, onClose }) {
  const { logout, user } = useAuth()
  const navigate = useNavigate()

  const handleLogout = async () => {
    try {
      await logout()
      toast.success('Logged out')
      navigate('/login')
    } catch {
      toast.error('Something went wrong logging out')
    }
  }

  const content = (
    <div className="flex flex-col h-full">
      <div className="px-6 py-6 border-b border-paper-line dark:border-night-line flex items-center justify-between">
        <Logo />
        <button onClick={onClose} className="lg:hidden p-1 text-ink900/50 dark:text-night-muted">
          <X size={20} />
        </button>
      </div>

      <nav className="flex-1 px-4 py-6 space-y-1">
        {links.map((link) => (
          <NavLink
            key={link.to}
            to={link.to}
            onClick={onClose}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                isActive
                  ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400'
                  : 'text-ink900/60 dark:text-night-muted hover:bg-black/5 dark:hover:bg-white/5'
              }`
            }
          >
            <link.icon size={18} />
            {link.label}
          </NavLink>
        ))}
      </nav>

      <div className="px-4 py-5 border-t border-paper-line dark:border-night-line">
        <div className="flex items-center gap-3 px-2 mb-3">
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-emerald-400 to-violet-500 flex items-center justify-center text-white text-sm font-semibold font-display flex-shrink-0">
            {user?.full_name?.charAt(0) || user?.email?.charAt(0) || 'U'}
          </div>
          <div className="min-w-0">
            <p className="text-sm font-medium text-ink900 dark:text-night-text truncate">
              {user?.full_name || 'Your account'}
            </p>
            <p className="text-xs text-ink900/45 dark:text-night-muted truncate">{user?.email}</p>
          </div>
        </div>
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium text-red-500 hover:bg-red-50 dark:hover:bg-red-900/10 transition-colors"
        >
          <LogOut size={18} />
          Log out
        </button>
      </div>
    </div>
  )

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex lg:flex-col w-64 flex-shrink-0 border-r border-paper-line dark:border-night-line bg-white dark:bg-night-surface h-screen sticky top-0">
        {content}
      </aside>

      {/* Mobile drawer */}
      {open && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-ink900/40" onClick={onClose} />
          <aside className="relative w-72 bg-white dark:bg-night-surface h-full shadow-card">
            {content}
          </aside>
        </div>
      )}
    </>
  )
}
