import { forwardRef } from 'react'
import { classNames } from '../../utils/format'

const categoryColors = {
  food: 'bg-amber-50 text-amber-700 dark:bg-amber-900/20 dark:text-amber-400',
  transport: 'bg-blue-50 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400',
  shopping: 'bg-violet-50 text-violet-700 dark:bg-violet-900/20 dark:text-violet-400',
  medical: 'bg-red-50 text-red-700 dark:bg-red-900/20 dark:text-red-400',
  bills: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',
  education: 'bg-cyan-50 text-cyan-700 dark:bg-cyan-900/20 dark:text-cyan-400',
  entertainment: 'bg-pink-50 text-pink-700 dark:bg-pink-900/20 dark:text-pink-400',
  investment: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400',
  rent: 'bg-orange-50 text-orange-700 dark:bg-orange-900/20 dark:text-orange-400',
  others: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300',
  salary: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400',
  freelancing: 'bg-blue-50 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400',
  business: 'bg-violet-50 text-violet-700 dark:bg-violet-900/20 dark:text-violet-400',
  rental: 'bg-orange-50 text-orange-700 dark:bg-orange-900/20 dark:text-orange-400',
  interest: 'bg-cyan-50 text-cyan-700 dark:bg-cyan-900/20 dark:text-cyan-400',
  bonus: 'bg-pink-50 text-pink-700 dark:bg-pink-900/20 dark:text-pink-400',
  other: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300',
}

export function CategoryBadge({ category, label }) {
  return (
    <span
      className={classNames(
        'inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium',
        categoryColors[category] || categoryColors.others
      )}
    >
      {label}
    </span>
  )
}

export const Select = forwardRef(function Select(
  { label, error, options, className = '', ...props },
  ref
) {
  return (
    <div className="w-full">
      {label && (
        <label className="block text-sm font-medium text-ink900/80 dark:text-night-text/80 mb-1.5">
          {label}
        </label>
      )}
      <select
        ref={ref}
        className={classNames(
          'w-full rounded-xl border bg-white dark:bg-night-surface text-ink900 dark:text-night-text px-4 py-3 text-sm outline-none transition-all',
          error
            ? 'border-red-400 focus:border-red-500'
            : 'border-paper-line dark:border-night-line focus:border-emerald-600',
          className
        )}
        {...props}
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
      {error && <p className="mt-1.5 text-xs text-red-500">{error}</p>}
    </div>
  )
})
