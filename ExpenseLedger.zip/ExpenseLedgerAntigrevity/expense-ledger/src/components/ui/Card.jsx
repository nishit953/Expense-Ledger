import { motion } from 'framer-motion'
import { classNames } from '../../utils/format'

export function Card({ children, className = '', hover = false, ...props }) {
  return (
    <div
      className={classNames(
        'bg-white dark:bg-night-card border border-paper-line dark:border-night-line rounded-xl2 shadow-soft',
        hover && 'transition-all duration-300 hover:shadow-card hover:-translate-y-1',
        className
      )}
      {...props}
    >
      {children}
    </div>
  )
}

export function GlassCard({ children, className = '', ...props }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
      className={classNames('glass rounded-xl2 shadow-card', className)}
      {...props}
    >
      {children}
    </motion.div>
  )
}

export function AuthCard({ children, className = '' }) {
  return (
    <div className="min-h-screen w-full flex items-center justify-center px-4 py-12 bg-paper-light dark:bg-night-bg ledger-texture relative overflow-hidden">
      <div className="absolute -top-32 -left-32 w-96 h-96 bg-emerald-400/20 rounded-full blur-3xl" />
      <div className="absolute -bottom-32 -right-32 w-96 h-96 bg-violet-400/20 rounded-full blur-3xl" />
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
        className={classNames(
          'relative w-full max-w-md bg-white/90 dark:bg-night-card/90 backdrop-blur-xl border border-paper-line dark:border-night-line rounded-2xl shadow-card p-8 sm:p-10',
          className
        )}
      >
        {children}
      </motion.div>
    </div>
  )
}
