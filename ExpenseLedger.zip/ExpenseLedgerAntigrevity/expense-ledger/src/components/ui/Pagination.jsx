import { ChevronLeft, ChevronRight } from 'lucide-react'

export default function Pagination({ page, pageCount, onPageChange, totalCount, pageSize = 10 }) {
  if (pageCount <= 1) return null

  const start = (page - 1) * pageSize + 1
  const end = Math.min(page * pageSize, totalCount)

  return (
    <div className="flex items-center justify-between px-1 py-4">
      <p className="text-xs text-ink900/45 dark:text-night-muted">
        Showing <span className="num">{start}</span>–<span className="num">{end}</span> of{' '}
        <span className="num">{totalCount}</span>
      </p>
      <div className="flex items-center gap-1.5">
        <button
          onClick={() => onPageChange(page - 1)}
          disabled={page <= 1}
          className="p-2 rounded-lg border border-paper-line dark:border-night-line text-ink900 dark:text-night-text disabled:opacity-40 disabled:cursor-not-allowed hover:border-emerald-600 transition-colors"
          aria-label="Previous page"
        >
          <ChevronLeft size={16} />
        </button>
        <span className="num text-sm text-ink900/70 dark:text-night-text/70 px-2">
          {page} / {pageCount}
        </span>
        <button
          onClick={() => onPageChange(page + 1)}
          disabled={page >= pageCount}
          className="p-2 rounded-lg border border-paper-line dark:border-night-line text-ink900 dark:text-night-text disabled:opacity-40 disabled:cursor-not-allowed hover:border-emerald-600 transition-colors"
          aria-label="Next page"
        >
          <ChevronRight size={16} />
        </button>
      </div>
    </div>
  )
}
