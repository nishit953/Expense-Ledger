export function Skeleton({ className = '' }) {
  return (
    <div
      className={`animate-pulse bg-paper-line/70 dark:bg-night-line/70 rounded-md ${className}`}
    />
  )
}

export function SkeletonRow() {
  return (
    <div className="flex items-center gap-4 py-4 px-1">
      <Skeleton className="w-10 h-10 rounded-full flex-shrink-0" />
      <div className="flex-1 space-y-2">
        <Skeleton className="h-3.5 w-1/3" />
        <Skeleton className="h-3 w-1/5" />
      </div>
      <Skeleton className="h-4 w-16" />
    </div>
  )
}

export function SkeletonCard() {
  return (
    <div className="rounded-xl2 border border-paper-line dark:border-night-line p-6 space-y-3">
      <Skeleton className="h-3 w-1/2" />
      <Skeleton className="h-7 w-2/3" />
      <Skeleton className="h-3 w-1/3" />
    </div>
  )
}

export function SkeletonTable({ rows = 5 }) {
  return (
    <div className="divide-y divide-paper-line dark:divide-night-line">
      {Array.from({ length: rows }).map((_, i) => (
        <SkeletonRow key={i} />
      ))}
    </div>
  )
}
