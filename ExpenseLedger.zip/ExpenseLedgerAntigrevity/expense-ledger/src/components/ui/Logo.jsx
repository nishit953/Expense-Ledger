import { Link } from 'react-router-dom'

export default function Logo({ className = '' }) {
  return (
    <Link to="/" className={`flex items-center gap-2 group ${className}`}>
      <span className="relative w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center overflow-hidden">
        <span className="absolute inset-0 bg-gradient-to-br from-emerald-400 to-emerald-700 opacity-90" />
        <span className="relative text-white font-display font-bold text-sm">E</span>
      </span>
      <span className="font-display font-semibold text-lg tracking-tight text-ink900 dark:text-night-text">
        Expense<span className="text-emerald-600">Ledger</span>
      </span>
    </Link>
  )
}
