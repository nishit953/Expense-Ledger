import { forwardRef, useState } from 'react'
import { Loader2 } from 'lucide-react'
import { classNames } from '../../utils/format'

const variants = {
  primary:
    'bg-emerald-600 text-white hover:bg-emerald-700 shadow-soft hover:shadow-glow',
  secondary:
    'bg-ink900 text-white hover:bg-ink900/90 dark:bg-white dark:text-ink900 dark:hover:bg-white/90',
  outline:
    'border border-paper-line text-ink900 hover:border-emerald-600 hover:text-emerald-700 dark:border-night-line dark:text-night-text dark:hover:border-emerald-500',
  ghost:
    'text-ink900 hover:bg-black/5 dark:text-night-text dark:hover:bg-white/5',
}

const sizes = {
  sm: 'text-sm px-3.5 py-2 rounded-lg',
  md: 'text-sm px-5 py-2.5 rounded-xl',
  lg: 'text-base px-6 py-3.5 rounded-xl',
}

const Button = forwardRef(
  (
    {
      children,
      variant = 'primary',
      size = 'md',
      className = '',
      loading = false,
      onClick,
      type = 'button',
      ...props
    },
    ref
  ) => {
    const [ripples, setRipples] = useState([])

    const handleClick = (e) => {
      const rect = e.currentTarget.getBoundingClientRect()
      const id = Date.now()
      const ripple = {
        id,
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
        size: Math.max(rect.width, rect.height) * 2,
      }
      setRipples((r) => [...r, ripple])
      setTimeout(() => setRipples((r) => r.filter((rp) => rp.id !== id)), 600)
      onClick?.(e)
    }

    return (
      <button
        ref={ref}
        type={type}
        onClick={handleClick}
        disabled={loading || props.disabled}
        className={classNames(
          'relative overflow-hidden font-medium inline-flex items-center justify-center gap-2 transition-all duration-200 disabled:opacity-60 disabled:cursor-not-allowed',
          variants[variant],
          sizes[size],
          className
        )}
        {...props}
      >
        {ripples.map((r) => (
          <span
            key={r.id}
            className="absolute rounded-full bg-white/30 pointer-events-none animate-ping"
            style={{
              left: r.x - r.size / 2,
              top: r.y - r.size / 2,
              width: r.size,
              height: r.size,
              animationDuration: '600ms',
              animationIterationCount: 1,
            }}
          />
        ))}
        {loading && <Loader2 size={16} className="animate-spin" />}
        {children}
      </button>
    )
  }
)

Button.displayName = 'Button'
export default Button
