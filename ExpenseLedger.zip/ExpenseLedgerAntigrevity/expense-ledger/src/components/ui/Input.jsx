import { forwardRef, useState } from 'react'
import { Eye, EyeOff } from 'lucide-react'
import { classNames } from '../../utils/format'

const Input = forwardRef(
  ({ label, error, type = 'text', icon: Icon, className = '', ...props }, ref) => {
    const [show, setShow] = useState(false)
    const isPassword = type === 'password'
    const inputType = isPassword ? (show ? 'text' : 'password') : type

    return (
      <div className="w-full">
        {label && (
          <label className="block text-sm font-medium text-ink900/80 dark:text-night-text/80 mb-1.5">
            {label}
          </label>
        )}
        <div className="relative">
          {Icon && (
            <Icon
              size={18}
              className="absolute left-3.5 top-1/2 -translate-y-1/2 text-ink900/40 dark:text-night-muted"
            />
          )}
          <input
            ref={ref}
            type={inputType}
            className={classNames(
              'w-full rounded-xl border bg-white dark:bg-night-surface text-ink900 dark:text-night-text px-4 py-3 text-sm outline-none transition-all placeholder:text-ink900/35 dark:placeholder:text-night-muted/60',
              Icon ? 'pl-11' : '',
              isPassword ? 'pr-11' : '',
              error
                ? 'border-red-400 focus:border-red-500'
                : 'border-paper-line dark:border-night-line focus:border-emerald-600',
              className
            )}
            {...props}
          />
          {isPassword && (
            <button
              type="button"
              tabIndex={-1}
              onClick={() => setShow((s) => !s)}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-ink900/40 dark:text-night-muted hover:text-ink900 dark:hover:text-night-text transition-colors"
              aria-label={show ? 'Hide password' : 'Show password'}
            >
              {show ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          )}
        </div>
        {error && <p className="mt-1.5 text-xs text-red-500">{error}</p>}
      </div>
    )
  }
)

Input.displayName = 'Input'
export default Input
