import { Target, Receipt, TrendingUp, CalendarDays, ArrowUpRight, ArrowDownLeft } from 'lucide-react'
import { Card } from '../ui/Card'
import { SkeletonCard } from '../ui/Skeleton'
import { formatCurrency } from '../../utils/format'

export default function ProfileStatsPanel({ summary, loading }) {
  if (loading) {
    return (
      <div className="space-y-5">
        <SkeletonCard />
        <SkeletonCard />
      </div>
    )
  }

  if (!summary) return null

  const { goal_summary, account_statistics, recent_activity } = summary

  return (
    <div className="space-y-5">
      <Card className="p-6">
        <p className="flex items-center gap-2 text-sm font-medium text-ink900/70 dark:text-night-text/70 mb-4">
          <Target size={15} /> Financial goals
        </p>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="num text-xl font-semibold text-ink900 dark:text-night-text">{goal_summary.active_goals}</p>
            <p className="text-xs text-ink900/45 dark:text-night-muted">Active</p>
          </div>
          <div>
            <p className="num text-xl font-semibold text-emerald-600">{goal_summary.overall_progress}%</p>
            <p className="text-xs text-ink900/45 dark:text-night-muted">Avg. progress</p>
          </div>
        </div>
      </Card>

      <Card className="p-6">
        <p className="flex items-center gap-2 text-sm font-medium text-ink900/70 dark:text-night-text/70 mb-4">
          <Receipt size={15} /> Account statistics
        </p>
        <div className="space-y-3 text-sm">
          <div className="flex items-center justify-between">
            <span className="text-ink900/55 dark:text-night-muted flex items-center gap-1.5">
              <CalendarDays size={13} /> Member since
            </span>
            <span className="num text-ink900 dark:text-night-text">{account_statistics.member_since}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-ink900/55 dark:text-night-muted">Expenses logged</span>
            <span className="num text-ink900 dark:text-night-text">{account_statistics.total_expenses_logged}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-ink900/55 dark:text-night-muted">Income entries</span>
            <span className="num text-ink900 dark:text-night-text">{account_statistics.total_income_logged}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-ink900/55 dark:text-night-muted flex items-center gap-1.5">
              <TrendingUp size={13} /> Lifetime savings
            </span>
            <span className="num text-emerald-600 font-medium">{formatCurrency(account_statistics.lifetime_savings)}</span>
          </div>
        </div>
      </Card>

      <Card className="p-6">
        <p className="text-sm font-medium text-ink900/70 dark:text-night-text/70 mb-3">Recent activity</p>
        {recent_activity.length === 0 ? (
          <p className="text-sm text-ink900/45 dark:text-night-muted">No activity yet.</p>
        ) : (
          <div className="divide-y divide-paper-line dark:divide-night-line">
            {recent_activity.map((item, i) => (
              <div key={i} className="flex items-center justify-between py-2.5">
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 ${
                      item.type === 'income' ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600' : 'bg-ink-50 dark:bg-ink-900/20 text-ink-600'
                    }`}
                  >
                    {item.type === 'income' ? <ArrowDownLeft size={12} /> : <ArrowUpRight size={12} />}
                  </div>
                  <p className="text-xs text-ink900/70 dark:text-night-text/70 truncate max-w-[140px]">{item.title}</p>
                </div>
                <p className={`num text-xs font-medium ${item.type === 'income' ? 'text-emerald-600' : 'text-ink900/60 dark:text-night-text/60'}`}>
                  {item.type === 'income' ? '+' : '-'}{formatCurrency(item.amount)}
                </p>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  )
}
