import { useForm } from 'react-hook-form'
import Input from '../ui/Input'
import { Select } from '../ui/Badge'
import Button from '../ui/Button'
import { GOAL_CATEGORIES, GOAL_PRIORITIES } from '../../services/goalService'

export default function GoalForm({ initialValues, onSubmit, onCancel, submitting }) {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    defaultValues: initialValues || {
      name: '', category: 'custom', target_amount: '', target_date: '', priority: 'medium', description: '',
    },
  })

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
      <Input
        label="Goal name"
        placeholder="e.g. Emergency fund"
        {...register('name', { required: 'Goal name is required', maxLength: { value: 200, message: 'Too long' } })}
        error={errors.name?.message}
      />

      <div className="grid sm:grid-cols-2 gap-4">
        <Select label="Category" options={GOAL_CATEGORIES} {...register('category', { required: true })} />
        <Select label="Priority" options={GOAL_PRIORITIES} {...register('priority', { required: true })} />
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <Input
          label="Target amount (₹)"
          type="number"
          step="0.01"
          placeholder="0.00"
          {...register('target_amount', {
            required: 'Target amount is required',
            min: { value: 0.01, message: 'Must be greater than 0' },
          })}
          error={errors.target_amount?.message}
        />
        <Input
          label="Target date"
          type="date"
          {...register('target_date', { required: 'Target date is required' })}
          error={errors.target_date?.message}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-ink900/80 dark:text-night-text/80 mb-1.5">
          Description
        </label>
        <textarea
          rows={3}
          placeholder="What's this goal for?"
          {...register('description')}
          className="w-full rounded-xl border border-paper-line dark:border-night-line bg-white dark:bg-night-surface text-ink900 dark:text-night-text px-4 py-3 text-sm outline-none focus:border-emerald-600 transition-colors resize-none"
        />
      </div>

      <div className="flex gap-3 pt-2">
        <Button type="submit" loading={submitting} className="flex-1">
          {initialValues ? 'Save changes' : 'Create goal'}
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  )
}
