import { Target, CheckCircle2, PiggyBank } from 'lucide-react'
import { Card } from '../ui/Card'
import { formatCurrency } from '../../utils/format'

export default function GoalsSummaryStrip({ summary }) {
  if (!summary) return null

  return (
    <div className="grid sm:grid-cols-3 gap-5 mb-6">
      <Card className="p-5 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-900/20 flex items-center justify-center flex-shrink-0">
          <Target size={18} className="text-emerald-600" />
        </div>
        <div>
          <p className="num text-lg font-semibold text-ink900 dark:text-night-text">{summary.active_goals}</p>
          <p className="text-xs text-ink900/45 dark:text-night-muted">Active goals</p>
        </div>
      </Card>
      <Card className="p-5 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-violet-50 dark:bg-violet-900/20 flex items-center justify-center flex-shrink-0">
          <CheckCircle2 size={18} className="text-violet-600" />
        </div>
        <div>
          <p className="num text-lg font-semibold text-ink900 dark:text-night-text">{summary.completed_goals}</p>
          <p className="text-xs text-ink900/45 dark:text-night-muted">Completed</p>
        </div>
      </Card>
      <Card className="p-5 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-ink-50 dark:bg-ink-900/20 flex items-center justify-center flex-shrink-0">
          <PiggyBank size={18} className="text-ink-600" />
        </div>
        <div>
          <p className="num text-lg font-semibold text-ink900 dark:text-night-text">
            {formatCurrency(summary.total_saved_amount)}
          </p>
          <p className="text-xs text-ink900/45 dark:text-night-muted">
            of {formatCurrency(summary.total_target_amount)} targeted
          </p>
        </div>
      </Card>
    </div>
  )
}
