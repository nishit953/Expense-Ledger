import { Search, X } from 'lucide-react'
import Input from '../ui/Input'
import { Select } from '../ui/Badge'
import { GOAL_CATEGORIES, GOAL_PRIORITIES } from '../../services/goalService'

export default function GoalFilters({ filters, onChange }) {
  const update = (patch) => onChange({ ...filters, ...patch })
  const clear = () => onChange({ search: '', category: '', priority: '', status: '', ordering: 'target_date' })
  const activeCount = ['category', 'priority', 'status'].filter((k) => filters[k]).length

  return (
    <div className="flex flex-col sm:flex-row gap-3 mb-6">
      <div className="flex-1">
        <Input icon={Search} placeholder="Search goals..." value={filters.search} onChange={(e) => update({ search: e.target.value })} />
      </div>
      <Select
        value={filters.status}
        onChange={(e) => update({ status: e.target.value })}
        className="sm:max-w-[160px]"
        options={[
          { value: '', label: 'All statuses' },
          { value: 'active', label: 'Active' },
          { value: 'completed', label: 'Completed' },
          { value: 'abandoned', label: 'Abandoned' },
        ]}
      />
      <Select
        value={filters.category}
        onChange={(e) => update({ category: e.target.value })}
        className="sm:max-w-[180px]"
        options={[{ value: '', label: 'All categories' }, ...GOAL_CATEGORIES]}
      />
      <Select
        value={filters.priority}
        onChange={(e) => update({ priority: e.target.value })}
        className="sm:max-w-[150px]"
        options={[{ value: '', label: 'All priorities' }, ...GOAL_PRIORITIES]}
      />
      <Select
        value={filters.ordering}
        onChange={(e) => update({ ordering: e.target.value })}
        className="sm:max-w-[170px]"
        options={[
          { value: 'target_date', label: 'Deadline soonest' },
          { value: '-target_date', label: 'Deadline latest' },
          { value: '-target_amount', label: 'Highest target' },
          { value: '-created_at', label: 'Newest first' },
        ]}
      />
      {activeCount > 0 && (
        <button onClick={clear} className="flex items-center gap-1.5 text-sm text-ink900/50 dark:text-night-muted hover:text-red-500 transition-colors px-2">
          <X size={14} /> Clear
        </button>
      )}
    </div>
  )
}
