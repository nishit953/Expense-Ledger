import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Pencil, Trash2, PiggyBank, Clock, Flag, Ban, RotateCcw, TrendingUp } from 'lucide-react'
import { CategoryBadge } from '../ui/Badge'
import BudgetProgressBar from '../budgets/BudgetProgressBar'
import { formatCurrency } from '../../utils/format'
import { GOAL_CATEGORIES } from '../../services/goalService'
import { fetchGoalForecast } from '../../services/mlService'

const categoryLabel = (v) => GOAL_CATEGORIES.find((c) => c.value === v)?.label || v

const priorityColors = {
  high: 'text-red-500',
  medium: 'text-amber-500',
  low: 'text-ink900/40 dark:text-night-muted',
}

const statusToProgressStatus = (statusLabel) => {
  if (statusLabel === 'completed') return 'on_track'
  if (statusLabel === 'overdue') return 'exceeded'
  return 'on_track'
}

const paceCopy = {
  ahead: { text: 'Ahead of pace', color: 'text-emerald-600 dark:text-emerald-400' },
  on_track: { text: 'On track for your deadline', color: 'text-emerald-600 dark:text-emerald-400' },
  behind: { text: 'Behind pace for your deadline', color: 'text-amber-600 dark:text-amber-400' },
}

export default function GoalCard({ goal, onEdit, onDelete, onContribute, onAbandon, onReactivate }) {
  const isActive = goal.status === 'active'
  const isAbandoned = goal.status === 'abandoned'
  const [forecast, setForecast] = useState(null)

  useEffect(() => {
    if (!isActive) return
    let cancelled = false
    fetchGoalForecast(goal.id)
      .then((result) => {
        if (!cancelled && result.pace_status !== 'stalled') setForecast(result)
      })
      .catch(() => {})
    return () => {
      cancelled = true
    }
  }, [goal.id, isActive])

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
      className="rounded-xl2 border border-paper-line dark:border-night-line bg-white dark:bg-night-card p-5 hover:shadow-card transition-shadow group"
    >
      <div className="flex items-start justify-between mb-3">
        <div>
          <CategoryBadge category={goal.category} label={goal.category_display || categoryLabel(goal.category)} />
          <h3 className="font-display font-semibold text-ink900 dark:text-night-text mt-2">{goal.name}</h3>
        </div>
        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button onClick={() => onEdit(goal)} className="p-1.5 rounded-lg text-ink900/50 dark:text-night-muted hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20" aria-label="Edit">
            <Pencil size={14} />
          </button>
          <button onClick={() => onDelete(goal)} className="p-1.5 rounded-lg text-ink900/50 dark:text-night-muted hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/10" aria-label="Delete">
            <Trash2 size={14} />
          </button>
        </div>
      </div>

      <div className="flex items-baseline justify-between mb-1">
        <span className="num text-xl font-semibold text-ink900 dark:text-night-text">{formatCurrency(goal.saved_amount)}</span>
        <span className="num text-sm text-ink900/45 dark:text-night-muted">of {formatCurrency(goal.target_amount)}</span>
      </div>

      <BudgetProgressBar percentage={goal.progress_percentage} status={statusToProgressStatus(goal.status_label)} className="my-3" />

      <div className="flex items-center justify-between text-xs mb-4">
        <span className={`flex items-center gap-1.5 font-medium ${priorityColors[goal.priority]}`}>
          <Flag size={12} /> {goal.priority_display} priority
        </span>
        <span className="flex items-center gap-1.5 text-ink900/45 dark:text-night-muted">
          <Clock size={12} />
          {goal.status_label === 'completed'
            ? 'Completed'
            : goal.status_label === 'overdue'
            ? 'Overdue'
            : `${goal.days_remaining} day(s) left`}
        </span>
      </div>

      {forecast && (
        <p className={`flex items-center gap-1.5 text-xs mb-4 -mt-2 ${paceCopy[forecast.pace_status]?.color || 'text-ink900/45'}`}>
          <TrendingUp size={12} /> {paceCopy[forecast.pace_status]?.text}
        </p>
      )}

      <div className="flex gap-2">
        {isActive && (
          <button
            onClick={() => onContribute(goal)}
            className="flex-1 flex items-center justify-center gap-1.5 text-sm font-medium py-2 rounded-lg bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-900/30 transition-colors"
          >
            <PiggyBank size={14} /> Contribute
          </button>
        )}
        {isActive && (
          <button
            onClick={() => onAbandon(goal)}
            className="flex items-center justify-center gap-1.5 text-sm font-medium py-2 px-3 rounded-lg text-ink900/50 dark:text-night-muted hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
          >
            <Ban size={14} />
          </button>
        )}
        {isAbandoned && (
          <button
            onClick={() => onReactivate(goal)}
            className="flex-1 flex items-center justify-center gap-1.5 text-sm font-medium py-2 rounded-lg bg-ink-50 dark:bg-ink-900/20 text-ink-700 dark:text-ink-400 hover:bg-ink-100 transition-colors"
          >
            <RotateCcw size={14} /> Reactivate
          </button>
        )}
      </div>
    </motion.div>
  )
}
