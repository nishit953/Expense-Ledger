import { useForm } from 'react-hook-form'
import Input from '../ui/Input'
import Button from '../ui/Button'

export default function ContributeForm({ onSubmit, onCancel, submitting }) {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    defaultValues: { amount: '', date: new Date().toISOString().slice(0, 10), note: '' },
  })

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
      <Input
        label="Contribution amount (₹)"
        type="number"
        step="0.01"
        placeholder="0.00"
        {...register('amount', {
          required: 'Amount is required',
          min: { value: 0.01, message: 'Must be greater than 0' },
        })}
        error={errors.amount?.message}
      />
      <Input label="Date" type="date" {...register('date', { required: 'Date is required' })} error={errors.date?.message} />
      <Input label="Note" placeholder="Optional note" {...register('note')} />

      <div className="flex gap-3 pt-2">
        <Button type="submit" loading={submitting} className="flex-1">
          Add contribution
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  )
}
