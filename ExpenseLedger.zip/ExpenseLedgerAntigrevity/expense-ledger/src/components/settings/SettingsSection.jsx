import { Card } from '../ui/Card'

export default function SettingsSection({ icon: Icon, title, description, children }) {
  return (
    <Card className="p-6 sm:p-7">
      <div className="flex items-start gap-3 mb-6">
        {Icon && (
          <div className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-900/20 flex items-center justify-center flex-shrink-0">
            <Icon size={16} className="text-emerald-600" />
          </div>
        )}
        <div>
          <h3 className="font-display font-semibold text-ink900 dark:text-night-text">{title}</h3>
          {description && <p className="text-xs text-ink900/45 dark:text-night-muted mt-0.5">{description}</p>}
        </div>
      </div>
      {children}
    </Card>
  )
}
