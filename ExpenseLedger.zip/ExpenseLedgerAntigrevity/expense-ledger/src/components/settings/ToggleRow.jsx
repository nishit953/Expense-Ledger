export default function ToggleRow({ label, description, checked, onChange }) {
  return (
    <div className="flex items-center justify-between py-3">
      <div className="pr-4">
        <p className="text-sm font-medium text-ink900 dark:text-night-text">{label}</p>
        {description && <p className="text-xs text-ink900/45 dark:text-night-muted mt-0.5">{description}</p>}
      </div>
      <button
        onClick={() => onChange(!checked)}
        aria-label={label}
        className={`relative w-12 h-7 rounded-full flex items-center px-1 flex-shrink-0 transition-colors duration-300 ${
          checked ? 'bg-emerald-600' : 'bg-paper-line dark:bg-night-line'
        }`}
      >
        <span
          className={`w-5 h-5 rounded-full bg-white shadow-soft transition-transform duration-300 ${
            checked ? 'translate-x-5' : 'translate-x-0'
          }`}
        />
      </button>
    </div>
  )
}
