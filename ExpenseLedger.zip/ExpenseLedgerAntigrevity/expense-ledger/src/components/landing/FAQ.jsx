import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronDown } from 'lucide-react'
import { faqs } from '../../services/mockData'

export default function FAQ() {
  const [open, setOpen] = useState(0)

  return (
    <section id="faq" className="container-page py-20 sm:py-28">
      <div className="max-w-2xl mb-12">
        <p className="text-sm font-medium text-ink-600 dark:text-ink-300 mb-3">FAQ</p>
        <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight text-ink900 dark:text-night-text">
          Questions, answered
        </h2>
      </div>

      <div className="max-w-3xl divide-y divide-paper-line dark:divide-night-line border-t border-b border-paper-line dark:border-night-line">
        {faqs.map((item, i) => {
          const isOpen = open === i
          return (
            <div key={item.q}>
              <button
                onClick={() => setOpen(isOpen ? -1 : i)}
                className="w-full flex items-center justify-between py-5 text-left"
              >
                <span className="font-medium text-ink900 dark:text-night-text pr-6">
                  {item.q}
                </span>
                <ChevronDown
                  size={18}
                  className={`flex-shrink-0 text-ink900/50 dark:text-night-muted transition-transform duration-300 ${
                    isOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>
              <AnimatePresence>
                {isOpen && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.25 }}
                    className="overflow-hidden"
                  >
                    <p className="pb-5 text-sm text-ink900/55 dark:text-night-muted leading-relaxed max-w-2xl">
                      {item.a}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )
        })}
      </div>
    </section>
  )
}
