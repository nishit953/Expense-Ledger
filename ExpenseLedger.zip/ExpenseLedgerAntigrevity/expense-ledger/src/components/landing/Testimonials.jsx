import { motion } from 'framer-motion'
import { Quote } from 'lucide-react'
import { Card } from '../ui/Card'
import { testimonials } from '../../services/mockData'

export default function Testimonials() {
  return (
    <section className="container-page py-20 sm:py-28">
      <div className="max-w-2xl mb-14">
        <p className="text-sm font-medium text-violet-600 dark:text-violet-400 mb-3">
          Trusted by early users
        </p>
        <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight text-ink900 dark:text-night-text">
          People keep their ledger open
        </h2>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {testimonials.map((t, i) => (
          <motion.div
            key={t.name}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.5, delay: i * 0.08 }}
          >
            <Card hover className="p-7 h-full flex flex-col">
              <Quote size={22} className="text-emerald-600/40 mb-4" />
              <p className="text-sm text-ink900/75 dark:text-night-text/80 leading-relaxed flex-1">
                {t.quote}
              </p>
              <div className="mt-6 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-400 to-violet-500 flex items-center justify-center text-white text-sm font-semibold font-display">
                  {t.name.charAt(0)}
                </div>
                <div>
                  <p className="text-sm font-medium text-ink900 dark:text-night-text">
                    {t.name}
                  </p>
                  <p className="text-xs text-ink900/45 dark:text-night-muted">{t.role}</p>
                </div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>
    </section>
  )
}
