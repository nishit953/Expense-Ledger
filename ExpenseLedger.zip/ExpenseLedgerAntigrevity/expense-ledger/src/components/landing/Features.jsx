import { motion } from 'framer-motion'
import { Card } from '../ui/Card'
import { features } from '../../services/mockData'

export default function Features() {
  return (
    <section id="features" className="container-page py-20 sm:py-28">
      <div className="max-w-2xl mb-14">
        <p className="text-sm font-medium text-emerald-700 dark:text-emerald-400 mb-3">
          Everything in one ledger
        </p>
        <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight text-ink900 dark:text-night-text">
          Built for how money actually moves
        </h2>
        <p className="mt-4 text-ink900/55 dark:text-night-muted text-lg">
          Six systems, one running total — spending, saving, and investing
          tracked without switching apps.
        </p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {features.map((f, i) => (
          <motion.div
            key={f.title}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.5, delay: i * 0.06 }}
          >
            <Card hover className="p-7 h-full">
              <div className="w-11 h-11 rounded-xl bg-emerald-50 dark:bg-emerald-900/20 flex items-center justify-center mb-5">
                <f.icon size={20} className="text-emerald-600 dark:text-emerald-400" />
              </div>
              <h3 className="font-display text-lg font-semibold text-ink900 dark:text-night-text mb-2">
                {f.title}
              </h3>
              <p className="text-sm text-ink900/55 dark:text-night-muted leading-relaxed">
                {f.desc}
              </p>
            </Card>
          </motion.div>
        ))}
      </div>
    </section>
  )
}
