import { motion } from 'framer-motion'
import { AreaChart, Area, ResponsiveContainer, Tooltip, XAxis } from 'recharts'
import { howItWorks, chartData } from '../../services/mockData'
import { formatCurrency } from '../../utils/format'

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-white dark:bg-night-card border border-paper-line dark:border-night-line rounded-lg shadow-card px-3.5 py-2.5 text-xs">
      <p className="font-medium text-ink900 dark:text-night-text mb-1">{label}</p>
      {payload.map((p) => (
        <p key={p.dataKey} className="num text-ink900/60 dark:text-night-muted">
          {p.dataKey === 'spend' ? 'Spent' : 'Saved'}: {formatCurrency(p.value)}
        </p>
      ))}
    </div>
  )
}

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="bg-white dark:bg-night-surface border-y border-paper-line dark:border-night-line">
      <div className="container-page py-20 sm:py-28 grid lg:grid-cols-2 gap-16 items-center">
        <div>
          <p className="text-sm font-medium text-ink-600 dark:text-ink-300 mb-3">How it works</p>
          <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight text-ink900 dark:text-night-text mb-10">
            From transaction to insight, automatically
          </h2>

          <div className="space-y-8">
            {howItWorks.map((step, i) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, x: -16 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: '-60px' }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="flex gap-5"
              >
                <div className="num flex-shrink-0 w-10 h-10 rounded-full bg-ink900 dark:bg-emerald-600 text-white flex items-center justify-center text-sm font-semibold">
                  {i + 1}
                </div>
                <div>
                  <h3 className="font-display font-semibold text-ink900 dark:text-night-text mb-1">
                    {step.title}
                  </h3>
                  <p className="text-sm text-ink900/55 dark:text-night-muted leading-relaxed">
                    {step.desc}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="bg-paper-light dark:bg-night-card rounded-2xl border border-paper-line dark:border-night-line p-6 sm:p-8"
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <p className="text-xs uppercase tracking-wide text-ink900/45 dark:text-night-muted font-medium">
                Spend vs. saved
              </p>
              <p className="font-display font-semibold text-ink900 dark:text-night-text">
                Last 6 months
              </p>
            </div>
            <div className="flex gap-4 text-xs">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-ink-500" /> Spent
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Saved
              </span>
            </div>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="spendFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#3B67F5" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="#3B67F5" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="savedFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10B981" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="#10B981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis
                  dataKey="month"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: '#8FA39B' }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="spend"
                  stroke="#3B67F5"
                  strokeWidth={2}
                  fill="url(#spendFill)"
                />
                <Area
                  type="monotone"
                  dataKey="saved"
                  stroke="#10B981"
                  strokeWidth={2}
                  fill="url(#savedFill)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
