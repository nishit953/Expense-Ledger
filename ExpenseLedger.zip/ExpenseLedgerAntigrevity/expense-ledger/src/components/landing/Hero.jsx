import { motion } from 'framer-motion'
import { ArrowRight, ArrowUpRight } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import Button from '../ui/Button'
import StatCounter from '../ui/StatCounter'
import { heroStats } from '../../services/mockData'
import { formatCurrency } from '../../utils/format'

const tickerRows = [
  { label: 'Groceries — BigBasket', amount: -2140, time: 'Today, 9:12 AM' },
  { label: 'Salary credited', amount: 84000, time: 'Yesterday' },
  { label: 'SIP — Nifty 50 Index', amount: -5000, time: '2 days ago' },
  { label: 'Electricity bill', amount: -1860, time: '3 days ago' },
]

export default function Hero() {
  const navigate = useNavigate()

  return (
    <section className="relative overflow-hidden ledger-texture">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[500px] bg-gradient-to-br from-emerald-300/25 via-ink-300/15 to-violet-300/20 blur-3xl rounded-full pointer-events-none" />

      {/* floating shapes */}
      <div className="absolute top-24 left-[8%] w-16 h-16 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 animate-float hidden md:block" />
      <div
        className="absolute bottom-32 right-[10%] w-12 h-12 rounded-full bg-violet-500/10 border border-violet-500/20 animate-float hidden md:block"
        style={{ animationDelay: '1.2s' }}
      />
      <div
        className="absolute top-1/3 right-[6%] w-10 h-10 rounded-xl bg-ink-500/10 border border-ink-500/20 animate-float hidden md:block"
        style={{ animationDelay: '2.4s' }}
      />

      <div className="container-page relative pt-16 sm:pt-24 pb-20 sm:pb-28">
        <div className="grid lg:grid-cols-2 gap-14 items-center">
          <div>
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-400 text-xs font-medium mb-6"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              AI insights refreshed every night
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-4xl sm:text-5xl lg:text-6xl font-semibold tracking-tight text-ink900 dark:text-night-text leading-[1.08]"
            >
              Every rupee,
              <br />
              <span className="text-emerald-600">accounted for.</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="mt-6 text-lg text-ink900/60 dark:text-night-muted max-w-lg"
            >
              ExpenseLedger keeps spending, budgets, and investments in one
              running ledger — with AI that catches the leaks before you do.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="mt-9 flex flex-col sm:flex-row gap-3"
            >
              <Button size="lg" onClick={() => navigate('/register')}>
                Start your ledger <ArrowRight size={17} />
              </Button>
              <Button size="lg" variant="outline">
                See how it works
              </Button>
            </motion.div>

            <div className="mt-14 grid grid-cols-3 gap-6 max-w-md">
              {heroStats.map((s) => (
                <StatCounter key={s.label} {...s} />
              ))}
            </div>
          </div>

          {/* Signature element: a live-updating ledger ticker card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.94 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="relative"
          >
            <div className="glass rounded-2xl shadow-card p-6 sm:p-7 max-w-md mx-auto">
              <div className="flex items-center justify-between mb-1">
                <p className="text-xs uppercase tracking-wider text-ink900/45 dark:text-night-muted font-medium">
                  This month’s ledger
                </p>
                <span className="flex items-center gap-1 text-xs font-medium text-emerald-700 dark:text-emerald-400">
                  <ArrowUpRight size={13} /> On track
                </span>
              </div>
              <p className="num text-3xl font-semibold text-ink900 dark:text-night-text mt-1">
                {formatCurrency(74260)}
              </p>
              <p className="text-xs text-ink900/45 dark:text-night-muted mt-0.5">
                saved so far this month
              </p>

              <div className="mt-6 divide-y divide-paper-line dark:divide-night-line border-t border-paper-line dark:border-night-line">
                {tickerRows.map((row, i) => (
                  <motion.div
                    key={row.label}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: 0.5 + i * 0.12 }}
                    className="flex items-center justify-between py-3"
                  >
                    <div>
                      <p className="text-sm text-ink900 dark:text-night-text font-medium">
                        {row.label}
                      </p>
                      <p className="text-xs text-ink900/40 dark:text-night-muted">{row.time}</p>
                    </div>
                    <p
                      className={`num text-sm font-semibold ${
                        row.amount > 0
                          ? 'text-emerald-600'
                          : 'text-ink900/75 dark:text-night-text/75'
                      }`}
                    >
                      {row.amount > 0 ? '+' : ''}
                      {formatCurrency(row.amount)}
                    </p>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
