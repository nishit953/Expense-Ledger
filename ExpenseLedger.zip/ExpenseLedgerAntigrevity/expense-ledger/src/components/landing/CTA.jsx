import { motion } from 'framer-motion'
import { ArrowRight } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import Button from '../ui/Button'

export default function CTA() {
  const navigate = useNavigate()

  return (
    <section className="container-page py-20 sm:py-24">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="relative overflow-hidden rounded-2xl bg-ink900 dark:bg-night-card px-8 py-16 sm:py-20 text-center"
      >
        <div className="absolute inset-0 ledger-texture opacity-30 text-white" />
        <div className="absolute -top-24 -right-24 w-72 h-72 bg-emerald-500/20 rounded-full blur-3xl" />
        <div className="relative">
          <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight text-white max-w-xl mx-auto">
            Start your ledger in under two minutes
          </h2>
          <p className="mt-4 text-white/60 max-w-md mx-auto">
            No credit card, no setup fee — just a clearer picture of where your
            money goes.
          </p>
          <Button
            size="lg"
            variant="primary"
            className="mt-8"
            onClick={() => navigate('/register')}
          >
            Get Started <ArrowRight size={17} />
          </Button>
        </div>
      </motion.div>
    </section>
  )
}
