import { motion } from 'framer-motion'
import { Check } from 'lucide-react'
import { Card } from '../ui/Card'
import Button from '../ui/Button'
import { pricingPlans } from '../../services/mockData'
import { classNames } from '../../utils/format'

export default function Pricing() {
  return (
    <section id="pricing" className="bg-white dark:bg-night-surface border-y border-paper-line dark:border-night-line">
      <div className="container-page py-20 sm:py-28">
        <div className="max-w-2xl mx-auto text-center mb-14">
          <p className="text-sm font-medium text-emerald-700 dark:text-emerald-400 mb-3">
            Pricing
          </p>
          <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight text-ink900 dark:text-night-text">
            Simple plans, coming soon
          </h2>
          <p className="mt-4 text-ink900/55 dark:text-night-muted text-lg">
            ExpenseLedger is in Phase 1. Pricing below reflects the planned
            structure at launch.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {pricingPlans.map((plan, i) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
            >
              <Card
                className={classNames(
                  'p-8 h-full flex flex-col relative',
                  plan.highlighted && 'border-emerald-600 border-2 shadow-glow'
                )}
              >
                {plan.highlighted && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-emerald-600 text-white text-xs font-medium px-3 py-1 rounded-full">
                    Most anticipated
                  </span>
                )}
                <h3 className="font-display text-xl font-semibold text-ink900 dark:text-night-text">
                  {plan.name}
                </h3>
                <p className="text-sm text-ink900/50 dark:text-night-muted mt-1">
                  {plan.tagline}
                </p>
                <p className="num text-3xl font-semibold text-ink900 dark:text-night-text mt-6">
                  {plan.price}
                </p>

                <ul className="mt-7 space-y-3 flex-1">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2.5 text-sm text-ink900/70 dark:text-night-text/70">
                      <Check size={16} className="text-emerald-600 flex-shrink-0 mt-0.5" />
                      {f}
                    </li>
                  ))}
                </ul>

                <Button
                  variant={plan.highlighted ? 'primary' : 'outline'}
                  className="mt-8 w-full"
                  disabled={plan.price === 'Coming soon'}
                >
                  {plan.price === 'Free' ? 'Get started' : 'Coming soon'}
                </Button>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
