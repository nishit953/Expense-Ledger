import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis } from 'recharts'
import { Card } from '../ui/Card'
import { formatCurrency } from '../../utils/format'

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-white dark:bg-night-card border border-paper-line dark:border-night-line rounded-lg shadow-card px-3.5 py-2.5 text-xs">
      <p className="font-medium text-ink900 dark:text-night-text mb-1">{label}</p>
      <p className="num text-ink900/60 dark:text-night-muted">{formatCurrency(payload[0].value)}</p>
    </div>
  )
}

export default function WeeklySpendingChart({ data, loading }) {
  return (
    <Card className="p-6">
      <p className="text-sm font-medium text-ink900/70 dark:text-night-text/70 mb-5">Weekly spending pattern</p>
      <div className="h-56">
        {loading ? (
          <div className="w-full h-full bg-paper-line/50 dark:bg-night-line/50 rounded-lg animate-pulse" />
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
              <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#8FA39B' }} />
              <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(5,150,105,0.06)' }} />
              <Bar dataKey="total" fill="#7C3AED" radius={[6, 6, 0, 0]} maxBarSize={40} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </Card>
  )
}
