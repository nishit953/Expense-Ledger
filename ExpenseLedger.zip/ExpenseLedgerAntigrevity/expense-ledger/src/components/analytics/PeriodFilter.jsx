import { useState } from 'react'
import { Calendar } from 'lucide-react'
import Input from '../ui/Input'
import Button from '../ui/Button'
import { ANALYTICS_PERIODS } from '../../services/analyticsService'
import { classNames } from '../../utils/format'

export default function PeriodFilter({ period, onPeriodChange, customRange, onCustomRangeChange }) {
  const [showCustom, setShowCustom] = useState(period === 'custom')

  const handleSelect = (value) => {
    onPeriodChange(value)
    setShowCustom(value === 'custom')
  }

  return (
    <div className="mb-6">
      <div className="flex flex-wrap gap-2">
        {ANALYTICS_PERIODS.map((p) => (
          <button
            key={p.value}
            onClick={() => handleSelect(p.value)}
            className={classNames(
              'px-3.5 py-2 rounded-lg text-sm font-medium transition-colors',
              period === p.value
                ? 'bg-emerald-600 text-white'
                : 'bg-white dark:bg-night-card border border-paper-line dark:border-night-line text-ink900/60 dark:text-night-muted hover:border-emerald-600'
            )}
          >
            {p.label}
          </button>
        ))}
      </div>

      {showCustom && (
        <div className="flex flex-col sm:flex-row items-end gap-3 mt-4 p-4 rounded-xl border border-paper-line dark:border-night-line bg-white dark:bg-night-card">
          <Input
            label="From"
            type="date"
            value={customRange.date_from}
            onChange={(e) => onCustomRangeChange({ ...customRange, date_from: e.target.value })}
          />
          <Input
            label="To"
            type="date"
            value={customRange.date_to}
            onChange={(e) => onCustomRangeChange({ ...customRange, date_to: e.target.value })}
          />
          <Button variant="outline" className="sm:mb-0.5">
            <Calendar size={15} /> Apply
          </Button>
        </div>
      )}
    </div>
  )
}
