import { AreaChart, Area, ResponsiveContainer, Tooltip, XAxis } from 'recharts'
import { Card } from '../ui/Card'
import { formatCurrency } from '../../utils/format'

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-white dark:bg-night-card border border-paper-line dark:border-night-line rounded-lg shadow-card px-3.5 py-2.5 text-xs">
      <p className="font-medium text-ink900 dark:text-night-text mb-1">{label}</p>
      {payload.map((p) => (
        <p key={p.dataKey} className="num text-ink900/60 dark:text-night-muted capitalize">
          {p.dataKey}: {formatCurrency(p.value)}
        </p>
      ))}
    </div>
  )
}

export default function IncomeExpenseTrendChart({ data, loading, title = 'Income vs. expense trend' }) {
  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-5">
        <p className="text-sm font-medium text-ink900/70 dark:text-night-text/70">{title}</p>
        <div className="flex gap-4 text-xs">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Income
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-ink-500" /> Expense
          </span>
        </div>
      </div>
      <div className="h-64">
        {loading ? (
          <div className="w-full h-full bg-paper-line/50 dark:bg-night-line/50 rounded-lg animate-pulse" />
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data}>
              <defs>
                <linearGradient id="incomeFillA" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#10B981" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="#10B981" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="expenseFillA" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#3B67F5" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="#3B67F5" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#8FA39B' }} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="income" stroke="#10B981" strokeWidth={2} fill="url(#incomeFillA)" />
              <Area type="monotone" dataKey="expense" stroke="#3B67F5" strokeWidth={2} fill="url(#expenseFillA)" />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </div>
    </Card>
  )
}
