import { TrendingUp, Receipt, PiggyBank, Tag, Activity } from 'lucide-react'
import { Card } from '../ui/Card'
import { SkeletonCard } from '../ui/Skeleton'
import { formatCurrency, formatPercent } from '../../utils/format'

export default function StatisticsGrid({ statistics, loading }) {
  if (loading) {
    return (
      <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
        {[0, 1, 2, 3, 4].map((i) => <SkeletonCard key={i} />)}
      </div>
    )
  }

  if (!statistics) return null

  const items = [
    { label: 'Avg. monthly expense', value: formatCurrency(statistics.average_monthly_expense), icon: Receipt },
    { label: 'Highest category', value: statistics.highest_expense_category, icon: Tag, isText: true },
    { label: 'Total transactions', value: statistics.total_transactions, icon: Activity, isText: true },
    { label: 'Total savings', value: formatCurrency(statistics.total_savings), icon: PiggyBank },
    {
      label: 'Growth vs. last period',
      value: formatPercent(statistics.monthly_growth),
      icon: TrendingUp,
      positive: statistics.monthly_growth >= 0,
    },
  ]

  return (
    <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
      {items.map((item) => (
        <Card key={item.label} className="p-5">
          <div className="flex items-center gap-2 mb-2">
            <item.icon size={15} className="text-ink900/40 dark:text-night-muted" />
            <p className="text-xs text-ink900/45 dark:text-night-muted">{item.label}</p>
          </div>
          <p
            className={`num text-lg font-semibold ${
              item.positive === undefined
                ? 'text-ink900 dark:text-night-text'
                : item.positive
                ? 'text-emerald-600'
                : 'text-red-500'
            } ${item.isText ? 'font-display truncate' : ''}`}
          >
            {item.value}
          </p>
        </Card>
      ))}
    </div>
  )
}
