import Input from '../ui/Input'
import { Select } from '../ui/Badge'
import { REPORT_TYPES } from '../../services/reportService'

const months = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
]

export default function ReportFilters({ params, onChange }) {
  const update = (patch) => onChange({ ...params, ...patch })
  const currentYear = new Date().getFullYear()
  const years = Array.from({ length: 6 }, (_, i) => currentYear - i)

  return (
    <div className="flex flex-wrap items-end gap-3 mb-6">
      <Select
        label="Report type"
        value={params.type}
        onChange={(e) => update({ type: e.target.value })}
        options={REPORT_TYPES}
        className="min-w-[160px]"
      />

      {params.type === 'monthly' && (
        <>
          <Select
            label="Month"
            value={params.month}
            onChange={(e) => update({ month: Number(e.target.value) })}
            options={months.map((m, i) => ({ value: i + 1, label: m }))}
            className="min-w-[150px]"
          />
          <Select
            label="Year"
            value={params.year}
            onChange={(e) => update({ year: Number(e.target.value) })}
            options={years.map((y) => ({ value: y, label: String(y) }))}
            className="min-w-[110px]"
          />
        </>
      )}

      {params.type === 'yearly' && (
        <Select
          label="Year"
          value={params.year}
          onChange={(e) => update({ year: Number(e.target.value) })}
          options={years.map((y) => ({ value: y, label: String(y) }))}
          className="min-w-[110px]"
        />
      )}

      {params.type === 'custom' && (
        <>
          <Input label="From" type="date" value={params.date_from} onChange={(e) => update({ date_from: e.target.value })} />
          <Input label="To" type="date" value={params.date_to} onChange={(e) => update({ date_to: e.target.value })} />
        </>
      )}
    </div>
  )
}
