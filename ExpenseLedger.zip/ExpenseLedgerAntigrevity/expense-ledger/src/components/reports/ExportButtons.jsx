import { useState } from 'react'
import { FileDown, FileSpreadsheet } from 'lucide-react'
import toast from 'react-hot-toast'
import Button from '../ui/Button'
import * as reportService from '../../services/reportService'
import { extractErrorMessage } from '../../services/api'

export default function ExportButtons({ exportParams }) {
  const [exportingPdf, setExportingPdf] = useState(false)
  const [exportingExcel, setExportingExcel] = useState(false)

  const handlePDF = async () => {
    setExportingPdf(true)
    try {
      await reportService.exportReportPDF(exportParams)
      toast.success('PDF downloaded')
    } catch (err) {
      toast.error(extractErrorMessage(err))
    } finally {
      setExportingPdf(false)
    }
  }

  const handleExcel = async () => {
    setExportingExcel(true)
    try {
      await reportService.exportReportExcel(exportParams)
      toast.success('Excel file downloaded')
    } catch (err) {
      toast.error(extractErrorMessage(err))
    } finally {
      setExportingExcel(false)
    }
  }

  return (
    <div className="flex gap-2">
      <Button variant="outline" onClick={handlePDF} loading={exportingPdf}>
        <FileDown size={15} /> Export PDF
      </Button>
      <Button variant="outline" onClick={handleExcel} loading={exportingExcel}>
        <FileSpreadsheet size={15} /> Export Excel
      </Button>
    </div>
  )
}
