import { CheckCircle2, AlertTriangle, Info, Bell as BellIcon, X } from 'lucide-react'
import { NOTIFICATION_TYPE_STYLES } from '../../services/notificationService'

const typeIcons = {
  success: CheckCircle2,
  warning: AlertTriangle,
  info: Info,
  reminder: BellIcon,
}

function timeAgo(dateStr) {
  const diffMs = Date.now() - new Date(dateStr).getTime()
  const mins = Math.floor(diffMs / 60000)
  if (mins < 1) return 'Just now'
  if (mins < 60) return `${mins}m ago`
  const hours = Math.floor(mins / 60)
  if (hours < 24) return `${hours}h ago`
  return `${Math.floor(hours / 24)}d ago`
}

export default function NotificationItem({ notification, onMarkRead, onDelete }) {
  const Icon = typeIcons[notification.type] || Info
  const style = NOTIFICATION_TYPE_STYLES[notification.type] || NOTIFICATION_TYPE_STYLES.info

  return (
    <div
      className={`flex gap-3 px-4 py-3.5 transition-colors ${!notification.is_read ? 'bg-emerald-50/40 dark:bg-emerald-900/10' : ''} hover:bg-black/[0.02] dark:hover:bg-white/[0.02]`}
      onClick={() => !notification.is_read && onMarkRead(notification.id)}
    >
      <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${style.bg}`}>
        <Icon size={15} className={style.color} />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-ink900 dark:text-night-text">{notification.title}</p>
        <p className="text-xs text-ink900/55 dark:text-night-muted mt-0.5 leading-relaxed">{notification.message}</p>
        <p className="text-[11px] text-ink900/35 dark:text-night-muted/70 mt-1">{timeAgo(notification.created_at)}</p>
      </div>
      <button
        onClick={(e) => { e.stopPropagation(); onDelete(notification.id) }}
        className="p-1 text-ink900/25 dark:text-night-muted/50 hover:text-red-500 transition-colors flex-shrink-0 h-fit"
        aria-label="Dismiss"
      >
        <X size={14} />
      </button>
    </div>
  )
}
