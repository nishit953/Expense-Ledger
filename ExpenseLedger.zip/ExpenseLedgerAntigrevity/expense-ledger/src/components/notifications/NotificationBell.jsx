import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Bell, CheckCheck, Inbox } from 'lucide-react'
import NotificationItem from './NotificationItem'
import EmptyState from '../ui/EmptyState'
import { SkeletonTable } from '../ui/Skeleton'
import useNotifications from '../../hooks/useNotifications'

export default function NotificationBell() {
  const [open, setOpen] = useState(false)
  const ref = useRef(null)
  const { notifications, unreadCount, loading, markRead, markAllRead, remove } = useNotifications()

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((o) => !o)}
        className="relative p-2 rounded-lg text-ink900/70 dark:text-night-text/70 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
        aria-label="Notifications"
      >
        <Bell size={19} />
        {unreadCount > 0 && (
          <span className="absolute top-1 right-1 min-w-[16px] h-4 px-1 rounded-full bg-red-500 text-white text-[10px] font-semibold flex items-center justify-center">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.97 }}
            transition={{ duration: 0.15 }}
            className="absolute right-0 mt-2 w-80 sm:w-96 bg-white dark:bg-night-card border border-paper-line dark:border-night-line rounded-2xl shadow-card overflow-hidden z-50"
          >
            <div className="flex items-center justify-between px-4 py-3.5 border-b border-paper-line dark:border-night-line">
              <p className="font-display font-semibold text-sm text-ink900 dark:text-night-text">Notifications</p>
              {unreadCount > 0 && (
                <button
                  onClick={markAllRead}
                  className="flex items-center gap-1 text-xs text-emerald-700 dark:text-emerald-400 font-medium hover:underline"
                >
                  <CheckCheck size={13} /> Mark all read
                </button>
              )}
            </div>

            <div className="max-h-96 overflow-y-auto divide-y divide-paper-line dark:divide-night-line">
              {loading ? (
                <div className="p-4">
                  <SkeletonTable rows={3} />
                </div>
              ) : notifications.length === 0 ? (
                <EmptyState icon={Inbox} title="You're all caught up" description="New alerts and reminders will show up here." />
              ) : (
                notifications.map((n) => (
                  <NotificationItem key={n.id} notification={n} onMarkRead={markRead} onDelete={remove} />
                ))
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
