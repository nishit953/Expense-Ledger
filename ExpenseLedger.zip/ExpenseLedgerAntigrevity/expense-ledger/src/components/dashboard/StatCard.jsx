import { motion } from 'framer-motion'
import { formatCurrency } from '../../utils/format'
import { SkeletonCard } from '../ui/Skeleton'

const variants = {
  emerald: 'from-emerald-500 to-emerald-700',
  ink: 'from-ink-500 to-ink-700',
  violet: 'from-violet-500 to-violet-700',
  dark: 'from-ink900 to-ink900/80',
}

export default function StatCard({ label, value, icon: Icon, variant = 'emerald', loading, hint }) {
  if (loading) return <SkeletonCard />

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className={`relative overflow-hidden rounded-xl2 bg-gradient-to-br ${variants[variant]} p-6 text-white shadow-card`}
    >
      <div className="absolute -top-6 -right-6 w-24 h-24 rounded-full bg-white/10" />
      <div className="relative flex items-start justify-between">
        <div>
          <p className="text-xs font-medium text-white/70 uppercase tracking-wide">{label}</p>
          <p className="num text-2xl sm:text-3xl font-semibold mt-2">{formatCurrency(value)}</p>
          {hint && <p className="text-xs text-white/60 mt-1.5">{hint}</p>}
        </div>
        {Icon && (
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center flex-shrink-0">
            <Icon size={18} />
          </div>
        )}
      </div>
    </motion.div>
  )
}
