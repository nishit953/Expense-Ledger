import { CalendarClock } from 'lucide-react'
import { Card } from '../ui/Card'
import EmptyState from '../ui/EmptyState'
import { SkeletonTable } from '../ui/Skeleton'
import { formatCurrency } from '../../utils/format'

function daysUntil(dateStr) {
  const diff = Math.ceil((new Date(dateStr) - new Date().setHours(0, 0, 0, 0)) / 86400000)
  if (diff === 0) return 'Today'
  if (diff === 1) return 'Tomorrow'
  return `In ${diff} days`
}

export default function UpcomingBills({ bills, loading }) {
  return (
    <Card className="p-6">
      <p className="text-sm font-medium text-ink900/70 dark:text-night-text/70 mb-3">Upcoming bills</p>

      {loading ? (
        <SkeletonTable rows={3} />
      ) : !bills?.length ? (
        <EmptyState
          icon={CalendarClock}
          title="No upcoming bills"
          description="Recurring expenses due in the next 30 days will show up here."
        />
      ) : (
        <div className="divide-y divide-paper-line dark:divide-night-line">
          {bills.map((bill) => (
            <div key={`${bill.title}-${bill.due_date}`} className="flex items-center justify-between py-3">
              <div>
                <p className="text-sm font-medium text-ink900 dark:text-night-text">{bill.title}</p>
                <p className="text-xs text-ink900/45 dark:text-night-muted">
                  {bill.category_display} · {daysUntil(bill.due_date)}
                </p>
              </div>
              <p className="num text-sm font-semibold text-ink900 dark:text-night-text">{formatCurrency(bill.amount)}</p>
            </div>
          ))}
        </div>
      )}
    </Card>
  )
}
