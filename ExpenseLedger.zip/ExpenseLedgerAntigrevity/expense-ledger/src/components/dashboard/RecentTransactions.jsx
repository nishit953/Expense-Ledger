import { ArrowDownLeft, ArrowUpRight, Receipt } from 'lucide-react'
import { Card } from '../ui/Card'
import EmptyState from '../ui/EmptyState'
import { SkeletonTable } from '../ui/Skeleton'
import { formatCurrency } from '../../utils/format'

export default function RecentTransactions({ transactions, loading }) {
  return (
    <Card className="p-6">
      <p className="text-sm font-medium text-ink900/70 dark:text-night-text/70 mb-3">Recent transactions</p>

      {loading ? (
        <SkeletonTable rows={5} />
      ) : !transactions?.length ? (
        <EmptyState icon={Receipt} title="No transactions yet" description="Add an expense or income entry to see it here." />
      ) : (
        <div className="divide-y divide-paper-line dark:divide-night-line">
          {transactions.map((tx) => (
            <div key={`${tx.type}-${tx.id}`} className="flex items-center justify-between py-3.5">
              <div className="flex items-center gap-3">
                <div
                  className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 ${
                    tx.type === 'income'
                      ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600'
                      : 'bg-ink-50 dark:bg-ink-900/20 text-ink-600'
                  }`}
                >
                  {tx.type === 'income' ? <ArrowDownLeft size={15} /> : <ArrowUpRight size={15} />}
                </div>
                <div>
                  <p className="text-sm font-medium text-ink900 dark:text-night-text">{tx.title}</p>
                  <p className="text-xs text-ink900/45 dark:text-night-muted">
                    {tx.category_or_source} · {tx.date}
                  </p>
                </div>
              </div>
              <p
                className={`num text-sm font-semibold ${
                  tx.type === 'income' ? 'text-emerald-600' : 'text-ink900/75 dark:text-night-text/75'
                }`}
              >
                {tx.type === 'income' ? '+' : '-'}
                {formatCurrency(tx.amount)}
              </p>
            </div>
          ))}
        </div>
      )}
    </Card>
  )
}
