import { useEffect, useState } from 'react'
import { Sparkles, TrendingUp } from 'lucide-react'
import { Card } from '../ui/Card'
import { SkeletonCard } from '../ui/Skeleton'
import { formatCurrency } from '../../utils/format'
import { fetchExpenseForecast } from '../../services/mlService'

export default function ForecastCard() {
  const [forecast, setForecast] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchExpenseForecast()
      .then(setForecast)
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  if (loading) return <SkeletonCard />
  if (!forecast) return null

  return (
    <Card className="p-6 flex items-center gap-4">
      <div className="w-11 h-11 rounded-xl bg-violet-50 dark:bg-violet-900/20 flex items-center justify-center flex-shrink-0">
        <TrendingUp size={18} className="text-violet-600" />
      </div>
      <div>
        <p className="flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-ink900/45 dark:text-night-muted">
          <Sparkles size={12} /> Next month’s forecast
        </p>
        <p className="num text-xl font-semibold text-ink900 dark:text-night-text mt-0.5">
          {formatCurrency(forecast.prediction)}
        </p>
        <p className="text-xs text-ink900/40 dark:text-night-muted mt-0.5">
          {forecast.method === 'model'
            ? `Based on ${forecast.months_used} months of history`
            : 'Estimated from your recent average'}
        </p>
      </div>
    </Card>
  )
}
