import { motion } from 'framer-motion'
import { HeartPulse } from 'lucide-react'
import { Card } from '../ui/Card'
import { SkeletonCard } from '../ui/Skeleton'

const ratingColors = {
  Excellent: '#059669',
  Good: '#10B981',
  Fair: '#F59E0B',
  'Needs attention': '#EF4444',
}

export default function HealthScoreCard({ health, loading }) {
  if (loading) return <SkeletonCard />
  if (!health) return null

  const color = ratingColors[health.rating] || '#059669'
  const circumference = 2 * Math.PI * 36
  const offset = circumference - (health.score / 100) * circumference

  return (
    <Card className="p-6 flex items-center gap-5">
      <div className="relative w-20 h-20 flex-shrink-0">
        <svg viewBox="0 0 88 88" className="w-full h-full -rotate-90">
          <circle cx="44" cy="44" r="36" fill="none" stroke="currentColor" strokeWidth="8" className="text-paper-line dark:text-night-line" />
          <motion.circle
            cx="44" cy="44" r="36" fill="none" stroke={color} strokeWidth="8" strokeLinecap="round"
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset: offset }}
            transition={{ duration: 1, ease: 'easeOut' }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="num text-xl font-semibold text-ink900 dark:text-night-text">{health.score}</span>
        </div>
      </div>
      <div>
        <p className="flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-ink900/45 dark:text-night-muted">
          <HeartPulse size={13} /> Financial health
        </p>
        <p className="font-display font-semibold text-lg mt-0.5" style={{ color }}>
          {health.rating}
        </p>
        <p className="text-xs text-ink900/45 dark:text-night-muted mt-1">
          {health.savings_rate}% saved this month
        </p>
      </div>
    </Card>
  )
}
