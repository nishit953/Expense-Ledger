import { Card } from '../ui/Card'
import EmptyState from '../ui/EmptyState'
import { PieChart as PieChartIcon } from 'lucide-react'
import { formatCurrency } from '../../utils/format'

const palette = ['#059669', '#1D4ED8', '#7C3AED', '#F59E0B', '#EF4444', '#0891B2', '#EC4899', '#84CC16', '#F97316', '#64748B']

export default function BreakdownList({ title, items, labelKey, loading }) {
  if (loading) {
    return (
      <Card className="p-6">
        <p className="text-sm font-medium text-ink900/70 dark:text-night-text/70 mb-4">{title}</p>
        <div className="space-y-3">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-3 bg-paper-line dark:bg-night-line rounded-full animate-pulse" />
          ))}
        </div>
      </Card>
    )
  }

  if (!items?.length) {
    return (
      <Card className="p-6">
        <p className="text-sm font-medium text-ink900/70 dark:text-night-text/70 mb-2">{title}</p>
        <EmptyState icon={PieChartIcon} title="No data yet" description="Once you add entries, the breakdown will appear here." />
      </Card>
    )
  }

  return (
    <Card className="p-6">
      <p className="text-sm font-medium text-ink900/70 dark:text-night-text/70 mb-5">{title}</p>
      <div className="space-y-4">
        {items.map((item, i) => (
          <div key={item[labelKey]}>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-sm text-ink900 dark:text-night-text flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: palette[i % palette.length] }} />
                {item[`${labelKey}_display`]}
              </span>
              <span className="num text-sm font-medium text-ink900 dark:text-night-text">
                {formatCurrency(item.total)}
              </span>
            </div>
            <div className="h-1.5 rounded-full bg-paper-line dark:bg-night-line overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-700"
                style={{ width: `${item.percentage}%`, backgroundColor: palette[i % palette.length] }}
              />
            </div>
          </div>
        ))}
      </div>
    </Card>
  )
}
