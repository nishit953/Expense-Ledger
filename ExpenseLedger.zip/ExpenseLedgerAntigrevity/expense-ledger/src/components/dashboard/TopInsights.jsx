import { Link } from 'react-router-dom'
import { Sparkles, ArrowRight } from 'lucide-react'
import { Card } from '../ui/Card'
import EmptyState from '../ui/EmptyState'
import { SkeletonTable } from '../ui/Skeleton'
import { PRIORITY_STYLES } from '../../services/insightsService'
import useInsights from '../../hooks/useInsights'

export default function TopInsights() {
  const { insights, loading } = useInsights()
  const top = insights.slice(0, 3)

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-3">
        <p className="flex items-center gap-1.5 text-sm font-medium text-ink900/70 dark:text-night-text/70">
          <Sparkles size={15} /> AI Insights
        </p>
        <Link
          to="/app/insights"
          className="flex items-center gap-1 text-xs text-emerald-700 dark:text-emerald-400 font-medium hover:underline"
        >
          View all <ArrowRight size={12} />
        </Link>
      </div>

      {loading ? (
        <SkeletonTable rows={3} />
      ) : top.length === 0 ? (
        <EmptyState icon={Sparkles} title="No insights yet" description="Keep logging your finances and recommendations will appear here." />
      ) : (
        <div className="divide-y divide-paper-line dark:divide-night-line">
          {top.map((insight) => {
            const style = PRIORITY_STYLES[insight.priority] || PRIORITY_STYLES.info
            return (
              <div key={insight.id} className="py-3">
                <p className={`text-xs font-medium mb-0.5 ${style.color}`}>{insight.title}</p>
                <p className="text-xs text-ink900/55 dark:text-night-muted leading-relaxed line-clamp-2">
                  {insight.message}
                </p>
              </div>
            )
          })}
        </div>
      )}
    </Card>
  )
}
