import { useForm } from 'react-hook-form'
import Input from '../ui/Input'
import { Select } from '../ui/Badge'
import Button from '../ui/Button'
import { SAVINGS_SOURCES } from '../../services/savingsService'

export default function SavingsForm({ initialValues, onSubmit, onCancel, submitting }) {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    defaultValues: initialValues || {
      amount: '',
      date: new Date().toISOString().slice(0, 10),
      source: 'salary_savings',
      description: '',
      is_emergency_fund: false,
    },
  })

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
      <div className="grid sm:grid-cols-2 gap-4">
        <Select label="Source" options={SAVINGS_SOURCES} {...register('source', { required: true })} />
        <Input
          label="Amount (₹)"
          type="number"
          step="0.01"
          placeholder="0.00"
          {...register('amount', {
            required: 'Amount is required',
            min: { value: 0.01, message: 'Must be greater than 0' },
          })}
          error={errors.amount?.message}
        />
      </div>

      <Input label="Date" type="date" {...register('date', { required: 'Date is required' })} error={errors.date?.message} />

      <Input label="Description" placeholder="Optional description" {...register('description')} />

      <label className="flex items-center gap-2.5 text-sm text-ink900/70 dark:text-night-text/70 cursor-pointer select-none">
        <input type="checkbox" {...register('is_emergency_fund')} className="w-4 h-4 rounded accent-emerald-600" />
        Count toward emergency fund
      </label>

      <div className="flex gap-3 pt-2">
        <Button type="submit" loading={submitting} className="flex-1">
          {initialValues ? 'Save changes' : 'Add savings entry'}
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  )
}
