import { AreaChart, Area, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { Card } from '../ui/Card'
import { formatCurrency } from '../../utils/format'

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-white dark:bg-night-card border border-paper-line dark:border-night-line rounded-lg shadow-card px-3.5 py-2.5 text-xs">
      <p className="font-medium text-ink900 dark:text-night-text mb-1">{label}</p>
      <p className="num text-ink900/60 dark:text-night-muted">Balance: {formatCurrency(payload[0].value)}</p>
    </div>
  )
}

export default function SavingsGrowthChart({ data, loading }) {
  return (
    <Card className="p-6">
      <p className="text-sm font-medium text-ink900/70 dark:text-night-text/70 mb-5">Savings growth</p>
      <div className="h-64">
        {loading ? (
          <div className="w-full h-full bg-paper-line/50 dark:bg-night-line/50 rounded-lg animate-pulse" />
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data}>
              <defs>
                <linearGradient id="savingsFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#059669" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="#059669" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#8FA39B' }} />
              <YAxis hide />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="total_balance" stroke="#059669" strokeWidth={2} fill="url(#savingsFill)" />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </div>
    </Card>
  )
}
