import { Pencil, Trash2, ShieldCheck } from 'lucide-react'
import { CategoryBadge } from '../ui/Badge'
import { formatCurrency } from '../../utils/format'
import { SAVINGS_SOURCES } from '../../services/savingsService'

const sourceLabel = (v) => SAVINGS_SOURCES.find((s) => s.value === v)?.label || v

export default function SavingsTable({ entries, onEdit, onDelete }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left text-xs uppercase tracking-wide text-ink900/40 dark:text-night-muted border-b border-paper-line dark:border-night-line">
            <th className="py-3 font-medium">Source</th>
            <th className="py-3 font-medium">Description</th>
            <th className="py-3 font-medium">Date</th>
            <th className="py-3 font-medium text-right">Amount</th>
            <th className="py-3 font-medium text-right">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-paper-line dark:divide-night-line">
          {entries.map((e) => (
            <tr key={e.id} className="group">
              <td className="py-3.5 pr-4">
                <div className="flex items-center gap-2">
                  <CategoryBadge category={e.source} label={e.source_display || sourceLabel(e.source)} />
                  {e.is_emergency_fund && <ShieldCheck size={14} className="text-emerald-600" />}
                </div>
              </td>
              <td className="py-3.5 pr-4 text-ink900/60 dark:text-night-muted">{e.description || '—'}</td>
              <td className="num py-3.5 pr-4 text-ink900/60 dark:text-night-muted">{e.date}</td>
              <td className="num py-3.5 pr-4 text-right font-semibold text-emerald-600">+{formatCurrency(e.amount)}</td>
              <td className="py-3.5 text-right">
                <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => onEdit(e)} className="p-1.5 text-ink900/50 dark:text-night-muted hover:text-emerald-600">
                    <Pencil size={15} />
                  </button>
                  <button onClick={() => onDelete(e)} className="p-1.5 text-ink900/50 dark:text-night-muted hover:text-red-500">
                    <Trash2 size={15} />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
