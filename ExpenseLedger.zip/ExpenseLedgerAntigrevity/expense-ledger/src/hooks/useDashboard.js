import { useEffect, useState } from 'react'
import * as dashboardService from '../services/dashboardService'

export default function useDashboard() {
  const [summary, setSummary] = useState(null)
  const [categoryBreakdown, setCategoryBreakdown] = useState([])
  const [sourceBreakdown, setSourceBreakdown] = useState([])
  const [trend, setTrend] = useState([])
  const [recentTransactions, setRecentTransactions] = useState([])
  const [netWorth, setNetWorth] = useState(null)
  const [healthScore, setHealthScore] = useState(null)
  const [upcomingBills, setUpcomingBills] = useState([])
  const [monthlyOverview, setMonthlyOverview] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    let cancelled = false

    const load = async () => {
      setLoading(true)
      setError(null)
      try {
        const [
          summaryData, categoryData, sourceData, trendData, recentData,
          netWorthData, healthData, billsData, overviewData,
        ] = await Promise.all([
          dashboardService.fetchSummary(),
          dashboardService.fetchExpenseByCategory(),
          dashboardService.fetchIncomeBySource(),
          dashboardService.fetchMonthlyTrend(6),
          dashboardService.fetchRecentTransactions(8),
          dashboardService.fetchNetWorth(),
          dashboardService.fetchFinancialHealth(),
          dashboardService.fetchUpcomingBills(30),
          dashboardService.fetchMonthlyOverview(),
        ])
        if (cancelled) return
        setSummary(summaryData)
        setCategoryBreakdown(categoryData)
        setSourceBreakdown(sourceData)
        setTrend(trendData)
        setRecentTransactions(recentData)
        setNetWorth(netWorthData)
        setHealthScore(healthData)
        setUpcomingBills(billsData)
        setMonthlyOverview(overviewData)
      } catch (err) {
        if (!cancelled) setError(err)
      } finally {
        if (!cancelled) setLoading(false)
      }
    }

    load()
    return () => {
      cancelled = true
    }
  }, [])

  return {
    summary, categoryBreakdown, sourceBreakdown, trend, recentTransactions,
    netWorth, healthScore, upcomingBills, monthlyOverview, loading, error,
  }
}
