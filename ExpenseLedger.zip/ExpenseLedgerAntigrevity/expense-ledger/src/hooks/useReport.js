import { useEffect, useState } from 'react'
import * as reportService from '../services/reportService'

export default function useReport(params) {
  const [report, setReport] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    let cancelled = false

    const load = async () => {
      setLoading(true)
      setError(null)
      try {
        let data
        if (params.type === 'yearly') {
          data = await reportService.fetchYearlyReport(params.year)
        } else if (params.type === 'custom') {
          if (!params.date_from || !params.date_to) {
            setLoading(false)
            return
          }
          data = await reportService.fetchReport({ date_from: params.date_from, date_to: params.date_to })
        } else {
          data = await reportService.fetchMonthlyReport(params.year, params.month)
        }
        if (!cancelled) setReport(data)
      } catch (err) {
        if (!cancelled) setError(err)
      } finally {
        if (!cancelled) setLoading(false)
      }
    }

    load()
    return () => {
      cancelled = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.type, params.year, params.month, params.date_from, params.date_to])

  return { report, loading, error }
}
