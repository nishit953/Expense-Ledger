import { useCallback, useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import * as notificationService from '../services/notificationService'
import { extractErrorMessage } from '../services/api'

export default function useNotifications() {
  const [notifications, setNotifications] = useState([])
  const [unreadCount, setUnreadCount] = useState(0)
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const [list, count] = await Promise.all([
        notificationService.fetchNotifications({ page_size: 20 }),
        notificationService.fetchUnreadCount(),
      ])
      setNotifications(list.results || list)
      setUnreadCount(count)
    } catch {
      // Silent — the bell icon just won't update; not worth a toast for a background fetch.
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
    // Also try to generate any new rule-based notifications on mount.
    notificationService.generateNotifications().then(load).catch(() => {})
  }, [load])

  const markRead = async (id) => {
    try {
      await notificationService.markAsRead(id)
      setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, is_read: true } : n)))
      setUnreadCount((c) => Math.max(0, c - 1))
    } catch (err) {
      toast.error(extractErrorMessage(err))
    }
  }

  const markAllRead = async () => {
    try {
      await notificationService.markAllAsRead()
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })))
      setUnreadCount(0)
    } catch (err) {
      toast.error(extractErrorMessage(err))
    }
  }

  const remove = async (id) => {
    try {
      await notificationService.deleteNotification(id)
      setNotifications((prev) => prev.filter((n) => n.id !== id))
    } catch (err) {
      toast.error(extractErrorMessage(err))
    }
  }

  return { notifications, unreadCount, loading, markRead, markAllRead, remove, refresh: load }
}
