import { useCallback, useEffect, useState } from 'react'
import * as insightsService from '../services/insightsService'

export default function useInsights(category = null) {
  const [insights, setInsights] = useState([])
  const [countsByCategory, setCountsByCategory] = useState({})
  const [countsByPriority, setCountsByPriority] = useState({})
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const data = await insightsService.fetchInsights(category)
      setInsights(data.insights)
      setCountsByCategory(data.counts_by_category)
      setCountsByPriority(data.counts_by_priority)
    } catch (err) {
      setError(err)
    } finally {
      setLoading(false)
    }
  }, [category])

  useEffect(() => {
    load()
  }, [load])

  return { insights, countsByCategory, countsByPriority, loading, error, refresh: load }
}
