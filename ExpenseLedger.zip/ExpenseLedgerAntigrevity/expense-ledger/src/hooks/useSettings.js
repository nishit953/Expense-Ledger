import { useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import * as settingsService from '../services/settingsService'
import { extractErrorMessage } from '../services/api'

export default function useSettings() {
  const [settings, setSettings] = useState(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  const load = async () => {
    setLoading(true)
    try {
      const data = await settingsService.fetchSettings()
      setSettings(data)
    } catch (err) {
      toast.error(extractErrorMessage(err))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [])

  const update = async (patch) => {
    setSaving(true)
    try {
      const data = await settingsService.updateSettings(patch)
      setSettings(data)
      toast.success('Settings saved')
      return true
    } catch (err) {
      toast.error(extractErrorMessage(err))
      return false
    } finally {
      setSaving(false)
    }
  }

  return { settings, loading, saving, update, refresh: load }
}
