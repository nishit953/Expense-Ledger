import { useCallback, useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import * as savingsService from '../services/savingsService'
import { extractErrorMessage } from '../services/api'

const PAGE_SIZE = 10

export default function useSavings(queryParams) {
  const [data, setData] = useState({ results: [], count: 0 })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const response = await savingsService.fetchSavingsEntries(queryParams)
      setData(response)
    } catch (err) {
      setError(extractErrorMessage(err))
    } finally {
      setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify(queryParams)])

  useEffect(() => {
    load()
  }, [load])

  const create = async (payload) => {
    try {
      await savingsService.createSavingsEntry(payload)
      toast.success('Savings entry added')
      await load()
      return true
    } catch (err) {
      toast.error(extractErrorMessage(err))
      return false
    }
  }

  const update = async (id, payload) => {
    try {
      await savingsService.updateSavingsEntry(id, payload)
      toast.success('Savings entry updated')
      await load()
      return true
    } catch (err) {
      toast.error(extractErrorMessage(err))
      return false
    }
  }

  const remove = async (id) => {
    try {
      await savingsService.deleteSavingsEntry(id)
      toast.success('Savings entry deleted')
      await load()
      return true
    } catch (err) {
      toast.error(extractErrorMessage(err))
      return false
    }
  }

  const pageCount = Math.max(1, Math.ceil((data.count || 0) / PAGE_SIZE))

  return { entries: data.results, totalCount: data.count, pageCount, loading, error, create, update, remove, refresh: load }
}
