import { useCallback, useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import * as goalService from '../services/goalService'
import { extractErrorMessage } from '../services/api'

const PAGE_SIZE = 10

export default function useGoals(queryParams) {
  const [data, setData] = useState({ results: [], count: 0 })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const response = await goalService.fetchGoals(queryParams)
      setData(response)
    } catch (err) {
      setError(extractErrorMessage(err))
    } finally {
      setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify(queryParams)])

  useEffect(() => {
    load()
  }, [load])

  const create = async (payload) => {
    try {
      await goalService.createGoal(payload)
      toast.success('Goal created')
      await load()
      return true
    } catch (err) {
      toast.error(extractErrorMessage(err))
      return false
    }
  }

  const update = async (id, payload) => {
    try {
      await goalService.updateGoal(id, payload)
      toast.success('Goal updated')
      await load()
      return true
    } catch (err) {
      toast.error(extractErrorMessage(err))
      return false
    }
  }

  const remove = async (id) => {
    try {
      await goalService.deleteGoal(id)
      toast.success('Goal deleted')
      await load()
      return true
    } catch (err) {
      toast.error(extractErrorMessage(err))
      return false
    }
  }

  const contribute = async (id, payload) => {
    try {
      const result = await goalService.contributeToGoal(id, payload)
      if (result.data?.status === 'completed') {
        toast.success('🎉 Goal reached!')
      } else {
        toast.success('Contribution added')
      }
      await load()
      return true
    } catch (err) {
      toast.error(extractErrorMessage(err))
      return false
    }
  }

  const abandon = async (id) => {
    try {
      await goalService.abandonGoal(id)
      toast.success('Goal marked as abandoned')
      await load()
      return true
    } catch (err) {
      toast.error(extractErrorMessage(err))
      return false
    }
  }

  const reactivate = async (id) => {
    try {
      await goalService.reactivateGoal(id)
      toast.success('Goal reactivated')
      await load()
      return true
    } catch (err) {
      toast.error(extractErrorMessage(err))
      return false
    }
  }

  const pageCount = Math.max(1, Math.ceil((data.count || 0) / PAGE_SIZE))

  return {
    goals: data.results, totalCount: data.count, pageCount, loading, error,
    create, update, remove, contribute, abandon, reactivate, refresh: load,
  }
}
