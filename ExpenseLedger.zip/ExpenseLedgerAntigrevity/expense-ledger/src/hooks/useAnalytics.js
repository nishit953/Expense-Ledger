import { useCallback, useEffect, useState } from 'react'
import * as analyticsService from '../services/analyticsService'

export default function useAnalytics(period, customRange) {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const params = { period }
      if (period === 'custom' && customRange?.date_from && customRange?.date_to) {
        params.date_from = customRange.date_from
        params.date_to = customRange.date_to
      }
      const result = await analyticsService.fetchAnalytics(params)
      setData(result)
    } catch (err) {
      setError(err)
    } finally {
      setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [period, customRange?.date_from, customRange?.date_to])

  useEffect(() => {
    // Custom range needs both dates before it's worth fetching.
    if (period === 'custom' && (!customRange?.date_from || !customRange?.date_to)) return
    load()
  }, [load, period, customRange])

  return { data, loading, error, refresh: load }
}
