import api from './api'

export async function fetchBudgets(params = {}) {
  const { data } = await api.get('/budgets/', { params })
  return data
}

export async function createBudget(payload) {
  const { data } = await api.post('/budgets/', payload)
  return data
}

export async function updateBudget(id, payload) {
  const { data } = await api.patch(`/budgets/${id}/`, payload)
  return data
}

export async function deleteBudget(id) {
  await api.delete(`/budgets/${id}/`)
}

export const BUDGET_CATEGORIES = [
  { value: 'food', label: 'Food' },
  { value: 'transport', label: 'Transport' },
  { value: 'shopping', label: 'Shopping' },
  { value: 'medical', label: 'Medical' },
  { value: 'bills', label: 'Bills' },
  { value: 'education', label: 'Education' },
  { value: 'entertainment', label: 'Entertainment' },
  { value: 'investment', label: 'Investment' },
  { value: 'rent', label: 'Rent' },
  { value: 'others', label: 'Others' },
]

export const BUDGET_STATUS_LABELS = {
  on_track: 'On track',
  warning: 'Near limit',
  exceeded: 'Exceeded',
}
