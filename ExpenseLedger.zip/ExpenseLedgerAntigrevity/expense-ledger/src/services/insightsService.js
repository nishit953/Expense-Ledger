import api from './api'

export async function fetchInsights(category = null) {
  const params = category ? { category } : {}
  const { data } = await api.get('/insights/', { params })
  return data.data // { insights, counts_by_category, counts_by_priority }
}

export const INSIGHT_CATEGORIES = [
  { value: 'overspending', label: 'Overspending' },
  { value: 'budget', label: 'Budget' },
  { value: 'savings', label: 'Savings' },
  { value: 'goal', label: 'Goals' },
  { value: 'monthly_summary', label: 'Monthly Summary' },
  { value: 'health', label: 'Financial Health' },
]

export const PRIORITY_STYLES = {
  high: { color: 'text-red-600 dark:text-red-400', bg: 'bg-red-50 dark:bg-red-900/20', label: 'High priority' },
  medium: { color: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-50 dark:bg-amber-900/20', label: 'Medium priority' },
  low: { color: 'text-ink-600 dark:text-ink-400', bg: 'bg-ink-50 dark:bg-ink-900/20', label: 'Low priority' },
  info: { color: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-50 dark:bg-emerald-900/20', label: 'Info' },
}
