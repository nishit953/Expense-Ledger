import api from './api'

export async function fetchSavingsEntries(params = {}) {
  const { data } = await api.get('/savings/', { params })
  return data
}

export async function fetchSavingsStats() {
  const { data } = await api.get('/savings/stats/')
  return data.data
}

export async function createSavingsEntry(payload) {
  const { data } = await api.post('/savings/', payload)
  return data
}

export async function updateSavingsEntry(id, payload) {
  const { data } = await api.patch(`/savings/${id}/`, payload)
  return data
}

export async function deleteSavingsEntry(id) {
  await api.delete(`/savings/${id}/`)
}

export const SAVINGS_SOURCES = [
  { value: 'salary_savings', label: 'Salary Savings' },
  { value: 'investment_return', label: 'Investment Return' },
  { value: 'bonus', label: 'Bonus' },
  { value: 'gift', label: 'Gift' },
  { value: 'interest', label: 'Interest' },
  { value: 'other', label: 'Other' },
]
