import api, { clearTokens, getRefreshToken, saveTokens } from './api'

export async function registerUser(payload) {
  const { data } = await api.post('/auth/register/', payload)
  return data
}

export async function loginUser({ email, password, rememberMe }) {
  const { data } = await api.post('/auth/login/', { email, password, remember_me: rememberMe })
  saveTokens(data.data, rememberMe)
  return data.data.user
}

export async function logoutUser() {
  const refresh = getRefreshToken()
  try {
    if (refresh) await api.post('/auth/logout/', { refresh })
  } finally {
    clearTokens()
  }
}

export async function fetchProfile() {
  const { data } = await api.get('/auth/profile/')
  return data
}

export async function fetchProfileSummary() {
  const { data } = await api.get('/auth/profile/summary/')
  return data.data
}

export async function updateProfile(payload) {
  const formData = new FormData()
  Object.entries(payload).forEach(([key, value]) => {
    if (value !== undefined && value !== null) formData.append(key, value)
  })
  const { data } = await api.patch('/auth/profile/', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
  return data.data
}

export async function changePassword(payload) {
  const { data } = await api.post('/auth/change-password/', payload)
  return data
}

export async function forgotPassword(email) {
  const { data } = await api.post('/auth/forgot-password/', { email })
  return data
}

export async function resetPassword(payload) {
  const { data } = await api.post('/auth/reset-password/', payload)
  return data
}

export async function verifyEmail(payload) {
  const { data } = await api.post('/auth/verify-email/', payload)
  return data
}

export async function resendOTP(email, purpose) {
  const { data } = await api.post('/auth/resend-otp/', { email, purpose })
  return data
}
