import api from './api'

export async function fetchExpenses(params = {}) {
  const { data } = await api.get('/expenses/', { params })
  return data // { count, next, previous, results }
}

export async function fetchExpense(id) {
  const { data } = await api.get(`/expenses/${id}/`)
  return data
}

export async function createExpense(payload) {
  const formData = buildExpenseFormData(payload)
  const { data } = await api.post('/expenses/', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
  return data
}

export async function updateExpense(id, payload) {
  const formData = buildExpenseFormData(payload)
  const { data } = await api.patch(`/expenses/${id}/`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
  return data
}

export async function deleteExpense(id) {
  await api.delete(`/expenses/${id}/`)
}

function buildExpenseFormData(payload) {
  const formData = new FormData()
  Object.entries(payload).forEach(([key, value]) => {
    if (value === undefined || value === null || value === '') return
    if (key === 'receipt' && !(value instanceof File)) return // skip unchanged receipt
    formData.append(key, value)
  })
  return formData
}

export const EXPENSE_CATEGORIES = [
  { value: 'food', label: 'Food' },
  { value: 'transport', label: 'Transport' },
  { value: 'shopping', label: 'Shopping' },
  { value: 'medical', label: 'Medical' },
  { value: 'bills', label: 'Bills' },
  { value: 'education', label: 'Education' },
  { value: 'entertainment', label: 'Entertainment' },
  { value: 'investment', label: 'Investment' },
  { value: 'rent', label: 'Rent' },
  { value: 'others', label: 'Others' },
]

export const PAYMENT_METHODS = [
  { value: 'cash', label: 'Cash' },
  { value: 'debit_card', label: 'Debit Card' },
  { value: 'credit_card', label: 'Credit Card' },
  { value: 'upi', label: 'UPI' },
  { value: 'net_banking', label: 'Net Banking' },
  { value: 'wallet', label: 'Wallet' },
  { value: 'other', label: 'Other' },
]

export const RECURRING_FREQUENCIES = [
  { value: 'daily', label: 'Daily' },
  { value: 'weekly', label: 'Weekly' },
  { value: 'monthly', label: 'Monthly' },
  { value: 'yearly', label: 'Yearly' },
]
