import api from './api'

export async function fetchGoals(params = {}) {
  const { data } = await api.get('/goals/', { params })
  return data
}

export async function fetchGoal(id) {
  const { data } = await api.get(`/goals/${id}/`)
  return data
}

export async function fetchGoalsSummary() {
  const { data } = await api.get('/goals/summary/')
  return data.data
}

export async function createGoal(payload) {
  const { data } = await api.post('/goals/', payload)
  return data
}

export async function updateGoal(id, payload) {
  const { data } = await api.patch(`/goals/${id}/`, payload)
  return data
}

export async function deleteGoal(id) {
  await api.delete(`/goals/${id}/`)
}

export async function contributeToGoal(id, payload) {
  const { data } = await api.post(`/goals/${id}/contribute/`, payload)
  return data
}

export async function abandonGoal(id) {
  const { data } = await api.post(`/goals/${id}/abandon/`)
  return data
}

export async function reactivateGoal(id) {
  const { data } = await api.post(`/goals/${id}/reactivate/`)
  return data
}

export const GOAL_CATEGORIES = [
  { value: 'emergency_fund', label: 'Emergency Fund' },
  { value: 'buy_car', label: 'Buy a Car' },
  { value: 'buy_house', label: 'Buy a House' },
  { value: 'vacation', label: 'Vacation' },
  { value: 'education', label: 'Education' },
  { value: 'wedding', label: 'Wedding' },
  { value: 'business', label: 'Business' },
  { value: 'custom', label: 'Custom Goal' },
]

export const GOAL_PRIORITIES = [
  { value: 'low', label: 'Low' },
  { value: 'medium', label: 'Medium' },
  { value: 'high', label: 'High' },
]

export const GOAL_STATUS_LABELS = {
  active: 'Active',
  completed: 'Completed',
  abandoned: 'Abandoned',
  overdue: 'Overdue',
}
