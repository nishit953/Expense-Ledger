import api from './api'

export async function fetchReport(params = {}) {
  const { data } = await api.get('/reports/', { params })
  return data.data
}

export async function fetchMonthlyReport(year, month) {
  const { data } = await api.get('/reports/monthly/', { params: { year, month } })
  return data.data
}

export async function fetchYearlyReport(year) {
  const { data } = await api.get('/reports/yearly/', { params: { year } })
  return data.data
}

export async function fetchReportHistory(params = {}) {
  const { data } = await api.get('/reports/history/', { params })
  return data
}

async function downloadFile(url, params, fallbackFilename) {
  const response = await api.get(url, { params, responseType: 'blob' })

  const disposition = response.headers['content-disposition']
  const match = disposition && disposition.match(/filename="?([^"]+)"?/)
  const filename = match ? match[1] : fallbackFilename

  const blobUrl = window.URL.createObjectURL(new Blob([response.data]))
  const link = document.createElement('a')
  link.href = blobUrl
  link.setAttribute('download', filename)
  document.body.appendChild(link)
  link.click()
  link.remove()
  window.URL.revokeObjectURL(blobUrl)
}

export async function exportReportPDF(params = {}) {
  return downloadFile('/reports/export/pdf/', params, 'expenseledger-report.pdf')
}

export async function exportReportExcel(params = {}) {
  return downloadFile('/reports/export/excel/', params, 'expenseledger-report.xlsx')
}

export const REPORT_TYPES = [
  { value: 'monthly', label: 'Monthly' },
  { value: 'yearly', label: 'Yearly' },
  { value: 'custom', label: 'Custom Range' },
]
