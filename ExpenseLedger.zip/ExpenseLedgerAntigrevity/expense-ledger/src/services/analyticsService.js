import api from './api'

export async function fetchAnalytics(params = {}) {
  const { data } = await api.get('/analytics/', { params })
  return data.data
}

export const ANALYTICS_PERIODS = [
  { value: 'today', label: 'Today' },
  { value: 'this_week', label: 'This Week' },
  { value: 'this_month', label: 'This Month' },
  { value: 'last_month', label: 'Last Month' },
  { value: 'last_6_months', label: 'Last 6 Months' },
  { value: 'this_year', label: 'This Year' },
  { value: 'custom', label: 'Custom Range' },
]
