import axios from 'axios'

export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000/api'

// Access/refresh tokens live in sessionStorage by default; "remember me"
// promotes them to localStorage so they survive a browser restart.
const ACCESS_KEY = 'el_access_token'
const REFRESH_KEY = 'el_refresh_token'

export function getStorage() {
  return localStorage.getItem(REFRESH_KEY) ? localStorage : sessionStorage
}

export function saveTokens({ access, refresh }, rememberMe) {
  const store = rememberMe ? localStorage : sessionStorage
  const other = rememberMe ? sessionStorage : localStorage
  other.removeItem(ACCESS_KEY)
  other.removeItem(REFRESH_KEY)
  store.setItem(ACCESS_KEY, access)
  if (refresh) store.setItem(REFRESH_KEY, refresh)
}

export function getAccessToken() {
  return localStorage.getItem(ACCESS_KEY) || sessionStorage.getItem(ACCESS_KEY)
}

export function getRefreshToken() {
  return localStorage.getItem(REFRESH_KEY) || sessionStorage.getItem(REFRESH_KEY)
}

export function clearTokens() {
  localStorage.removeItem(ACCESS_KEY)
  localStorage.removeItem(REFRESH_KEY)
  sessionStorage.removeItem(ACCESS_KEY)
  sessionStorage.removeItem(REFRESH_KEY)
}

const api = axios.create({ baseURL: API_BASE_URL })

api.interceptors.request.use((config) => {
  const token = getAccessToken()
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

let isRefreshing = false
let pendingQueue = []

function flushQueue(error, token = null) {
  pendingQueue.forEach(({ resolve, reject }) => (error ? reject(error) : resolve(token)))
  pendingQueue = []
}

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config
    const status = error.response?.status

    if (status === 401 && !originalRequest._retry && getRefreshToken()) {
      if (isRefreshing) {
        return new Promise((resolve, reject) => {
          pendingQueue.push({ resolve, reject })
        }).then((token) => {
          originalRequest.headers.Authorization = `Bearer ${token}`
          return api(originalRequest)
        })
      }

      originalRequest._retry = true
      isRefreshing = true

      try {
        const refresh = getRefreshToken()
        const { data } = await axios.post(`${API_BASE_URL}/auth/token/refresh/`, { refresh })
        const rememberMe = getStorage() === localStorage
        saveTokens({ access: data.access, refresh: data.refresh || refresh }, rememberMe)
        flushQueue(null, data.access)
        originalRequest.headers.Authorization = `Bearer ${data.access}`
        return api(originalRequest)
      } catch (refreshError) {
        flushQueue(refreshError, null)
        clearTokens()
        window.location.href = '/login'
        return Promise.reject(refreshError)
      } finally {
        isRefreshing = false
      }
    }

    return Promise.reject(error)
  }
)

/** Pulls a human-readable message out of the backend's { message, errors } envelope. */
export function extractErrorMessage(error) {
  return (
    error?.response?.data?.message ||
    error?.response?.data?.detail ||
    'Something went wrong. Please try again.'
  )
}

export default api
