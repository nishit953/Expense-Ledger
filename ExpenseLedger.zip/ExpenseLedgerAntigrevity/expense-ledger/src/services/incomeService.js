import api from './api'

export async function fetchIncomes(params = {}) {
  const { data } = await api.get('/income/', { params })
  return data
}

export async function createIncome(payload) {
  const { data } = await api.post('/income/', payload)
  return data
}

export async function updateIncome(id, payload) {
  const { data } = await api.patch(`/income/${id}/`, payload)
  return data
}

export async function deleteIncome(id) {
  await api.delete(`/income/${id}/`)
}

export const INCOME_SOURCES = [
  { value: 'salary', label: 'Salary' },
  { value: 'freelancing', label: 'Freelancing' },
  { value: 'business', label: 'Business' },
  { value: 'rental', label: 'Rental' },
  { value: 'interest', label: 'Interest' },
  { value: 'bonus', label: 'Bonus' },
  { value: 'other', label: 'Other' },
]
