import api from './api'

export async function fetchSummary() {
  const { data } = await api.get('/dashboard/summary/')
  return data.data
}

export async function fetchExpenseByCategory(params = {}) {
  const { data } = await api.get('/dashboard/expense-by-category/', { params })
  return data.data
}

export async function fetchIncomeBySource(params = {}) {
  const { data } = await api.get('/dashboard/income-by-source/', { params })
  return data.data
}

export async function fetchMonthlyTrend(months = 6) {
  const { data } = await api.get('/dashboard/monthly-trend/', { params: { months } })
  return data.data
}

export async function fetchRecentTransactions(limit = 8) {
  const { data } = await api.get('/dashboard/recent-transactions/', { params: { limit } })
  return data.data
}

export async function fetchNetWorth() {
  const { data } = await api.get('/dashboard/net-worth/')
  return data.data
}

export async function fetchFinancialHealth() {
  const { data } = await api.get('/dashboard/financial-health/')
  return data.data
}

export async function fetchUpcomingBills(days = 30) {
  const { data } = await api.get('/dashboard/upcoming-bills/', { params: { days } })
  return data.data
}

export async function fetchMonthlyOverview() {
  const { data } = await api.get('/dashboard/monthly-overview/')
  return data.data
}
