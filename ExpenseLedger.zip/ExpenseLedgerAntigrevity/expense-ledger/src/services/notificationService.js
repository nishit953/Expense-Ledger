import api from './api'

export async function fetchNotifications(params = {}) {
  const { data } = await api.get('/notifications/', { params })
  return data
}

export async function markAsRead(id) {
  const { data } = await api.patch(`/notifications/${id}/read/`)
  return data
}

export async function markAllAsRead() {
  const { data } = await api.post('/notifications/mark-all-read/')
  return data
}

export async function deleteNotification(id) {
  await api.delete(`/notifications/${id}/`)
}

export async function fetchUnreadCount() {
  const { data } = await api.get('/notifications/unread-count/')
  return data.data.unread_count
}

export async function generateNotifications() {
  const { data } = await api.post('/notifications/generate/')
  return data
}

export const NOTIFICATION_TYPE_STYLES = {
  success: { color: 'text-emerald-600', bg: 'bg-emerald-50 dark:bg-emerald-900/20' },
  warning: { color: 'text-amber-600', bg: 'bg-amber-50 dark:bg-amber-900/20' },
  info: { color: 'text-ink-600', bg: 'bg-ink-50 dark:bg-ink-900/20' },
  reminder: { color: 'text-violet-600', bg: 'bg-violet-50 dark:bg-violet-900/20' },
}
