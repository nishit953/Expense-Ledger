import api from './api'

export async function fetchSettings() {
  const { data } = await api.get('/settings/')
  return data
}

export async function updateSettings(payload) {
  const { data } = await api.patch('/settings/', payload)
  return data
}

export const THEMES = [
  { value: 'light', label: 'Light' },
  { value: 'dark', label: 'Dark' },
  { value: 'system', label: 'System' },
]
