import {
  PiggyBank,
  LineChart,
  Target,
  Sparkles,
  Wallet,
  TrendingUp,
} from 'lucide-react'

export const heroStats = [
  { label: 'Tracked monthly', value: 482300, prefix: '₹' },
  { label: 'Active ledgers', value: 12480, prefix: '' },
  { label: 'Avg. savings lift', value: 23, suffix: '%' },
]

export const features = [
  {
    icon: Wallet,
    title: 'Expense Tracking',
    desc: 'Every rupee categorized automatically the moment it moves — no manual entry required.',
  },
  {
    icon: PiggyBank,
    title: 'Budget Management',
    desc: 'Set limits per category and get nudged before you overspend, not after.',
  },
  {
    icon: LineChart,
    title: 'Stock Portfolio',
    desc: 'Watch your holdings alongside your spending in one unified ledger view.',
  },
  {
    icon: TrendingUp,
    title: 'Investment Tracking',
    desc: 'SIPs, mutual funds, and equities — performance tracked against your goals.',
  },
  {
    icon: Target,
    title: 'Financial Goals',
    desc: 'Define what you are saving for and watch a real progress line move toward it.',
  },
  {
    icon: Sparkles,
    title: 'AI Insights',
    desc: 'Pattern-spotting across months of data to flag leaks before they compound.',
  },
]

export const howItWorks = [
  {
    title: 'Connect your ledger',
    desc: 'Link accounts or enter transactions manually — your data, your control.',
  },
  {
    title: 'Let the AI categorize',
    desc: 'Every transaction sorted into a category automatically, refined as you go.',
  },
  {
    title: 'Track goals in real time',
    desc: 'Budgets, portfolios, and savings goals update live as your ledger moves.',
  },
]

export const testimonials = [
  {
    name: 'Priya Nair',
    role: 'Product Designer',
    quote:
      'I finally understand where my money leaks every month. The AI insights caught a subscription I forgot about within a week.',
  },
  {
    name: 'Rahul Mehta',
    role: 'Software Engineer',
    quote:
      'The portfolio view next to my expenses changed how I think about spending. It is the first finance app I have kept open.',
  },
  {
    name: 'Ananya Iyer',
    role: 'Freelance Consultant',
    quote:
      'Goal tracking with a real progress line instead of a percentage bar made saving for my sabbatical feel tangible.',
  },
]

export const faqs = [
  {
    q: 'Is my financial data secure?',
    a: 'Data is encrypted in transit and at rest. Phase 1 of ExpenseLedger runs entirely on mock data — no real accounts are connected yet.',
  },
  {
    q: 'Which accounts can I connect?',
    a: 'Bank accounts, credit cards, and brokerage accounts will be supported at launch, with manual entry always available as a fallback.',
  },
  {
    q: 'Does the AI give investment advice?',
    a: 'The AI surfaces patterns in your own data — spending leaks, goal pacing, budget drift — rather than recommending trades.',
  },
  {
    q: 'Is there a free plan?',
    a: 'Pricing is being finalized. A generous free tier is planned alongside a paid tier for advanced portfolio analytics.',
  },
]

export const pricingPlans = [
  {
    name: 'Starter',
    price: 'Free',
    tagline: 'For getting your ledger in order',
    features: ['Unlimited manual transactions', 'Core budget tracking', '1 financial goal', 'Monthly AI summary'],
  },
  {
    name: 'Pro',
    price: 'Coming soon',
    tagline: 'For serious portfolio tracking',
    features: ['Everything in Starter', 'Live portfolio tracking', 'Unlimited goals', 'Weekly AI insights', 'Priority support'],
    highlighted: true,
  },
  {
    name: 'Teams',
    price: 'Coming soon',
    tagline: 'For households and small teams',
    features: ['Everything in Pro', 'Shared ledgers', 'Role-based access', 'Consolidated reporting'],
  },
]

export const chartData = [
  { month: 'Jan', spend: 32000, saved: 8000 },
  { month: 'Feb', spend: 28500, saved: 11200 },
  { month: 'Mar', spend: 34200, saved: 9800 },
  { month: 'Apr', spend: 29100, saved: 13400 },
  { month: 'May', spend: 31800, saved: 12100 },
  { month: 'Jun', spend: 26900, saved: 15600 },
]
