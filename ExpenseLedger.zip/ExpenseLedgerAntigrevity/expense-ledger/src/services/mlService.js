import api from './api'

export async function suggestCategory(title, description = '') {
  const { data } = await api.post('/ml/suggest-category/', { title, description })
  return data.data // { category, confidence, method }
}

export async function fetchExpenseForecast() {
  const { data } = await api.get('/ml/expense-forecast/')
  return data.data // { prediction, method, months_used }
}

export async function fetchBudgetRisk(budgetId) {
  const { data } = await api.get(`/ml/budget-risk/${budgetId}/`)
  return data.data // { budget_id, risk_score, method }
}

export async function fetchAnomalies(days = 30) {
  const { data } = await api.get('/ml/anomalies/', { params: { days } })
  return data.data // [{ expense_id, title, amount, expense_date, is_anomaly, score, method }]
}

export async function fetchGoalForecast(goalId) {
  const { data } = await api.get(`/ml/goal-forecast/${goalId}/`)
  return data.data // { goal_id, estimated_days_remaining, estimated_completion_date, pace_status, method }
}
