import { useEffect, useMemo, useState } from 'react'
import { Plus, Receipt as ReceiptIcon } from 'lucide-react'
import AppLayout from '../../components/layout/AppLayout'
import { Card } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import Modal from '../../components/ui/Modal'
import ConfirmDialog from '../../components/ui/ConfirmDialog'
import EmptyState from '../../components/ui/EmptyState'
import { SkeletonTable } from '../../components/ui/Skeleton'
import Pagination from '../../components/ui/Pagination'
import ExpenseFilters from '../../components/expenses/ExpenseFilters'
import ExpenseForm from '../../components/expenses/ExpenseForm'
import ExpenseTable from '../../components/expenses/ExpenseTable'
import useExpenses from '../../hooks/useExpenses'
import useDebounce from '../../hooks/useDebounce'
import { formatCurrency } from '../../utils/format'
import { fetchAnomalies } from '../../services/mlService'

export default function ExpenseList() {
  const [filters, setFilters] = useState({
    search: '', category: '', payment_method: '', date_from: '', date_to: '', ordering: '-expense_date',
  })
  const [page, setPage] = useState(1)
  const debouncedSearch = useDebounce(filters.search, 400)

  const queryParams = useMemo(
    () => ({ ...filters, search: debouncedSearch, page }),
    [filters, debouncedSearch, page]
  )

  const { expenses, totalCount, pageCount, loading, create, update, remove } = useExpenses(queryParams)

  const [anomalyIds, setAnomalyIds] = useState(new Set())
  useEffect(() => {
    fetchAnomalies(30)
      .then((results) => setAnomalyIds(new Set(results.map((r) => r.expense_id))))
      .catch(() => {}) // supplementary hint only — table works fine without it
  }, [expenses])

  const [modalOpen, setModalOpen] = useState(false)
  const [editing, setEditing] = useState(null)
  const [submitting, setSubmitting] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState(null)
  const [deleting, setDeleting] = useState(false)

  const openCreate = () => {
    setEditing(null)
    setModalOpen(true)
  }
  const openEdit = (exp) => {
    setEditing(exp)
    setModalOpen(true)
  }

  const handleSubmit = async (data) => {
    setSubmitting(true)
    const ok = editing ? await update(editing.id, data) : await create(data)
    setSubmitting(false)
    if (ok) setModalOpen(false)
  }

  const handleDelete = async () => {
    setDeleting(true)
    const ok = await remove(deleteTarget.id)
    setDeleting(false)
    if (ok) setDeleteTarget(null)
  }

  const pageTotal = expenses.reduce((sum, e) => sum + Number(e.amount), 0)

  return (
    <AppLayout title="Expenses" subtitle="Every expense, categorized and searchable">
      <div className="flex items-center justify-between mb-6 gap-4">
        <div>
          <p className="text-xs text-ink900/45 dark:text-night-muted uppercase tracking-wide">This page’s total</p>
          <p className="num text-2xl font-semibold text-ink900 dark:text-night-text">{formatCurrency(pageTotal)}</p>
        </div>
        <Button onClick={openCreate}>
          <Plus size={16} /> Add expense
        </Button>
      </div>

      <ExpenseFilters filters={filters} onChange={(f) => { setFilters(f); setPage(1) }} />

      <Card className="p-5 sm:p-6">
        {loading ? (
          <SkeletonTable rows={6} />
        ) : expenses.length === 0 ? (
          <EmptyState
            icon={ReceiptIcon}
            title="No expenses found"
            description="Try adjusting your filters, or add your first expense."
            actionLabel="Add expense"
            onAction={openCreate}
          />
        ) : (
          <>
            <ExpenseTable expenses={expenses} onEdit={openEdit} onDelete={setDeleteTarget} anomalyIds={anomalyIds} />
            <Pagination page={page} pageCount={pageCount} onPageChange={setPage} totalCount={totalCount} />
          </>
        )}
      </Card>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit expense' : 'Add expense'}>
        <ExpenseForm
          initialValues={editing}
          onSubmit={handleSubmit}
          onCancel={() => setModalOpen(false)}
          submitting={submitting}
        />
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete this expense?"
        description={deleteTarget ? `"${deleteTarget.title}" will be permanently removed.` : ''}
      />
    </AppLayout>
  )
}
