import { useState } from 'react'
import { Sparkles } from 'lucide-react'
import AppLayout from '../components/layout/AppLayout'
import { Card } from '../components/ui/Card'
import EmptyState from '../components/ui/EmptyState'
import { SkeletonCard } from '../components/ui/Skeleton'
import InsightFilters from '../components/insights/InsightFilters'
import InsightCard from '../components/insights/InsightCard'
import useInsights from '../hooks/useInsights'

export default function Insights() {
  const [category, setCategory] = useState(null)
  const { insights, countsByCategory, loading } = useInsights(category)

  return (
    <AppLayout title="AI Insights" subtitle="Personalized recommendations based on your spending, budgets, and goals">
      <InsightFilters category={category} onCategoryChange={setCategory} countsByCategory={countsByCategory} />

      {loading ? (
        <div className="grid sm:grid-cols-2 gap-4">
          {[0, 1, 2, 3].map((i) => <SkeletonCard key={i} />)}
        </div>
      ) : insights.length === 0 ? (
        <Card className="p-5">
          <EmptyState
            icon={Sparkles}
            title="No insights right now"
            description="As you log expenses, income, budgets, and goals, personalized recommendations will show up here."
          />
        </Card>
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {insights.map((insight) => (
            <InsightCard key={insight.id} insight={insight} />
          ))}
        </div>
      )}
    </AppLayout>
  )
}
