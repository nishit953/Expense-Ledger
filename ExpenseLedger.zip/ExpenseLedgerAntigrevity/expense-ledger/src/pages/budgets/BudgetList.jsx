import { useMemo, useState } from 'react'
import { Plus, PiggyBank } from 'lucide-react'
import AppLayout from '../../components/layout/AppLayout'
import { Card } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import Modal from '../../components/ui/Modal'
import ConfirmDialog from '../../components/ui/ConfirmDialog'
import EmptyState from '../../components/ui/EmptyState'
import { SkeletonCard } from '../../components/ui/Skeleton'
import Pagination from '../../components/ui/Pagination'
import BudgetFilters from '../../components/budgets/BudgetFilters'
import BudgetForm from '../../components/budgets/BudgetForm'
import BudgetCard from '../../components/budgets/BudgetCard'
import BudgetTable from '../../components/budgets/BudgetTable'
import useBudgets from '../../hooks/useBudgets'

export default function BudgetList() {
  const [filters, setFilters] = useState({ category: '', month: '', ordering: '-month' })
  const [view, setView] = useState('cards')
  const [page, setPage] = useState(1)

  const queryParams = useMemo(() => ({ ...filters, page }), [filters, page])
  const { budgets, totalCount, pageCount, loading, create, update, remove } = useBudgets(queryParams)

  const [modalOpen, setModalOpen] = useState(false)
  const [editing, setEditing] = useState(null)
  const [submitting, setSubmitting] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState(null)
  const [deleting, setDeleting] = useState(false)

  const openCreate = () => {
    setEditing(null)
    setModalOpen(true)
  }
  const openEdit = (b) => {
    setEditing(b)
    setModalOpen(true)
  }

  const handleSubmit = async (payload) => {
    setSubmitting(true)
    const ok = editing ? await update(editing.id, payload) : await create(payload)
    setSubmitting(false)
    if (ok) setModalOpen(false)
  }

  const handleDelete = async () => {
    setDeleting(true)
    const ok = await remove(deleteTarget.id)
    setDeleting(false)
    if (ok) setDeleteTarget(null)
  }

  return (
    <AppLayout title="Budgets" subtitle="Set monthly limits and track spending against them">
      <div className="flex items-center justify-between mb-6">
        <p className="text-sm text-ink900/50 dark:text-night-muted">
          <span className="num font-medium text-ink900 dark:text-night-text">{totalCount}</span> budget{totalCount !== 1 && 's'} set
        </p>
        <Button onClick={openCreate}>
          <Plus size={16} /> Create budget
        </Button>
      </div>

      <BudgetFilters filters={filters} onChange={(f) => { setFilters(f); setPage(1) }} view={view} onViewChange={setView} />

      {loading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {[0, 1, 2].map((i) => <SkeletonCard key={i} />)}
        </div>
      ) : budgets.length === 0 ? (
        <Card className="p-5">
          <EmptyState
            icon={PiggyBank}
            title="No budgets yet"
            description="Set a monthly limit for a category to start tracking spending against it."
            actionLabel="Create budget"
            onAction={openCreate}
          />
        </Card>
      ) : view === 'cards' ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {budgets.map((b) => (
            <BudgetCard key={b.id} budget={b} onEdit={openEdit} onDelete={setDeleteTarget} />
          ))}
        </div>
      ) : (
        <Card className="p-5 sm:p-6">
          <BudgetTable budgets={budgets} onEdit={openEdit} onDelete={setDeleteTarget} />
        </Card>
      )}

      <Pagination page={page} pageCount={pageCount} onPageChange={setPage} totalCount={totalCount} />

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit budget' : 'Create budget'}>
        <BudgetForm initialValues={editing} onSubmit={handleSubmit} onCancel={() => setModalOpen(false)} submitting={submitting} />
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete this budget?"
        description={deleteTarget ? `The ${deleteTarget.category_display} budget for ${deleteTarget.month} will be permanently removed.` : ''}
      />
    </AppLayout>
  )
}
