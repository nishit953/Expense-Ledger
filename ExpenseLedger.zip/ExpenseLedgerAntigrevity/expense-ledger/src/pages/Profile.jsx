import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import toast from 'react-hot-toast'
import { Save, KeyRound, Sun, Moon, LogOut } from 'lucide-react'
import AppLayout from '../components/layout/AppLayout'
import { Card } from '../components/ui/Card'
import Input from '../components/ui/Input'
import Button from '../components/ui/Button'
import Modal from '../components/ui/Modal'
import ProfileStatsPanel from '../components/profile/ProfileStatsPanel'
import { useTheme } from '../context/ThemeContext'
import { useAuth } from '../context/AuthContext'
import * as authService from '../services/authService'
import { extractErrorMessage } from '../services/api'

function ChangePasswordForm({ onDone }) {
  const [loading, setLoading] = useState(false)
  const {
    register,
    handleSubmit,
    watch,
    reset,
    formState: { errors },
  } = useForm({ defaultValues: { old_password: '', new_password: '', confirm_new_password: '' } })
  const newPassword = watch('new_password')

  const onSubmit = async (values) => {
    setLoading(true)
    try {
      await authService.changePassword(values)
      toast.success('Password changed')
      reset()
      onDone()
    } catch (err) {
      toast.error(extractErrorMessage(err))
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
      <Input
        label="Current password"
        type="password"
        {...register('old_password', { required: 'Current password is required' })}
        error={errors.old_password?.message}
      />
      <Input
        label="New password"
        type="password"
        {...register('new_password', {
          required: 'New password is required',
          minLength: { value: 8, message: 'Must be at least 8 characters' },
        })}
        error={errors.new_password?.message}
      />
      <Input
        label="Confirm new password"
        type="password"
        {...register('confirm_new_password', {
          required: 'Confirm your new password',
          validate: (v) => v === newPassword || 'Passwords do not match',
        })}
        error={errors.confirm_new_password?.message}
      />
      <Button type="submit" loading={loading} className="w-full">
        Update password
      </Button>
    </form>
  )
}

export default function Profile() {
  const { theme, toggleTheme } = useTheme()
  const { user, updateUser, logout } = useAuth()
  const [saving, setSaving] = useState(false)
  const [passwordModalOpen, setPasswordModalOpen] = useState(false)

  const [summary, setSummary] = useState(null)
  const [summaryLoading, setSummaryLoading] = useState(true)

  const handleLogout = async () => {
    try {
      await logout()
      toast.success('Logged out successfully')
    } catch (err) {
      toast.error(extractErrorMessage(err))
    }
  }

  useEffect(() => {
    authService
      .fetchProfileSummary()
      .then(setSummary)
      .catch(() => {})
      .finally(() => setSummaryLoading(false))
  }, [])

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    defaultValues: { first_name: '', last_name: '', phone_number: '', bio: '', occupation: '', monthly_income: '' },
  })

  useEffect(() => {
    if (user) {
      reset({
        first_name: user.first_name || '',
        last_name: user.last_name || '',
        phone_number: user.phone_number || '',
        bio: user.bio || '',
        occupation: user.occupation || '',
        monthly_income: user.monthly_income || '',
      })
    }
  }, [user, reset])

  const onSubmit = async (values) => {
    setSaving(true)
    try {
      const payload = {
        ...values,
        phone_number: values.phone_number ? values.phone_number.replace(/\D/g, '') : '',
      }
      const updated = await authService.updateProfile(payload)
      updateUser(updated)
      toast.success('Profile updated')
    } catch (err) {
      toast.error(extractErrorMessage(err))
    } finally {
      setSaving(false)
    }
  }

  return (
    <AppLayout title="Profile" subtitle="Manage your account details and preferences">
      <div className="grid lg:grid-cols-3 gap-6 max-w-6xl">
        <div className="lg:col-span-2">
          <Card className="p-7 sm:p-9">
            <div className="flex items-center gap-5 pb-8 border-b border-paper-line dark:border-night-line">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-emerald-400 to-violet-500 flex items-center justify-center text-white text-2xl font-semibold font-display shadow-sm">
                {user?.first_name?.charAt(0) || user?.email?.charAt(0) || 'U'}
              </div>
              <div>
                <p className="font-display font-semibold text-lg text-ink900 dark:text-night-text">
                  {user?.full_name || user?.email}
                </p>
                <p className="text-sm text-ink900/50 dark:text-night-muted">{user?.email}</p>
              </div>
            </div>

            <form onSubmit={handleSubmit(onSubmit)} className="pt-8 space-y-5">
              <div className="grid sm:grid-cols-2 gap-5">
                <Input label="First name" {...register('first_name')} />
                <Input label="Last name" {...register('last_name')} />
              </div>
              <div className="grid sm:grid-cols-2 gap-5">
                <Input
                  label="Phone number"
                  maxLength={10}
                  placeholder="9876543210"
                  {...register('phone_number', {
                    validate: (v) => !v || /^[0-9]{10}$/.test(v.replace(/\D/g, '')) || 'Phone number must be exactly 10 digits',
                  })}
                  error={errors.phone_number?.message}
                />
                <Input label="Occupation" placeholder="e.g. Software Engineer" {...register('occupation')} />
              </div>
              <Input
                label="Monthly income (₹)"
                type="number"
                step="0.01"
                placeholder="0.00"
                {...register('monthly_income', {
                  min: { value: 0, message: 'Monthly income cannot be negative' },
                })}
                error={errors.monthly_income?.message}
              />
              <div>
                <label className="block text-sm font-medium text-ink900/80 dark:text-night-text/80 mb-1.5">
                  Bio
                </label>
                <textarea
                  rows={3}
                  {...register('bio')}
                  className="w-full rounded-xl border border-paper-line dark:border-night-line bg-white dark:bg-night-surface text-ink900 dark:text-night-text px-4 py-3 text-sm outline-none focus:border-emerald-600 transition-colors resize-none"
                />
              </div>

              <div className="flex items-center gap-3 pt-2 flex-wrap">
                <Button type="submit" loading={saving}>
                  <Save size={16} /> Save changes
                </Button>
                <Button type="button" variant="outline" onClick={() => setPasswordModalOpen(true)}>
                  <KeyRound size={16} /> Change password
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleLogout}
                  className="border-red-200 text-red-600 hover:bg-red-50 dark:border-red-900/40 dark:text-red-400 dark:hover:bg-red-950/30"
                >
                  <LogOut size={16} /> Log out
                </Button>
              </div>
            </form>

            <div className="mt-8 pt-8 border-t border-paper-line dark:border-night-line flex items-center justify-between">
              <div className="flex items-center gap-3">
                {theme === 'dark' ? (
                  <Moon size={18} className="text-night-muted" />
                ) : (
                  <Sun size={18} className="text-amber-500" />
                )}
                <div>
                  <p className="text-sm font-medium text-ink900 dark:text-night-text">Dark mode</p>
                  <p className="text-xs text-ink900/45 dark:text-night-muted">
                    Switch between light and dark themes
                  </p>
                </div>
              </div>
              <button
                onClick={toggleTheme}
                aria-label="Toggle dark mode"
                className={`relative w-14 h-8 rounded-full flex items-center px-1 transition-colors duration-300 ${
                  theme === 'dark' ? 'bg-emerald-700' : 'bg-paper-line'
                }`}
              >
                <span
                  className={`w-6 h-6 rounded-full bg-white shadow-soft transition-transform duration-300 ${
                    theme === 'dark' ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </Card>
        </div>

        <ProfileStatsPanel summary={summary} loading={summaryLoading} />
      </div>

      <Modal open={passwordModalOpen} onClose={() => setPasswordModalOpen(false)} title="Change password">
        <ChangePasswordForm onDone={() => setPasswordModalOpen(false)} />
      </Modal>
    </AppLayout>
  )
}
