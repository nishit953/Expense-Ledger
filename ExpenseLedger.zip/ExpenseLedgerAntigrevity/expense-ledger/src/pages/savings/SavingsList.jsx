import { useEffect, useMemo, useState } from 'react'
import { Plus, Wallet, TrendingUp, ShieldCheck } from 'lucide-react'
import AppLayout from '../../components/layout/AppLayout'
import { Card } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import Modal from '../../components/ui/Modal'
import ConfirmDialog from '../../components/ui/ConfirmDialog'
import EmptyState from '../../components/ui/EmptyState'
import { SkeletonTable } from '../../components/ui/Skeleton'
import Pagination from '../../components/ui/Pagination'
import StatCard from '../../components/dashboard/StatCard'
import SavingsGrowthChart from '../../components/savings/SavingsGrowthChart'
import SavingsFilters from '../../components/savings/SavingsFilters'
import SavingsForm from '../../components/savings/SavingsForm'
import SavingsTable from '../../components/savings/SavingsTable'
import useSavings from '../../hooks/useSavings'
import useDebounce from '../../hooks/useDebounce'
import * as savingsService from '../../services/savingsService'

export default function SavingsList() {
  const [filters, setFilters] = useState({ search: '', source: '', date_from: '', date_to: '', ordering: '-date' })
  const [page, setPage] = useState(1)
  const debouncedSearch = useDebounce(filters.search, 400)

  const queryParams = useMemo(() => ({ ...filters, search: debouncedSearch, page }), [filters, debouncedSearch, page])
  const { entries, totalCount, pageCount, loading, create, update, remove } = useSavings(queryParams)

  const [stats, setStats] = useState(null)
  const [statsLoading, setStatsLoading] = useState(true)

  const loadStats = async () => {
    setStatsLoading(true)
    try {
      const data = await savingsService.fetchSavingsStats()
      setStats(data)
    } finally {
      setStatsLoading(false)
    }
  }

  useEffect(() => {
    loadStats()
  }, [])

  const [modalOpen, setModalOpen] = useState(false)
  const [editing, setEditing] = useState(null)
  const [submitting, setSubmitting] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState(null)
  const [deleting, setDeleting] = useState(false)

  const openCreate = () => {
    setEditing(null)
    setModalOpen(true)
  }
  const openEdit = (e) => {
    setEditing(e)
    setModalOpen(true)
  }

  const handleSubmit = async (payload) => {
    setSubmitting(true)
    const ok = editing ? await update(editing.id, payload) : await create(payload)
    setSubmitting(false)
    if (ok) {
      setModalOpen(false)
      loadStats()
    }
  }

  const handleDelete = async () => {
    setDeleting(true)
    const ok = await remove(deleteTarget.id)
    setDeleting(false)
    if (ok) {
      setDeleteTarget(null)
      loadStats()
    }
  }

  return (
    <AppLayout title="Savings" subtitle="Track deposits and watch your balance grow">
      <div className="grid sm:grid-cols-3 gap-5 mb-6">
        <StatCard label="Total savings" value={stats?.total_savings ?? 0} icon={Wallet} variant="emerald" loading={statsLoading} />
        <StatCard label="This month" value={stats?.monthly_savings ?? 0} icon={TrendingUp} variant="ink" loading={statsLoading} />
        <StatCard label="Emergency fund" value={stats?.emergency_fund ?? 0} icon={ShieldCheck} variant="violet" loading={statsLoading} />
      </div>

      <div className="mb-6">
        <SavingsGrowthChart data={stats?.growth_trend} loading={statsLoading} />
      </div>

      <div className="flex items-center justify-end mb-4">
        <Button onClick={openCreate}>
          <Plus size={16} /> Add savings entry
        </Button>
      </div>

      <SavingsFilters filters={filters} onChange={(f) => { setFilters(f); setPage(1) }} />

      <Card className="p-5 sm:p-6">
        {loading ? (
          <SkeletonTable rows={6} />
        ) : entries.length === 0 ? (
          <EmptyState
            icon={Wallet}
            title="No savings entries found"
            description="Try adjusting your filters, or log your first savings deposit."
            actionLabel="Add savings entry"
            onAction={openCreate}
          />
        ) : (
          <>
            <SavingsTable entries={entries} onEdit={openEdit} onDelete={setDeleteTarget} />
            <Pagination page={page} pageCount={pageCount} onPageChange={setPage} totalCount={totalCount} />
          </>
        )}
      </Card>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit savings entry' : 'Add savings entry'}>
        <SavingsForm initialValues={editing} onSubmit={handleSubmit} onCancel={() => setModalOpen(false)} submitting={submitting} />
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete this savings entry?"
        description="This deposit will be permanently removed from your savings history."
      />
    </AppLayout>
  )
}
