import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { Link, useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { Mail, Lock, User, Phone } from 'lucide-react'
import { AuthCard } from '../components/ui/Card'
import Input from '../components/ui/Input'
import Button from '../components/ui/Button'
import Logo from '../components/ui/Logo'
import PasswordStrengthMeter from '../components/auth/PasswordStrengthMeter'
import { useAuth } from '../context/AuthContext'
import { extractErrorMessage } from '../services/api'

export default function Register() {
  const [loading, setLoading] = useState(false)
  const { register: registerUser } = useAuth()
  const navigate = useNavigate()

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm({
    defaultValues: {
      full_name: '', email: '', phone_number: '', password: '', confirm_password: '', accept_terms: false,
    },
  })
  const password = watch('password')

  const onSubmit = async (values) => {
    setLoading(true)
    try {
      const payload = {
        ...values,
        full_name: values.full_name.trim(),
        email: values.email.trim().toLowerCase(),
        phone_number: values.phone_number ? values.phone_number.replace(/\D/g, '') : '',
      }
      const result = await registerUser(payload)
      toast.success(result.message || 'Account created')
      navigate('/verify-email', { state: { email: payload.email } })
    } catch (err) {
      toast.error(extractErrorMessage(err))
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthCard className="max-w-md">
      <div className="flex justify-center mb-8">
        <Logo />
      </div>
      <h1 className="text-2xl font-semibold text-center text-ink900 dark:text-night-text">
        Create your ledger
      </h1>
      <p className="text-sm text-center text-ink900/50 dark:text-night-muted mt-2 mb-8">
        Start tracking spending, budgets, and goals in one place
      </p>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
        <Input
          label="Full name"
          icon={User}
          placeholder="Aarav Sharma"
          {...register('full_name', {
            required: 'Enter your full name',
            minLength: { value: 2, message: 'Must be at least 2 characters' },
            validate: (v) => v.trim().length >= 2 || 'Full name must be at least 2 characters',
          })}
          error={errors.full_name?.message}
        />
        <Input
          label="Email"
          type="email"
          icon={Mail}
          placeholder="you@example.com"
          {...register('email', {
            required: 'Email is required',
            pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: 'Enter a valid email address' },
          })}
          error={errors.email?.message}
        />
        <Input
          label="Phone number"
          icon={Phone}
          maxLength={10}
          placeholder="9876543210"
          {...register('phone_number', {
            validate: (v) => !v || /^[0-9]{10}$/.test(v.replace(/\D/g, '')) || 'Phone number must be exactly 10 digits',
          })}
          error={errors.phone_number?.message}
        />
        <div>
          <Input
            label="Password"
            type="password"
            icon={Lock}
            placeholder="••••••••"
            {...register('password', {
              required: 'Password is required',
              minLength: { value: 8, message: 'Must be at least 8 characters' },
            })}
            error={errors.password?.message}
          />
          <PasswordStrengthMeter password={password} />
        </div>
        <Input
          label="Confirm password"
          type="password"
          icon={Lock}
          placeholder="••••••••"
          {...register('confirm_password', {
            required: 'Confirm your password',
            validate: (v) => v === password || 'Passwords do not match',
          })}
          error={errors.confirm_password?.message}
        />

        <div>
          <label className="flex items-start gap-2.5 text-sm text-ink900/65 dark:text-night-muted cursor-pointer select-none">
            <input
              type="checkbox"
              {...register('accept_terms', { required: 'You must accept the terms to continue' })}
              className="w-4 h-4 mt-0.5 rounded accent-emerald-600"
            />
            I agree to the <span className="text-emerald-700 dark:text-emerald-400 font-medium">Terms of Service</span> and{' '}
            <span className="text-emerald-700 dark:text-emerald-400 font-medium">Privacy Policy</span>
          </label>
          {errors.accept_terms && <p className="mt-1.5 text-xs text-red-500">{errors.accept_terms.message}</p>}
        </div>

        <Button type="submit" size="lg" className="w-full" loading={loading}>
          {loading ? 'Creating account...' : 'Create account'}
        </Button>
      </form>

      <p className="text-sm text-center text-ink900/50 dark:text-night-muted mt-8">
        Already have an account?{' '}
        <Link to="/login" className="text-emerald-700 dark:text-emerald-400 font-medium">
          Log in
        </Link>
      </p>
    </AuthCard>
  )
}
