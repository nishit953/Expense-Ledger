import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { Mail, Lock } from 'lucide-react'
import { AuthCard } from '../components/ui/Card'
import Input from '../components/ui/Input'
import Button from '../components/ui/Button'
import Logo from '../components/ui/Logo'
import { useAuth } from '../context/AuthContext'
import { extractErrorMessage } from '../services/api'

export default function Login() {
  const [loading, setLoading] = useState(false)
  const { login } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({ defaultValues: { email: '', password: '', rememberMe: false } })

  const onSubmit = async (values) => {
    setLoading(true)
    try {
      const payload = { ...values, email: values.email.trim().toLowerCase() }
      await login(payload)
      toast.success('Welcome back')
      navigate(location.state?.from?.pathname || '/app/dashboard', { replace: true })
    } catch (err) {
      toast.error(extractErrorMessage(err))
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthCard>
      <div className="flex justify-center mb-8">
        <Logo />
      </div>
      <h1 className="text-2xl font-semibold text-center text-ink900 dark:text-night-text">
        Welcome back
      </h1>
      <p className="text-sm text-center text-ink900/50 dark:text-night-muted mt-2 mb-8">
        Log in to keep your ledger up to date
      </p>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
        <Input
          label="Email"
          type="email"
          icon={Mail}
          placeholder="you@example.com"
          {...register('email', {
            required: 'Email is required',
            pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: 'Enter a valid email address' },
          })}
          error={errors.email?.message}
        />
        <Input
          label="Password"
          type="password"
          icon={Lock}
          placeholder="••••••••"
          {...register('password', { required: 'Password is required' })}
          error={errors.password?.message}
        />

        <div className="flex items-center justify-between text-sm">
          <label className="flex items-center gap-2 text-ink900/65 dark:text-night-muted cursor-pointer select-none">
            <input
              type="checkbox"
              {...register('rememberMe')}
              className="w-4 h-4 rounded accent-emerald-600"
            />
            Remember me
          </label>
          <Link to="/forgot-password" className="text-emerald-700 dark:text-emerald-400 font-medium">
            Forgot password?
          </Link>
        </div>

        <Button type="submit" size="lg" className="w-full" loading={loading}>
          {loading ? 'Logging in...' : 'Log in'}
        </Button>
      </form>

      <p className="text-sm text-center text-ink900/50 dark:text-night-muted mt-8">
        Don’t have an account?{' '}
        <Link to="/register" className="text-emerald-700 dark:text-emerald-400 font-medium">
          Sign up
        </Link>
      </p>
    </AuthCard>
  )
}
