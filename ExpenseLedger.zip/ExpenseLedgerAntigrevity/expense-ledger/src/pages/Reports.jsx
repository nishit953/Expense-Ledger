import { useState } from 'react'
import { TrendingUp, TrendingDown, PiggyBank, Target } from 'lucide-react'
import AppLayout from '../components/layout/AppLayout'
import { Card } from '../components/ui/Card'
import ReportFilters from '../components/reports/ReportFilters'
import ExportButtons from '../components/reports/ExportButtons'
import BreakdownList from '../components/dashboard/BreakdownList'
import StatCard from '../components/dashboard/StatCard'
import BudgetProgressBar from '../components/budgets/BudgetProgressBar'
import useReport from '../hooks/useReport'
import { formatCurrency } from '../utils/format'

const today = new Date()

export default function Reports() {
  const [params, setParams] = useState({
    type: 'monthly', year: today.getFullYear(), month: today.getMonth() + 1, date_from: '', date_to: '',
  })
  const { report, loading } = useReport(params)

  return (
    <AppLayout title="Reports" subtitle="Monthly and yearly summaries across your whole ledger">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-2">
        <ReportFilters params={params} onChange={setParams} />
        <ExportButtons exportParams={params} />
      </div>

      {loading || !report ? (
        <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-5">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="h-28 rounded-xl2 bg-paper-line/50 dark:bg-night-line/50 animate-pulse" />
          ))}
        </div>
      ) : (
        <>
          <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-5 mb-6">
            <StatCard label="Total income" value={report.monthly_overview.total_income} icon={TrendingUp} variant="emerald" />
            <StatCard label="Total expense" value={report.monthly_overview.total_expense} icon={TrendingDown} variant="ink" />
            <StatCard label="Net savings" value={report.monthly_overview.net_savings} icon={PiggyBank} variant="violet" />
            <StatCard label="Saved (period)" value={report.savings_summary.saved_in_period} icon={Target} variant="dark" />
          </div>

          <div className="grid lg:grid-cols-2 gap-6 mb-6">
            <BreakdownList title="Expense by category" items={report.expense_summary.by_category} labelKey="category" />
            <BreakdownList title="Income by source" items={report.income_summary.by_source} labelKey="source" />
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="p-6">
              <p className="text-sm font-medium text-ink900/70 dark:text-night-text/70 mb-4">Budget performance</p>
              {report.budget_summary.budget_count > 0 ? (
                <>
                  <div className="flex items-baseline justify-between mb-2">
                    <span className="num text-xl font-semibold text-ink900 dark:text-night-text">
                      {formatCurrency(report.budget_summary.total_spent)}
                    </span>
                    <span className="num text-sm text-ink900/45 dark:text-night-muted">
                      of {formatCurrency(report.budget_summary.total_limit)}
                    </span>
                  </div>
                  <BudgetProgressBar
                    percentage={report.budget_summary.percentage_used}
                    status={
                      report.budget_summary.percentage_used >= 100
                        ? 'exceeded'
                        : report.budget_summary.percentage_used >= 80
                        ? 'warning'
                        : 'on_track'
                    }
                  />
                </>
              ) : (
                <p className="text-sm text-ink900/45 dark:text-night-muted">No budgets set for this period.</p>
              )}
            </Card>

            <Card className="p-6">
              <p className="text-sm font-medium text-ink900/70 dark:text-night-text/70 mb-4">Goal summary</p>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="num text-xl font-semibold text-ink900 dark:text-night-text">{report.goal_summary.active_goals}</p>
                  <p className="text-xs text-ink900/45 dark:text-night-muted">Active goals</p>
                </div>
                <div>
                  <p className="num text-xl font-semibold text-emerald-600">{report.goal_summary.overall_progress}%</p>
                  <p className="text-xs text-ink900/45 dark:text-night-muted">Overall progress</p>
                </div>
              </div>
            </Card>
          </div>
        </>
      )}
    </AppLayout>
  )
}
