import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { Lock, Mail, ArrowLeft } from 'lucide-react'
import { AuthCard } from '../components/ui/Card'
import Input from '../components/ui/Input'
import Button from '../components/ui/Button'
import Logo from '../components/ui/Logo'
import PasswordStrengthMeter from '../components/auth/PasswordStrengthMeter'
import * as authService from '../services/authService'
import { extractErrorMessage } from '../services/api'

export default function ResetPassword() {
  const [loading, setLoading] = useState(false)
  const location = useLocation()
  const navigate = useNavigate()

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm({
    defaultValues: {
      email: location.state?.email || '',
      code: '',
      new_password: '',
      confirm_new_password: '',
    },
  })
  const newPassword = watch('new_password')

  const onSubmit = async (values) => {
    setLoading(true)
    try {
      await authService.resetPassword(values)
      toast.success('Password reset. You can log in now.')
      navigate('/login')
    } catch (err) {
      toast.error(extractErrorMessage(err))
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthCard>
      <div className="flex justify-center mb-8">
        <Logo />
      </div>
      <h1 className="text-2xl font-semibold text-center text-ink900 dark:text-night-text">
        Set a new password
      </h1>
      <p className="text-sm text-center text-ink900/50 dark:text-night-muted mt-2 mb-8">
        Enter the code we emailed you along with your new password
      </p>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
        <Input
          label="Email"
          type="email"
          icon={Mail}
          {...register('email', { required: 'Email is required' })}
          error={errors.email?.message}
        />
        <Input
          label="6-digit code"
          maxLength={6}
          placeholder="123456"
          {...register('code', {
            required: 'Enter the code from your email',
            minLength: { value: 6, message: 'Code must be 6 digits' },
            maxLength: { value: 6, message: 'Code must be 6 digits' },
          })}
          error={errors.code?.message}
        />
        <div>
          <Input
            label="New password"
            type="password"
            icon={Lock}
            placeholder="••••••••"
            {...register('new_password', {
              required: 'New password is required',
              minLength: { value: 8, message: 'Must be at least 8 characters' },
            })}
            error={errors.new_password?.message}
          />
          <PasswordStrengthMeter password={newPassword} />
        </div>
        <Input
          label="Confirm new password"
          type="password"
          icon={Lock}
          placeholder="••••••••"
          {...register('confirm_new_password', {
            required: 'Confirm your new password',
            validate: (v) => v === newPassword || 'Passwords do not match',
          })}
          error={errors.confirm_new_password?.message}
        />

        <Button type="submit" size="lg" className="w-full" loading={loading}>
          {loading ? 'Resetting...' : 'Reset password'}
        </Button>
      </form>

      <Link
        to="/login"
        className="mt-8 flex items-center justify-center gap-1.5 text-sm text-ink900/50 dark:text-night-muted hover:text-emerald-700 dark:hover:text-emerald-400 transition-colors"
      >
        <ArrowLeft size={15} /> Back to log in
      </Link>
    </AuthCard>
  )
}
