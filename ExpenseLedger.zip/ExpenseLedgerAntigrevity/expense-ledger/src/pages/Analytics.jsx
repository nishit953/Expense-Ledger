import { useState } from 'react'
import AppLayout from '../components/layout/AppLayout'
import { Card } from '../components/ui/Card'
import PeriodFilter from '../components/analytics/PeriodFilter'
import StatisticsGrid from '../components/analytics/StatisticsGrid'
import IncomeExpenseTrendChart from '../components/analytics/IncomeExpenseTrendChart'
import WeeklySpendingChart from '../components/analytics/WeeklySpendingChart'
import BreakdownList from '../components/dashboard/BreakdownList'
import SavingsGrowthChart from '../components/savings/SavingsGrowthChart'
import BudgetProgressBar from '../components/budgets/BudgetProgressBar'
import useAnalytics from '../hooks/useAnalytics'
import { formatCurrency } from '../utils/format'

export default function Analytics() {
  const [period, setPeriod] = useState('this_month')
  const [customRange, setCustomRange] = useState({ date_from: '', date_to: '' })

  const { data, loading } = useAnalytics(period, customRange)

  const budgetUsage = data?.budget_usage
  const overview = data?.financial_overview

  return (
    <AppLayout title="Analytics" subtitle="A closer look at your spending, income, and progress over time">
      <PeriodFilter
        period={period}
        onPeriodChange={setPeriod}
        customRange={customRange}
        onCustomRangeChange={setCustomRange}
      />

      <StatisticsGrid statistics={data?.statistics} loading={loading} />

      {overview && (
        <Card className="p-6 mb-6">
          <p className="text-sm font-medium text-ink900/70 dark:text-night-text/70 mb-4">
            Financial overview — {period === 'custom' ? `${data.date_from} to ${data.date_to}` : period.replace(/_/g, ' ')}
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-5">
            <div>
              <p className="text-xs text-ink900/45 dark:text-night-muted">Income</p>
              <p className="num text-lg font-semibold text-emerald-600 mt-1">{formatCurrency(overview.total_income)}</p>
            </div>
            <div>
              <p className="text-xs text-ink900/45 dark:text-night-muted">Expense</p>
              <p className="num text-lg font-semibold text-ink900 dark:text-night-text mt-1">{formatCurrency(overview.total_expense)}</p>
            </div>
            <div>
              <p className="text-xs text-ink900/45 dark:text-night-muted">Net</p>
              <p className={`num text-lg font-semibold mt-1 ${overview.net >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                {formatCurrency(overview.net)}
              </p>
            </div>
            <div>
              <p className="text-xs text-ink900/45 dark:text-night-muted">Saved in period</p>
              <p className="num text-lg font-semibold text-violet-600 mt-1">{formatCurrency(overview.total_saved)}</p>
            </div>
          </div>
        </Card>
      )}

      <div className="grid lg:grid-cols-2 gap-6 mb-6">
        <IncomeExpenseTrendChart data={data?.monthly_income_trend} loading={loading} />
        <SavingsGrowthChart data={data?.savings_trend} loading={loading} />
      </div>

      <div className="grid lg:grid-cols-2 gap-6 mb-6">
        <BreakdownList title="Expense categories" items={data?.expense_categories} labelKey="category" loading={loading} />
        <BreakdownList title="Income sources" items={data?.income_sources} labelKey="source" loading={loading} />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <WeeklySpendingChart data={data?.weekly_spending} loading={loading} />

        <Card className="p-6">
          <p className="text-sm font-medium text-ink900/70 dark:text-night-text/70 mb-5">Budget usage</p>
          {loading ? (
            <div className="h-3 bg-paper-line dark:bg-night-line rounded-full animate-pulse" />
          ) : budgetUsage?.budget_count ? (
            <>
              <div className="flex items-baseline justify-between mb-2">
                <span className="num text-2xl font-semibold text-ink900 dark:text-night-text">
                  {formatCurrency(budgetUsage.total_spent)}
                </span>
                <span className="num text-sm text-ink900/45 dark:text-night-muted">
                  of {formatCurrency(budgetUsage.total_limit)}
                </span>
              </div>
              <BudgetProgressBar
                percentage={budgetUsage.percentage_used}
                status={budgetUsage.percentage_used >= 100 ? 'exceeded' : budgetUsage.percentage_used >= 80 ? 'warning' : 'on_track'}
              />
              <p className="text-xs text-ink900/45 dark:text-night-muted mt-3">
                Across {budgetUsage.budget_count} active budget{budgetUsage.budget_count !== 1 && 's'} this month
              </p>
            </>
          ) : (
            <p className="text-sm text-ink900/45 dark:text-night-muted">No budgets set for this month yet.</p>
          )}
        </Card>
      </div>
    </AppLayout>
  )
}
