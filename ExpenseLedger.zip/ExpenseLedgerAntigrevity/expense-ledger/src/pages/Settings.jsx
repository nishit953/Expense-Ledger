import { Palette, BellRing, ShieldCheck } from 'lucide-react'
import AppLayout from '../components/layout/AppLayout'
import { Select } from '../components/ui/Badge'
import SettingsSection from '../components/settings/SettingsSection'
import ToggleRow from '../components/settings/ToggleRow'
import { SkeletonCard } from '../components/ui/Skeleton'
import { useTheme } from '../context/ThemeContext'
import useSettings from '../hooks/useSettings'
import { THEMES } from '../services/settingsService'

export default function Settings() {
  const { settings, loading, saving, update } = useSettings()
  const { setTheme } = useTheme()

  const handleThemeChange = (value) => {
    update({ theme: value })
    if (value === 'light' || value === 'dark') setTheme(value)
  }

  if (loading) {
    return (
      <AppLayout title="Settings" subtitle="Preferences for how ExpenseLedger looks and notifies you">
        <div className="grid sm:grid-cols-2 gap-6 max-w-4xl">
          {[0, 1, 2, 3].map((i) => <SkeletonCard key={i} />)}
        </div>
      </AppLayout>
    )
  }

  return (
    <AppLayout title="Settings" subtitle="Preferences for how ExpenseLedger looks and notifies you">
      <div className="max-w-3xl space-y-6">
        <SettingsSection icon={Palette} title="Appearance" description="Choose your preferred color theme">
          <div className="max-w-xs">
            <Select label="Theme" value={settings.theme} onChange={(e) => handleThemeChange(e.target.value)} options={THEMES} />
          </div>
        </SettingsSection>

        <SettingsSection icon={BellRing} title="Notification preferences" description="Choose which alerts you want to receive">
          <div className="divide-y divide-paper-line dark:divide-night-line">
            <ToggleRow
              label="Budget alerts"
              description="When you're nearing or over a category budget"
              checked={settings.notify_budget_alerts}
              onChange={(v) => update({ notify_budget_alerts: v })}
            />
            <ToggleRow
              label="Goal reminders"
              description="When a goal deadline is approaching"
              checked={settings.notify_goal_reminders}
              onChange={(v) => update({ notify_goal_reminders: v })}
            />
            <ToggleRow
              label="Bill reminders"
              description="When a recurring expense is due soon"
              checked={settings.notify_bill_reminders}
              onChange={(v) => update({ notify_bill_reminders: v })}
            />
            <ToggleRow
              label="Monthly summary"
              description="A nudge near month-end to review your finances"
              checked={settings.notify_monthly_summary}
              onChange={(v) => update({ notify_monthly_summary: v })}
            />
            <ToggleRow
              label="Low savings alerts"
              description="When your monthly savings rate drops below target"
              checked={settings.notify_low_savings_alerts}
              onChange={(v) => update({ notify_low_savings_alerts: v })}
            />
            <ToggleRow
              label="Email notifications"
              description="Also send important alerts to your email"
              checked={settings.email_notifications_enabled}
              onChange={(v) => update({ email_notifications_enabled: v })}
            />
          </div>
        </SettingsSection>

        <SettingsSection icon={ShieldCheck} title="Security" description="Account protection settings">
          <ToggleRow
            label="Two-factor authentication"
            description="Add an extra layer of security to your account"
            checked={settings.two_factor_enabled}
            onChange={(v) => update({ two_factor_enabled: v })}
          />
        </SettingsSection>

        {saving && <p className="text-xs text-ink900/40 dark:text-night-muted text-center">Saving...</p>}
      </div>
    </AppLayout>
  )
}
