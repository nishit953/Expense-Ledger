import { useEffect, useMemo, useState } from 'react'
import { Plus, Target } from 'lucide-react'
import AppLayout from '../../components/layout/AppLayout'
import { Card } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import Modal from '../../components/ui/Modal'
import ConfirmDialog from '../../components/ui/ConfirmDialog'
import EmptyState from '../../components/ui/EmptyState'
import { SkeletonCard } from '../../components/ui/Skeleton'
import Pagination from '../../components/ui/Pagination'
import GoalsSummaryStrip from '../../components/goals/GoalsSummaryStrip'
import GoalFilters from '../../components/goals/GoalFilters'
import GoalForm from '../../components/goals/GoalForm'
import GoalCard from '../../components/goals/GoalCard'
import ContributeForm from '../../components/goals/ContributeForm'
import useGoals from '../../hooks/useGoals'
import useDebounce from '../../hooks/useDebounce'
import * as goalService from '../../services/goalService'

export default function GoalList() {
  const [filters, setFilters] = useState({ search: '', category: '', priority: '', status: '', ordering: 'target_date' })
  const [page, setPage] = useState(1)
  const debouncedSearch = useDebounce(filters.search, 400)

  const queryParams = useMemo(() => ({ ...filters, search: debouncedSearch, page }), [filters, debouncedSearch, page])
  const { goals, totalCount, pageCount, loading, create, update, remove, contribute, abandon, reactivate } = useGoals(queryParams)

  const [summary, setSummary] = useState(null)
  useEffect(() => {
    goalService.fetchGoalsSummary().then(setSummary).catch(() => {})
  }, [goals])

  const [modalOpen, setModalOpen] = useState(false)
  const [editing, setEditing] = useState(null)
  const [submitting, setSubmitting] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState(null)
  const [deleting, setDeleting] = useState(false)
  const [contributeTarget, setContributeTarget] = useState(null)
  const [contributing, setContributing] = useState(false)

  const openCreate = () => {
    setEditing(null)
    setModalOpen(true)
  }
  const openEdit = (g) => {
    setEditing(g)
    setModalOpen(true)
  }

  const handleSubmit = async (payload) => {
    setSubmitting(true)
    const ok = editing ? await update(editing.id, payload) : await create(payload)
    setSubmitting(false)
    if (ok) setModalOpen(false)
  }

  const handleDelete = async () => {
    setDeleting(true)
    const ok = await remove(deleteTarget.id)
    setDeleting(false)
    if (ok) setDeleteTarget(null)
  }

  const handleContribute = async (payload) => {
    setContributing(true)
    const ok = await contribute(contributeTarget.id, payload)
    setContributing(false)
    if (ok) setContributeTarget(null)
  }

  return (
    <AppLayout title="Financial Goals" subtitle="Set targets and track your progress toward them">
      <GoalsSummaryStrip summary={summary} />

      <div className="flex items-center justify-between mb-2">
        <p className="text-sm text-ink900/50 dark:text-night-muted">
          <span className="num font-medium text-ink900 dark:text-night-text">{totalCount}</span> goal{totalCount !== 1 && 's'}
        </p>
        <Button onClick={openCreate}>
          <Plus size={16} /> Create goal
        </Button>
      </div>

      <GoalFilters filters={filters} onChange={(f) => { setFilters(f); setPage(1) }} />

      {loading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {[0, 1, 2].map((i) => <SkeletonCard key={i} />)}
        </div>
      ) : goals.length === 0 ? (
        <Card className="p-5">
          <EmptyState
            icon={Target}
            title="No goals yet"
            description="Create your first financial goal — an emergency fund, a trip, anything you're saving toward."
            actionLabel="Create goal"
            onAction={openCreate}
          />
        </Card>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {goals.map((g) => (
            <GoalCard
              key={g.id}
              goal={g}
              onEdit={openEdit}
              onDelete={setDeleteTarget}
              onContribute={setContributeTarget}
              onAbandon={(goal) => abandon(goal.id)}
              onReactivate={(goal) => reactivate(goal.id)}
            />
          ))}
        </div>
      )}

      <Pagination page={page} pageCount={pageCount} onPageChange={setPage} totalCount={totalCount} />

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit goal' : 'Create goal'}>
        <GoalForm initialValues={editing} onSubmit={handleSubmit} onCancel={() => setModalOpen(false)} submitting={submitting} />
      </Modal>

      <Modal open={!!contributeTarget} onClose={() => setContributeTarget(null)} title={`Contribute to ${contributeTarget?.name || ''}`}>
        <ContributeForm onSubmit={handleContribute} onCancel={() => setContributeTarget(null)} submitting={contributing} />
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete this goal?"
        description={deleteTarget ? `"${deleteTarget.name}" and its contribution history will be permanently removed.` : ''}
      />
    </AppLayout>
  )
}
