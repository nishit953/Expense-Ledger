import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import toast from 'react-hot-toast'
import { Mail, ArrowLeft, CheckCircle2 } from 'lucide-react'
import { AuthCard } from '../components/ui/Card'
import Input from '../components/ui/Input'
import Button from '../components/ui/Button'
import Logo from '../components/ui/Logo'
import * as authService from '../services/authService'
import { extractErrorMessage } from '../services/api'

export default function ForgotPassword() {
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)
  const [sentEmail, setSentEmail] = useState('')
  const navigate = useNavigate()

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({ defaultValues: { email: '' } })

  const onSubmit = async ({ email }) => {
    setLoading(true)
    try {
      await authService.forgotPassword(email)
      setSentEmail(email)
      setSent(true)
    } catch (err) {
      toast.error(extractErrorMessage(err))
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthCard>
      <div className="flex justify-center mb-8">
        <Logo />
      </div>

      {!sent ? (
        <>
          <h1 className="text-2xl font-semibold text-center text-ink900 dark:text-night-text">
            Reset your password
          </h1>
          <p className="text-sm text-center text-ink900/50 dark:text-night-muted mt-2 mb-8">
            Enter the email linked to your ledger and we’ll send a reset code
          </p>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
            <Input
              label="Email"
              type="email"
              icon={Mail}
              placeholder="you@example.com"
              {...register('email', {
                required: 'Email is required',
                pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: 'Enter a valid email address' },
              })}
              error={errors.email?.message}
            />
            <Button type="submit" size="lg" className="w-full" loading={loading}>
              {loading ? 'Sending code...' : 'Send reset code'}
            </Button>
          </form>
        </>
      ) : (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4 }}
          className="text-center"
        >
          <div className="w-14 h-14 rounded-full bg-emerald-50 dark:bg-emerald-900/20 flex items-center justify-center mx-auto mb-5">
            <CheckCircle2 size={28} className="text-emerald-600" />
          </div>
          <h1 className="text-xl font-semibold text-ink900 dark:text-night-text">
            Check your inbox
          </h1>
          <p className="text-sm text-ink900/55 dark:text-night-muted mt-2">
            If an account exists for <span className="font-medium">{sentEmail}</span>, a reset code is on its way.
          </p>
          <Button className="mt-6" onClick={() => navigate('/reset-password', { state: { email: sentEmail } })}>
            Enter reset code
          </Button>
        </motion.div>
      )}

      <Link
        to="/login"
        className="mt-8 flex items-center justify-center gap-1.5 text-sm text-ink900/50 dark:text-night-muted hover:text-emerald-700 dark:hover:text-emerald-400 transition-colors"
      >
        <ArrowLeft size={15} /> Back to log in
      </Link>
    </AuthCard>
  )
}
