import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import toast from 'react-hot-toast'
import { CheckCircle2, MailCheck } from 'lucide-react'
import { AuthCard } from '../components/ui/Card'
import Button from '../components/ui/Button'
import Logo from '../components/ui/Logo'
import OTPInput from '../components/auth/OTPInput'
import * as authService from '../services/authService'
import { extractErrorMessage } from '../services/api'

const RESEND_SECONDS = 45

export default function EmailVerification() {
  const location = useLocation()
  const navigate = useNavigate()
  const email = location.state?.email

  const [seconds, setSeconds] = useState(RESEND_SECONDS)
  const [verified, setVerified] = useState(false)
  const [verifying, setVerifying] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    if (!email) navigate('/register')
  }, [email, navigate])

  useEffect(() => {
    if (seconds <= 0) return
    const t = setInterval(() => setSeconds((s) => s - 1), 1000)
    return () => clearInterval(t)
  }, [seconds])

  const handleComplete = async (code) => {
    setError('')
    setVerifying(true)
    try {
      await authService.verifyEmail({ email, code })
      setVerified(true)
      toast.success('Email verified')
      setTimeout(() => navigate('/login'), 1600)
    } catch (err) {
      setError(extractErrorMessage(err))
    } finally {
      setVerifying(false)
    }
  }

  const handleResend = async () => {
    if (seconds > 0) return
    try {
      await authService.resendOTP(email, 'verify_email')
      toast.success('New code sent')
      setSeconds(RESEND_SECONDS)
    } catch (err) {
      toast.error(extractErrorMessage(err))
    }
  }

  return (
    <AuthCard>
      <div className="flex justify-center mb-8">
        <Logo />
      </div>

      <AnimatePresence mode="wait">
        {!verified ? (
          <motion.div key="form" exit={{ opacity: 0, scale: 0.95 }}>
            <div className="w-14 h-14 rounded-full bg-emerald-50 dark:bg-emerald-900/20 flex items-center justify-center mx-auto mb-5">
              <MailCheck size={26} className="text-emerald-600" />
            </div>
            <h1 className="text-2xl font-semibold text-center text-ink900 dark:text-night-text">
              Verify your email
            </h1>
            <p className="text-sm text-center text-ink900/50 dark:text-night-muted mt-2 mb-8">
              Enter the 6-digit code sent to <span className="font-medium">{email}</span>
            </p>

            <OTPInput onComplete={handleComplete} />
            {error && <p className="text-xs text-red-500 text-center mt-4">{error}</p>}
            {verifying && (
              <p className="text-xs text-ink900/50 dark:text-night-muted text-center mt-4">Verifying...</p>
            )}

            <div className="mt-8 text-center text-sm text-ink900/50 dark:text-night-muted">
              {seconds > 0 ? (
                <span>
                  Resend code in{' '}
                  <span className="num font-medium text-ink900 dark:text-night-text">
                    0:{String(seconds).padStart(2, '0')}
                  </span>
                </span>
              ) : (
                <Button variant="ghost" size="sm" onClick={handleResend}>
                  Resend code
                </Button>
              )}
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="success"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4 }}
            className="text-center py-4"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', stiffness: 260, damping: 18 }}
              className="w-16 h-16 rounded-full bg-emerald-50 dark:bg-emerald-900/20 flex items-center justify-center mx-auto mb-5"
            >
              <CheckCircle2 size={32} className="text-emerald-600" />
            </motion.div>
            <h1 className="text-xl font-semibold text-ink900 dark:text-night-text">
              Email verified
            </h1>
            <p className="text-sm text-ink900/55 dark:text-night-muted mt-2">
              Taking you to log in...
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </AuthCard>
  )
}
