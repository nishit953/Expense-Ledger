import { Wallet, TrendingDown, TrendingUp, Sparkles } from 'lucide-react'
import AppLayout from '../components/layout/AppLayout'
import StatCard from '../components/dashboard/StatCard'
import BreakdownList from '../components/dashboard/BreakdownList'
import TrendChart from '../components/dashboard/TrendChart'
import RecentTransactions from '../components/dashboard/RecentTransactions'
import HealthScoreCard from '../components/dashboard/HealthScoreCard'
import UpcomingBills from '../components/dashboard/UpcomingBills'
import ForecastCard from '../components/dashboard/ForecastCard'
import TopInsights from '../components/dashboard/TopInsights'
import useDashboard from '../hooks/useDashboard'
import { useAuth } from '../context/AuthContext'

export default function Dashboard() {
  const {
    summary, categoryBreakdown, sourceBreakdown, trend, recentTransactions,
    netWorth, healthScore, upcomingBills, loading,
  } = useDashboard()
  const { user } = useAuth()

  return (
    <AppLayout
      title={`Welcome back${user?.first_name ? `, ${user.first_name}` : ''}`}
      subtitle="Here's where your money stands today"
    >
      <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-5 mb-6">
        <StatCard
          label="Net worth"
          value={netWorth?.net_worth ?? 0}
          icon={Sparkles}
          variant="dark"
          loading={loading}
          hint="Balance + total savings"
        />
        <StatCard label="Today's income" value={summary?.today_income ?? 0} icon={TrendingUp} variant="emerald" loading={loading} />
        <StatCard label="Today's expense" value={summary?.today_expense ?? 0} icon={TrendingDown} variant="ink" loading={loading} />
        <StatCard
          label="This month"
          value={(summary?.monthly_income ?? 0) - (summary?.monthly_expense ?? 0)}
          icon={Wallet}
          variant="violet"
          loading={loading}
          hint="Net for the current month"
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-6 mb-6">
        <div className="lg:col-span-2 space-y-6">
          <TrendChart data={trend} loading={loading} />
          <div className="grid sm:grid-cols-2 gap-6">
            <HealthScoreCard health={healthScore} loading={loading} />
            <ForecastCard />
          </div>
        </div>
        <div className="space-y-6">
          <RecentTransactions transactions={recentTransactions} loading={loading} />
          <TopInsights />
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6 mb-6">
        <div className="lg:col-span-2 grid sm:grid-cols-2 gap-6">
          <BreakdownList title="Expense by category" items={categoryBreakdown} labelKey="category" loading={loading} />
          <BreakdownList title="Income by source" items={sourceBreakdown} labelKey="source" loading={loading} />
        </div>
        <UpcomingBills bills={upcomingBills} loading={loading} />
      </div>
    </AppLayout>
  )
}
