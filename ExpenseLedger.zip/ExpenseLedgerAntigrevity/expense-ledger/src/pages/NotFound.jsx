import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Home } from 'lucide-react'
import Button from '../components/ui/Button'
import Logo from '../components/ui/Logo'

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-paper-light dark:bg-night-bg ledger-texture px-6 text-center relative overflow-hidden">
      <div className="absolute top-10 left-1/2 -translate-x-1/2">
        <Logo />
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6 }}
        className="relative"
      >
        <svg width="280" height="200" viewBox="0 0 280 200" fill="none" className="mx-auto mb-4">
          <rect x="40" y="30" width="200" height="140" rx="16" className="fill-white dark:fill-night-card stroke-paper-line dark:stroke-night-line" strokeWidth="2" />
          {[0, 1, 2, 3, 4].map((i) => (
            <line key={i} x1="60" y1={60 + i * 20} x2="220" y2={60 + i * 20} className="stroke-paper-line dark:stroke-night-line" strokeWidth="1.5" />
          ))}
          <motion.text
            x="140"
            y="115"
            textAnchor="middle"
            className="fill-emerald-600 font-display font-bold"
            style={{ fontSize: '46px' }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
          >
            404
          </motion.text>
          <motion.circle
            cx="230"
            cy="40"
            r="8"
            className="fill-violet-400/40"
            animate={{ y: [0, -8, 0] }}
            transition={{ duration: 3, repeat: Infinity }}
          />
          <motion.circle
            cx="45"
            cy="150"
            r="6"
            className="fill-emerald-400/40"
            animate={{ y: [0, -6, 0] }}
            transition={{ duration: 2.5, repeat: Infinity, delay: 0.4 }}
          />
        </svg>
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.5 }}
        className="text-2xl sm:text-3xl font-semibold text-ink900 dark:text-night-text"
      >
        This page isn’t in the ledger
      </motion.h1>
      <motion.p
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.5 }}
        className="text-sm text-ink900/50 dark:text-night-muted mt-2 max-w-sm"
      >
        The page you’re looking for doesn’t exist or may have moved.
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.5 }}
      >
        <Link to="/">
          <Button size="lg" className="mt-8">
            <Home size={16} /> Back to home
          </Button>
        </Link>
      </motion.div>
    </div>
  )
}
