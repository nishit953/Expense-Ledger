import { useMemo, useState } from 'react'
import { Plus, Wallet } from 'lucide-react'
import AppLayout from '../../components/layout/AppLayout'
import { Card } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import Modal from '../../components/ui/Modal'
import ConfirmDialog from '../../components/ui/ConfirmDialog'
import EmptyState from '../../components/ui/EmptyState'
import { SkeletonTable } from '../../components/ui/Skeleton'
import Pagination from '../../components/ui/Pagination'
import IncomeFilters from '../../components/income/IncomeFilters'
import IncomeForm from '../../components/income/IncomeForm'
import IncomeTable from '../../components/income/IncomeTable'
import useIncome from '../../hooks/useIncome'
import useDebounce from '../../hooks/useDebounce'
import { formatCurrency } from '../../utils/format'

export default function IncomeList() {
  const [filters, setFilters] = useState({ search: '', source: '', date_from: '', date_to: '', ordering: '-income_date' })
  const [page, setPage] = useState(1)
  const debouncedSearch = useDebounce(filters.search, 400)

  const queryParams = useMemo(
    () => ({ ...filters, search: debouncedSearch, page }),
    [filters, debouncedSearch, page]
  )

  const { incomes, totalCount, pageCount, loading, create, update, remove } = useIncome(queryParams)

  const [modalOpen, setModalOpen] = useState(false)
  const [editing, setEditing] = useState(null)
  const [submitting, setSubmitting] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState(null)
  const [deleting, setDeleting] = useState(false)

  const openCreate = () => {
    setEditing(null)
    setModalOpen(true)
  }
  const openEdit = (inc) => {
    setEditing(inc)
    setModalOpen(true)
  }

  const handleSubmit = async (data) => {
    setSubmitting(true)
    const ok = editing ? await update(editing.id, data) : await create(data)
    setSubmitting(false)
    if (ok) setModalOpen(false)
  }

  const handleDelete = async () => {
    setDeleting(true)
    const ok = await remove(deleteTarget.id)
    setDeleting(false)
    if (ok) setDeleteTarget(null)
  }

  const pageTotal = incomes.reduce((sum, i) => sum + Number(i.amount), 0)

  return (
    <AppLayout title="Income" subtitle="Every income source, tracked in one place">
      <div className="flex items-center justify-between mb-6 gap-4">
        <div>
          <p className="text-xs text-ink900/45 dark:text-night-muted uppercase tracking-wide">This page’s total</p>
          <p className="num text-2xl font-semibold text-emerald-600">+{formatCurrency(pageTotal)}</p>
        </div>
        <Button onClick={openCreate}>
          <Plus size={16} /> Add income
        </Button>
      </div>

      <IncomeFilters filters={filters} onChange={(f) => { setFilters(f); setPage(1) }} />

      <Card className="p-5 sm:p-6">
        {loading ? (
          <SkeletonTable rows={6} />
        ) : incomes.length === 0 ? (
          <EmptyState
            icon={Wallet}
            title="No income entries found"
            description="Try adjusting your filters, or add your first income entry."
            actionLabel="Add income"
            onAction={openCreate}
          />
        ) : (
          <>
            <IncomeTable incomes={incomes} onEdit={openEdit} onDelete={setDeleteTarget} />
            <Pagination page={page} pageCount={pageCount} onPageChange={setPage} totalCount={totalCount} />
          </>
        )}
      </Card>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit income' : 'Add income'}>
        <IncomeForm
          initialValues={editing}
          onSubmit={handleSubmit}
          onCancel={() => setModalOpen(false)}
          submitting={submitting}
        />
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete this income entry?"
        description={deleteTarget ? `This ${deleteTarget.source_display?.toLowerCase() || 'entry'} record will be permanently removed.` : ''}
      />
    </AppLayout>
  )
}
