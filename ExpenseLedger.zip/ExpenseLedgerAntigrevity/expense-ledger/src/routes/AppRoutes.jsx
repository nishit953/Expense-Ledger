import { Routes, Route } from 'react-router-dom'
import Landing from '../pages/Landing'
import Login from '../pages/Login'
import Register from '../pages/Register'
import ForgotPassword from '../pages/ForgotPassword'
import ResetPassword from '../pages/ResetPassword'
import EmailVerification from '../pages/EmailVerification'
import Profile from '../pages/Profile'
import Dashboard from '../pages/Dashboard'
import ExpenseList from '../pages/expenses/ExpenseList'
import IncomeList from '../pages/income/IncomeList'
import BudgetList from '../pages/budgets/BudgetList'
import SavingsList from '../pages/savings/SavingsList'
import Analytics from '../pages/Analytics'
import GoalList from '../pages/goals/GoalList'
import Reports from '../pages/Reports'
import Settings from '../pages/Settings'
import Insights from '../pages/Insights'
import NotFound from '../pages/NotFound'
import ProtectedRoute from '../components/routes/ProtectedRoute'

function Protected({ children }) {
  return <ProtectedRoute>{children}</ProtectedRoute>
}

export default function AppRoutes() {
  return (
    <Routes>
      {/* Public / marketing */}
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/verify-email" element={<EmailVerification />} />

      {/* Authenticated app */}
      <Route path="/app/dashboard" element={<Protected><Dashboard /></Protected>} />
      <Route path="/app/insights" element={<Protected><Insights /></Protected>} />
      <Route path="/app/expenses" element={<Protected><ExpenseList /></Protected>} />
      <Route path="/app/income" element={<Protected><IncomeList /></Protected>} />
      <Route path="/app/budgets" element={<Protected><BudgetList /></Protected>} />
      <Route path="/app/savings" element={<Protected><SavingsList /></Protected>} />
      <Route path="/app/goals" element={<Protected><GoalList /></Protected>} />
      <Route path="/app/analytics" element={<Protected><Analytics /></Protected>} />
      <Route path="/app/reports" element={<Protected><Reports /></Protected>} />
      <Route path="/app/settings" element={<Protected><Settings /></Protected>} />
      <Route path="/app/profile" element={<Protected><Profile /></Protected>} />

      <Route path="*" element={<NotFound />} />
    </Routes>
  )
}
