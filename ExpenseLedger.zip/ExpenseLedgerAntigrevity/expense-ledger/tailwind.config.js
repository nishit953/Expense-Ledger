/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        // Primary — Ledger Emerald
        emerald: {
          50: '#ECFDF5',
          100: '#D1FAE5',
          200: '#A7F3D0',
          300: '#6EE7B7',
          400: '#34D399',
          500: '#10B981',
          600: '#059669',
          700: '#047857',
          800: '#065F46',
          900: '#064E3B',
        },
        // Secondary — Ink Blue
        ink: {
          50: '#EFF4FF',
          100: '#DBE6FE',
          300: '#93B4FD',
          500: '#3B67F5',
          600: '#1D4ED8',
          700: '#1739A8',
          900: '#111F5C',
        },
        // Accent — Violet
        violet: {
          50: '#F5F3FF',
          100: '#EDE9FE',
          300: '#C4B5FD',
          500: '#8B5CF6',
          600: '#7C3AED',
          700: '#6D28D9',
        },
        // Surfaces
        paper: {
          light: '#F8FAF9',
          card: '#FFFFFF',
          line: '#E4E9E7',
        },
        ink900: '#0B1210',
        // Dark mode surfaces
        night: {
          bg: '#0B0F0E',
          surface: '#121715',
          card: '#161C1A',
          line: '#232B28',
          text: '#E7EFEC',
          muted: '#8FA39B',
        },
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'sans-serif'],
        sans: ['Inter', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      backgroundImage: {
        'ledger-lines':
          'repeating-linear-gradient(to bottom, transparent, transparent 39px, currentColor 39px, currentColor 40px)',
      },
      boxShadow: {
        soft: '0 2px 8px rgba(11, 18, 16, 0.04), 0 1px 2px rgba(11, 18, 16, 0.04)',
        card: '0 8px 24px rgba(11, 18, 16, 0.06), 0 2px 6px rgba(11, 18, 16, 0.04)',
        glow: '0 0 0 1px rgba(16, 185, 129, 0.15), 0 8px 32px rgba(16, 185, 129, 0.12)',
      },
      borderRadius: {
        xl2: '1.25rem',
      },
      animation: {
        'fade-up': 'fadeUp 0.6s ease-out forwards',
        float: 'float 6s ease-in-out infinite',
        ticker: 'ticker 1.2s ease-out',
      },
      keyframes: {
        fadeUp: {
          '0%': { opacity: 0, transform: 'translateY(16px)' },
          '100%': { opacity: 1, transform: 'translateY(0)' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-14px)' },
        },
        ticker: {
          '0%': { opacity: 0, transform: 'translateY(6px)' },
          '100%': { opacity: 1, transform: 'translateY(0)' },
        },
      },
    },
  },
  plugins: [],
}
